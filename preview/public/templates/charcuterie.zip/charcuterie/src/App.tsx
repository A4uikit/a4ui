import {
  Accordion,
  Aurora,
  Badge,
  Button,
  Card,
  Carousel,
  Configurator,
  type ConfiguratorGroup,
  type ConfiguratorState,
  GradientText,
  Input,
  Magnetic,
  Parallax,
  PricingTable,
  Rating,
  ScrollProgress,
  Section,
  Stat,
  Textarea,
  TextReveal,
} from '@a4ui/core'
import {
  Award,
  Beef,
  Circle,
  Clock,
  Gift,
  Grape,
  Mail,
  MapPin,
  MessageCircle,
  Package,
  Phone,
  Sparkles,
  Truck,
  Utensils,
  Wine,
  AtSign,
} from 'lucide-solid'
import { createSignal, For, Show, type JSX } from 'solid-js'

const NAV = [
  { href: '#catalog', label: 'Catálogo' },
  { href: '#builder', label: 'Arma tu tabla' },
  { href: '#gift', label: 'Regalos' },
  { href: '#about', label: 'Nosotros' },
  { href: '#reviews', label: 'Reseñas' },
  { href: '#contact', label: 'Contacto' },
]

type Product = { category: string; icon: JSX.Element; title: string; blurb: string; price: string }

const PRODUCTS: Product[] = [
  { category: 'Embutidos', icon: <Beef class="h-6 w-6" />, title: 'Jamón serrano 18 meses', blurb: 'Curado tradicional, corte fino a mano.', price: '$180 / 250g' },
  { category: 'Embutidos', icon: <Beef class="h-6 w-6" />, title: 'Chorizo ibérico picante', blurb: 'Pimentón ahumado y especias de la casa.', price: '$140 / 250g' },
  { category: 'Quesos', icon: <Circle class="h-6 w-6" />, title: 'Manchego añejo', blurb: '12 meses de maduración, sabor intenso.', price: '$210 / 300g' },
  { category: 'Quesos', icon: <Circle class="h-6 w-6" />, title: 'Brie cremoso', blurb: 'Corteza aterciopelada, centro untuoso.', price: '$190 / 250g' },
  { category: 'Acompañamientos', icon: <Grape class="h-6 w-6" />, title: 'Mermelada de higo', blurb: 'Endulza cada bocado con un toque frutal.', price: '$95 / frasco' },
  { category: 'Acompañamientos', icon: <Wine class="h-6 w-6" />, title: 'Galletas artesanales', blurb: 'Horneadas en casa, textura crujiente.', price: '$85 / caja' },
]

const BOARD_SIZES = [
  { id: 'personal', label: 'Personal', people: '1–2 personas', base: 320 },
  { id: 'shareable', label: 'Para compartir', people: '4–6 personas', base: 620 },
  { id: 'party', label: 'Fiesta', people: '8–12 personas', base: 980 },
] as const

type BuilderItem = { id: string; name: string; price: number }

const BUILDER_CATEGORIES: { id: string; label: string; icon: JSX.Element; items: BuilderItem[] }[] = [
  {
    id: 'embutidos',
    label: 'Embutidos',
    icon: <Beef class="h-4 w-4" />,
    items: [
      { id: 'jamon', name: 'Jamón serrano', price: 60 },
      { id: 'salchichon', name: 'Salchichón ibérico', price: 55 },
      { id: 'prosciutto', name: 'Prosciutto', price: 65 },
      { id: 'chorizo', name: 'Chorizo curado', price: 45 },
    ],
  },
  {
    id: 'quesos',
    label: 'Quesos',
    icon: <Circle class="h-4 w-4" />,
    items: [
      { id: 'manchego', name: 'Manchego añejo', price: 70 },
      { id: 'brie', name: 'Brie cremoso', price: 65 },
      { id: 'gouda', name: 'Gouda ahumado', price: 55 },
      { id: 'cabra', name: 'Cabra con hierbas', price: 60 },
    ],
  },
  {
    id: 'extras',
    label: 'Extras',
    icon: <Grape class="h-4 w-4" />,
    items: [
      { id: 'miel', name: 'Miel de abeja', price: 35 },
      { id: 'mermelada', name: 'Mermelada de higo', price: 40 },
      { id: 'nueces', name: 'Nueces garapiñadas', price: 30 },
      { id: 'galletas', name: 'Galletas artesanales', price: 25 },
      { id: 'uvas', name: 'Uvas frescas', price: 30 },
    ],
  },
]

const CONFIGURATOR_GROUPS: ConfiguratorGroup[] = [
  {
    type: 'select',
    name: 'tamano',
    label: 'Tamaño',
    options: BOARD_SIZES.map((s) => ({ value: s.id, label: `${s.label} · ${s.people}`, price: s.base })),
  },
  ...BUILDER_CATEGORIES.map(
    (cat): ConfiguratorGroup => ({
      type: 'counter',
      name: cat.id,
      label: cat.label,
      items: cat.items.map((item) => ({ id: item.id, label: item.name, price: item.price })),
    }),
  ),
]

const DEFAULT_CONFIGURATOR_STATE: ConfiguratorState = {
  tamano: 'shareable',
  embutidos: {},
  quesos: {},
  extras: {},
}

function boardSizeInfo(state: ConfiguratorState): (typeof BOARD_SIZES)[number] {
  const sizeId = typeof state.tamano === 'string' ? state.tamano : ''
  return BOARD_SIZES.find((s) => s.id === sizeId) ?? BOARD_SIZES[1]
}

function selectedBoardLines(state: ConfiguratorState): (BuilderItem & { qty: number })[] {
  return BUILDER_CATEGORIES.flatMap((cat) => {
    const counts = state[cat.id]
    const record: Record<string, number> = counts && typeof counts === 'object' ? counts : {}
    return cat.items
      .filter((item) => (record[item.id] ?? 0) > 0)
      .map((item) => ({ ...item, qty: record[item.id] ?? 0 }))
  })
}

function boardGrandTotal(state: ConfiguratorState): number {
  const lines = selectedBoardLines(state)
  return boardSizeInfo(state).base + lines.reduce((sum, l) => sum + l.qty * l.price, 0)
}

type GiftBox = { title: string; occasion: string; blurb: string; price: string }

const GIFT_BOXES: GiftBox[] = [
  { title: 'Caja Aperitivo', occasion: 'Cumpleaños', blurb: 'Selección de embutidos, quesos y galletas para 2.', price: '$450' },
  { title: 'Caja Ejecutiva', occasion: 'Corporativo', blurb: 'Ideal para agradecer a clientes o a tu equipo.', price: '$780' },
  { title: 'Caja Festiva', occasion: 'Navidad', blurb: 'Edición especial con vino y mermeladas artesanales.', price: '$980' },
  { title: 'Caja Romance', occasion: 'Aniversario', blurb: 'Quesos suaves, chocolate y un toque dulce.', price: '$620' },
]

const REVIEWS = [
  { name: 'Renata G.', quote: 'La tabla para compartir fue el alma de la fiesta. Todo fresco y bien armado.', rating: 5 },
  { name: 'Emiliano T.', quote: 'Pedimos la caja ejecutiva para clientes y quedaron encantados.', rating: 5 },
  { name: 'Sofía L.', quote: 'El maridaje de quesos y mermeladas es un acierto total. Ya es tradición en casa.', rating: 5 },
]

type CateringPackage = { name: string; people: string; price: string; features: string[]; popular?: boolean }

const PACKAGES: CateringPackage[] = [
  { name: 'Básico', people: 'Desde 10 personas', price: '$180 / persona', features: ['Selección de 3 embutidos', '2 quesos de temporada', 'Pan y galletas artesanales'] },
  { name: 'Signature', people: 'Desde 20 personas', price: '$240 / persona', features: ['5 embutidos premium', '4 quesos añejos', 'Mermeladas y miel', 'Montaje en el lugar'], popular: true },
  { name: 'Corporativo', people: 'Desde 40 personas', price: 'Cotización', features: ['Menú a medida', 'Servicio de staff', 'Cajas individuales'] },
]

const FAQ = [
  { value: 'q1', title: '¿Manejan alérgenos como frutos secos o lácteos?', content: 'Sí, casi todas nuestras tablas incluyen lácteos y algunas incluyen frutos secos. Indícanos tus restricciones al pedir y armamos una versión segura.' },
  { value: 'q2', title: '¿Cómo debo conservar y servir la tabla?', content: 'Mantén la tabla refrigerada hasta 30 minutos antes de servir. Una vez armada, se recomienda consumir dentro de 4 horas a temperatura ambiente.' },
  { value: 'q3', title: '¿Con cuánta anticipación debo pedir?', content: 'Para tablas personales o para compartir, 24 horas es suficiente. Para eventos y cajas corporativas, recomendamos 5 días de anticipación.' },
  { value: 'q4', title: '¿A qué zonas hacen entrega?', content: 'Entregamos en toda la zona metropolitana. Para eventos foráneos, cotizamos el envío por separado.' },
]

function formatMXN(n: number): string {
  return `$${n.toLocaleString('es-MX')}`
}

export function App(): JSX.Element {
  // Board builder state
  const [boardConfig, setBoardConfig] = createSignal<ConfiguratorState>(DEFAULT_CONFIGURATOR_STATE)

  // Contact / order form state
  const [name, setName] = createSignal('')
  const [email, setEmail] = createSignal('')
  const [phone, setPhone] = createSignal('')
  const [eventDate, setEventDate] = createSignal('')
  const [guests, setGuests] = createSignal('')
  const [message, setMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  const requestBoard = (): void => {
    const state = boardConfig()
    const size = boardSizeInfo(state)
    const lines = selectedBoardLines(state)
      .map((l) => `${l.qty}× ${l.name}`)
      .join(', ')
    setMessage(
      `Quiero pedir una tabla ${size.label.toLowerCase()} (${size.people})${
        lines ? ` con: ${lines}` : ''
      }. Total estimado: ${formatMXN(boardGrandTotal(state))}.`,
    )
    location.hash = '#contact'
  }

  const requestGiftBox = (title: string): void => {
    setMessage(`Quiero pedir la ${title} para regalo.`)
    location.hash = '#contact'
  }

  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress />

      <Aurora />

      {/* Nav */}
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" class="flex items-center gap-2 font-semibold tracking-tight">
            <Wine class="h-5 w-5 text-primary" /> La Tabla
          </a>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <Button ripple onClick={() => (location.hash = '#builder')}>
            Arma tu tabla
          </Button>
        </div>
      </header>

      {/* Hero */}
      <div id="top" class="relative overflow-hidden">
        <Parallax amount={50} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="absolute inset-0"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.18), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.2), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="neutral" class="mb-5">
            <Utensils class="h-3.5 w-3.5" /> Charcutería artesanal
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Cada tabla cuenta una <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">historia de sabor</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Embutidos curados, quesos añejos y acompañamientos artesanales. Arma tu propia tabla o elige una de nuestras cajas de regalo.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#builder')}>
                Arma tu tabla
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => (location.hash = '#catalog')}>
              Ver catálogo
            </Button>
          </div>
        </Section>
      </div>

      {/* Catalog */}
      <Section id="catalog">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Nuestro catálogo" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Embutidos curados, quesos añejos y acompañamientos seleccionados con cuidado.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={PRODUCTS}>
            {(p) => (
              <Card glass tilt spotlight class="p-6">
                <Badge tone="neutral" class="mb-4">{p.category}</Badge>
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {p.icon}
                </div>
                <h3 class="text-lg font-semibold">{p.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{p.blurb}</p>
                <p class="mt-4 text-sm font-medium text-primary">{p.price}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Board builder */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section id="builder">
          <div class="mb-10 text-center">
            <Badge tone="neutral" class="mb-4">
              <Sparkles class="h-3.5 w-3.5" /> El corazón de La Tabla
            </Badge>
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Arma tu tabla" onView />
            </h2>
            <p class="mx-auto mt-2 max-w-xl text-muted-foreground">
              Elige el tamaño, agrega tus favoritos y mira el total actualizarse en tiempo real.
            </p>
          </div>

          <Configurator
            value={boardConfig()}
            onChange={setBoardConfig}
            groups={CONFIGURATOR_GROUPS}
            formatTotal={formatMXN}
            action={{ label: 'Solicitar esta tabla', onClick: requestBoard }}
            preview={(state) => {
              const size = boardSizeInfo(state)
              const lines = selectedBoardLines(state)
              return (
                <Card glass glow class="p-6">
                  <h3 class="text-lg font-semibold">Tu tabla</h3>
                  <p class="mb-4 text-sm text-muted-foreground">
                    {size.label} · {size.people}
                  </p>
                  <Show when={lines.length > 0} fallback={<p class="py-2 text-xs text-muted-foreground">Aún no agregas extras.</p>}>
                    <div class="space-y-2 text-sm">
                      <For each={lines}>
                        {(l) => (
                          <div class="flex items-center justify-between">
                            <span class="text-muted-foreground">
                              {l.qty}× {l.name}
                            </span>
                            <span class="font-medium">{formatMXN(l.qty * l.price)}</span>
                          </div>
                        )}
                      </For>
                    </div>
                  </Show>
                  <Badge tone="neutral" class="mt-4">
                    {lines.reduce((sum, l) => sum + l.qty, 0)} artículos seleccionados
                  </Badge>
                </Card>
              )
            }}
          />
        </Section>
      </div>

      {/* Gift boxes */}
      <Section id="gift">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Cajas de regalo</h2>
          <p class="mt-2 text-muted-foreground">Curadas para cada ocasión: cumpleaños, corporativo, fechas especiales.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <For each={GIFT_BOXES}>
            {(box) => (
              <Card glass tilt spotlight class="flex flex-col p-6">
                <Badge tone="warning" class="mb-4 w-fit">{box.occasion}</Badge>
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-accent/20 text-accent-foreground">
                  <Gift class="h-6 w-6" />
                </div>
                <h3 class="text-lg font-semibold">{box.title}</h3>
                <p class="mt-1 flex-1 text-sm text-muted-foreground">{box.blurb}</p>
                <p class="mt-4 text-sm font-medium text-primary">{box.price}</p>
                <Button variant="outline" ripple class="mt-4 w-full" onClick={() => requestGiftBox(box.title)}>
                  Solicitar
                </Button>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* About / trust */}
      <div id="about" class="border-y border-border/60 bg-muted/30">
        <Section py="md">
          <div class="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">Nuestra historia</h2>
              <p class="mt-4 text-muted-foreground">
                Empezamos en un mercado de productores locales, seleccionando embutidos curados y quesos añejados a mano. Hoy
                seguimos trabajando con los mismos productores, cuidando cada tabla como si fuera para nuestra propia mesa.
              </p>
              <p class="mt-3 text-muted-foreground">
                Cada pieza pasa por nuestra cocina antes de llegar a ti: se cata, se corta y se acomoda pensando en el
                maridaje perfecto entre sabores, texturas y acompañamientos.
              </p>
            </div>
            <div class="grid gap-6 sm:grid-cols-3">
              <Stat label="Años de tradición" value={15} tone="primary" icon={<Award class="h-5 w-5" />} />
              <Stat
                label="Tablas servidas"
                value={9200}
                format={(n) => `${Math.round(n / 100) / 10}k+`}
                tone="primary"
                icon={<Package class="h-5 w-5" />}
              />
              <Stat label="Eventos atendidos" value={320} format={(n) => `${Math.round(n)}+`} tone="neutral" icon={<Truck class="h-5 w-5" />} />
            </div>
          </div>
        </Section>
      </div>

      {/* Reviews */}
      <Section id="reviews">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Lo que dicen</h2>
        </div>
        <div class="mx-auto max-w-2xl">
          <Carousel
            autoplayMs={5000}
            slides={REVIEWS.map((r) => (
              <div class="px-2">
                <Card glass class="p-8 text-center">
                  <Rating value={r.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                  <p class="text-lg">"{r.quote}"</p>
                  <p class="mt-4 text-sm font-medium text-muted-foreground">— {r.name}</p>
                </Card>
              </div>
            ))}
          />
        </div>
      </Section>

      {/* Pricing / catering packages */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Paquetes para eventos</h2>
            <p class="mt-2 text-muted-foreground">Cotizaciones por persona para catering de bodas, corporativos y celebraciones.</p>
          </div>
          <PricingTable
            tiers={PACKAGES.map((pkg) => ({
              name: pkg.name,
              price: pkg.price,
              description: pkg.people,
              features: pkg.features,
              highlighted: pkg.popular,
              cta: {
                label: 'Cotizar',
                onClick: () => {
                  setMessage(`Quiero cotizar el paquete ${pkg.name} para un evento.`)
                  location.hash = '#contact'
                },
              },
            }))}
          />
        </Section>
      </div>

      {/* FAQ */}
      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">Preguntas frecuentes</h2>
          <Accordion items={FAQ} />
        </div>
      </Section>

      {/* Contact */}
      <div id="contact" class="border-t border-border/60 bg-muted/30">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">Pide tu tabla o cotiza tu evento</h2>
              <p class="mt-2 text-muted-foreground">Déjanos tus datos y te confirmamos disponibilidad el mismo día.</p>
              <ul class="mt-8 space-y-4 text-sm">
                <li class="flex items-center gap-3"><Phone class="h-5 w-5 text-primary" /> +52 55 1234 5678</li>
                <li class="flex items-center gap-3"><Mail class="h-5 w-5 text-primary" /> hola@latabla.mx</li>
                <li class="flex items-center gap-3"><MapPin class="h-5 w-5 text-primary" /> Av. de los Insurgentes 456, CDMX</li>
                <li class="flex items-center gap-3"><Clock class="h-5 w-5 text-primary" /> Mar–Dom · 10:00–19:00</li>
              </ul>
              <div class="mt-6 flex gap-3 text-muted-foreground">
                <a
                  href="#"
                  aria-label="Escríbenos"
                  class="inline-flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-primary/10 hover:text-primary"
                >
                  <AtSign class="h-5 w-5" />
                </a>
                <a
                  href="#"
                  aria-label="Mensajería directa"
                  class="inline-flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-primary/10 hover:text-primary"
                >
                  <MessageCircle class="h-5 w-5" />
                </a>
              </div>
              <Card glass class="mt-6 flex h-40 items-center justify-center border-dashed p-0 text-sm text-muted-foreground">
                <MapPin class="mr-2 h-5 w-5 text-primary" /> Mapa · Av. de los Insurgentes 456, CDMX
              </Card>
            </div>

            <Card glass class="p-6">
              {sent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {name() || 'nos vemos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Te contactamos para confirmar tu pedido o evento.</p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submit}>
                  <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                      <Input id="contact-name" value={name()} onInput={setName} placeholder="Tu nombre" required />
                    </div>
                    <div>
                      <label for="contact-phone" class="mb-1 block text-sm font-medium">Teléfono</label>
                      <Input id="contact-phone" value={phone()} onInput={setPhone} placeholder="55 0000 0000" type="tel" required />
                    </div>
                  </div>
                  <div>
                    <label for="contact-email" class="mb-1 block text-sm font-medium">Correo</label>
                    <Input id="contact-email" value={email()} onInput={setEmail} placeholder="tu@correo.com" type="email" required />
                  </div>
                  <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label for="contact-date" class="mb-1 block text-sm font-medium">Fecha del evento</label>
                      <Input id="contact-date" value={eventDate()} onInput={setEventDate} type="date" />
                    </div>
                    <div>
                      <label for="contact-guests" class="mb-1 block text-sm font-medium">Número de invitados</label>
                      <Input id="contact-guests" value={guests()} onInput={setGuests} placeholder="Ej. 25" type="number" />
                    </div>
                  </div>
                  <div>
                    <label for="contact-message" class="mb-1 block text-sm font-medium">Cuéntanos sobre tu pedido</label>
                    <Textarea id="contact-message" value={message()} onInput={setMessage} placeholder="Tabla, caja de regalo o paquete de evento…" rows={4} />
                  </div>
                  <Button ripple type="submit" class="w-full">Enviar solicitud</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2"><Wine class="h-4 w-4 text-primary" /> La Tabla · Charcutería & Tablas Gourmet</span>
          <span>© 2026 La Tabla. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}
