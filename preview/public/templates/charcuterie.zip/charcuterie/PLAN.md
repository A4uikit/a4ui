# Template: `charcuterie` — Charcuterie & deli shop

A single-page shop for a charcuterie/deli business selling cured meats,
cheeses, grazing boards (tablas), and gift boxes. Goal: a visitor browses the
catalog, builds a custom board, and orders or requests a quote for events.

## Sections

1. **Top bar / nav** — logo, anchor links (Catalog, Build a Board, Gift Boxes, Contact), cart icon. (`AppShell` top bar, `Button`, `Anchor`)
2. **Hero** — headline, subcopy, primary CTA "Arma tu tabla", secondary "Ver catálogo". Glass surface over a themed rustic-wood/marble backdrop. (`Card` glass, `GradientText` on headline, `Parallax` backdrop)
3. **About / our story** — sourcing story (local producers, aged cheeses, artisan cured meats), trust signals (years, events catered, certifications). (`Card`, `Stat` count-up for "years", "boards served")
4. **Product catalog** — filterable grid of cured meats, cheeses, accompaniments (honey, jams, crackers, nuts), with category filters. (`ProductGrid`, `ProductCard` tilt/spotlight, `FilterGroup`, `Image` blurUp)
5. **"Arma tu tabla" configurator** — the core interactive flow:
   - Step 1: pick board size (personal, shareable, party). (`Stepper`, `SegmentedControl`)
   - Step 2: choose meats, cheeses, and extras with quantity per slot. (`Checkbox`/`Radio` groups, `QuantityStepper`, `ProductCard`)
   - Step 3: live summary preview of the board composition (running list + price). (`Card`, `List` stagger, `PriceTag`)
   - Step 4: review + add to cart or "solicitar para evento". (`CartLine`, `CartSummary`, `Button` ripple)
6. **Gift boxes** — curated pre-made boxes for holidays/corporate gifting, with occasion tags. (`ProductGrid`, `ProductCard`, `Badge`, `PriceTag`)
7. **Social proof** — testimonials + ratings from events/parties, before/after board photos. (`Rating`, `Carousel` swipe, `Card`)
8. **Pricing / catering packages** — per-person pricing, event minimums, corporate tiers. (`Card`, `PriceTag`, `Badge` "Popular")
9. **FAQ** — allergens, storage/serving instructions, lead time for orders, delivery area. (`Accordion` animated height)
10. **Order / event-quote form + full Contact** — name, email/phone, event date, guest count, board/box selection, message, plus contact info (phone, address, hours, map placeholder, social links). (`Form`, `DateField`, `NumberInput`, `Select`, `Textarea`, `Input`, `Button` ripple, `Descriptions`)
11. **Footer** — nav, contact, socials, legal.

## Structure

**Single-page** (long scroll + sticky anchor nav).

## Custom theme

Rustic-elegant mood: deep burgundy/wine primary, warm mustard/olive accent,
cream and walnut neutrals evoking wood boards and aged cheese rinds; generous
radius on product and gift-box cards for a soft, artisanal feel. Override
`--primary` / `--accent` / `--surface` / `--radius-*` tokens; verify WCAG AA
in light + dark.

## Animation / parallax

- `Parallax` on the hero backdrop (wood board / ingredient layers).
- `ScrollProgress` bar tracking scroll through the board configurator steps.
- `TextReveal` on section headings; `GradientText` on the hero headline.
- `TiltCard` / `Spotlight` on `ProductCard`s in the catalog and gift boxes.
- `Carousel` swipe for testimonials and event photo gallery.
- `Stat` count-up for "boards served" / "events catered".
- `Curtain` transition between Hero and Catalog.
- `List` stagger for the board-summary list and FAQ entrance.
- `Image` blurUp for product and board photos as they load.

## Reusable candidates

- **Build-your-own configurator pattern** (size picker → multi-item selection
  with quantities → running summary/price → add to cart) overlaps heavily
  with the laser-engraving customization flow; propose a shared `A4uikit/a4ui`
  "Configurator" compound component (stepper + selectable item grid + live
  summary panel + cart hookup) usable for both engraving and food-assembly
  verticals.
- **Event/quote form** (date + guest count + product selection + message) as
  a reusable `EventQuoteForm` block, distinct from the generic contact `Form`.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `charcuterie` theme tokens
- [ ] Nav + hero
- [ ] About / our story section
- [ ] Product catalog (filters + quick view)
- [ ] "Arma tu tabla" board configurator (size → items → summary → cart)
- [ ] Gift boxes section
- [ ] Testimonials + ratings + event photo carousel
- [ ] Pricing / catering packages
- [ ] FAQ accordion
- [ ] Order/event-quote form + full contact section + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
