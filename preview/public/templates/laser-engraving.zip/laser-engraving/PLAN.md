# Template: `laser-engraving` — Custom thermoses & laser-engraved wood

A single-page shop for a maker business selling thermoses (termos) and
laser-engraved wooden figures, with a personalization flow: pick a product,
add text or upload a logo, preview the engraving, and request a custom quote.

## Sections

1. **Top bar / nav** — logo, anchor links (Shop, Personalize, Gallery, FAQ, Contact), cart icon. (`AppShell` top bar, `Button`, `Anchor`)
2. **Hero** — headline, subcopy, primary CTA "Personaliza el tuyo", secondary "Ver catálogo". Glass surface over a themed wood/metal backdrop. (`Card` glass, `GradientText` on headline, `Parallax` backdrop)
3. **About / our craft** — short story of the workshop, materials used, years making pieces, certifications/awards. (`Card`, `Stat` count-up for "pieces engraved", "years")
4. **Product showcase gallery** — filterable grid of thermoses and wooden figures with hover zoom and quick-view. (`ProductGrid`, `ProductCard` tilt/spotlight, `FilterGroup`, `Image` blurUp)
5. **"Personaliza tu grabado" configurator** — the core interactive flow:
   - Step 1: pick product (thermos size/color or wood figure shape). (`Stepper`, `SegmentedControl`, `ProductCard`)
   - Step 2: enter engraving text or upload a logo/image. (`Input`, `Textarea`, `FileUpload`/`Dropzone`)
   - Step 3: live preview mock of text/logo placed on the product mockup, with font/size/position controls. (`Card`, `Slider` for size/position, `NumberInput`, `Select` for font)
   - Step 4: review + add to cart or "solicitar cotización". (`CartLine`, `CartSummary`, `PriceTag`, `Button` ripple)
6. **Popular designs / inspiration carousel** — swipeable examples of past custom work. (`Carousel` swipe, `Card`)
7. **Social proof** — testimonials + ratings from buyers (gifts, corporate orders). (`Rating`, `Carousel`, `Card`)
8. **Pricing / packages** — per-unit pricing, bulk/corporate gifting tiers. (`Card`, `PriceTag`, `Badge` "Popular", `QuantityStepper`)
9. **FAQ** — materials, engraving durability, turnaround time, care instructions. (`Accordion` animated height)
10. **Custom-order / quote form + full Contact** — name, email/phone, product type, quantity, message, plus contact info (phone, address, hours, map placeholder, social links). (`Form`, `Select`, `NumberInput`, `Textarea`, `Input`, `Button` ripple, `Descriptions`)
11. **Footer** — nav, contact, socials, legal.

## Structure

**Single-page** (long scroll + sticky anchor nav).

## Custom theme

Warm workshop mood: walnut/espresso primary, warm copper/amber accent, matte
charcoal neutrals evoking laser-etched wood grain; slightly larger radius on
product cards to feel handcrafted. Override `--primary` / `--accent` /
`--surface` / `--radius-*` tokens; verify WCAG AA in light + dark.

## Animation / parallax

- `Parallax` on the hero backdrop (wood texture / laser sparks layer).
- `ScrollProgress` bar tracking scroll through the configurator steps.
- `TextReveal` on section headings; `GradientText` on the hero headline.
- `TiltCard` / `Spotlight` on `ProductCard`s in the gallery.
- `Carousel` swipe for inspiration gallery and testimonials.
- `Stat` count-up for "pieces engraved" / "happy customers".
- `Curtain` transition between Hero and Product showcase.
- `List` stagger for the FAQ and gallery grid entrance.
- `Image` blurUp for product photos as they load.

## Reusable candidates

- **Product configurator pattern** (step picker → input/upload → live preview
  mock → add to cart) is generic enough for any customizable-goods vertical
  (apparel, engraving, print-on-demand). Propose as an `A4uikit/a4ui` "Configurator"
  compound component (stepper + preview canvas + cart hookup).
- **Custom-order quote form** (product + quantity + file upload + message) as
  a reusable `QuoteForm` block, distinct from the generic contact `Form`.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `laser-engraving` theme tokens
- [ ] Nav + hero
- [ ] About / our craft section
- [ ] Product showcase gallery (filters + quick view)
- [ ] Personalization configurator (product picker → text/logo upload → live preview)
- [ ] Inspiration carousel
- [ ] Testimonials + ratings
- [ ] Pricing / bulk packages
- [ ] FAQ accordion
- [ ] Custom-order/quote form + full contact section + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
