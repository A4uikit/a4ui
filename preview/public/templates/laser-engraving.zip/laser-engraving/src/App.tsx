import {
  Accordion,
  Badge,
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Carousel,
  Configurator,
  type ConfiguratorState,
  GradientText,
  Input,
  Magnetic,
  Parallax,
  Rating,
  ScrollProgress,
  Section,
  Select,
  Stat,
  Textarea,
  TextReveal,
} from '@a4ui/core'
import {
  AtSign,
  Award,
  Clock,
  CupSoda,
  Flame,
  Gift,
  Hammer,
  Mail,
  MapPin,
  MessageCircle,
  Package,
  Phone,
  Sparkles,
  TreePine,
  Users,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const NAV = [
  { href: '#catalogo', label: 'Catálogo' },
  { href: '#personaliza', label: 'Personaliza' },
  { href: '#galeria', label: 'Galería' },
  { href: '#precios', label: 'Precios' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contacto', label: 'Contacto' },
]

type ProductKind = 'thermo' | 'wood'

interface CustomProduct {
  id: string
  kind: ProductKind
  label: string
  material: string
  price: number
  from: string
  to: string
  ink: string
}

const CUSTOM_PRODUCTS: CustomProduct[] = [
  { id: 'thermo-acero', kind: 'thermo', label: 'Termo acero 750 ml', material: 'Acero inoxidable pulido', price: 450, from: '#d9d9d9', to: '#84838a', ink: '#241f1a' },
  { id: 'thermo-negro', kind: 'thermo', label: 'Termo mate negro 500 ml', material: 'Acero pintura mate', price: 420, from: '#3a3733', to: '#141210', ink: '#f2c98a' },
  { id: 'wood-venado', kind: 'wood', label: 'Figura de venado', material: 'Madera de pino natural', price: 380, from: '#caa06a', to: '#7a4f24', ink: '#2b1a0c' },
  { id: 'wood-corazon', kind: 'wood', label: 'Placa corazón', material: 'Nogal macizo', price: 320, from: '#8a5a34', to: '#3d2513', ink: '#f4e3c8' },
]

const ENGRAVING_FEE = 120

const FONT_OPTIONS = [
  { value: 'font-sans', label: 'Moderna' },
  { value: 'font-serif', label: 'Clásica' },
  { value: 'italic font-serif', label: 'Script elegante' },
]

const SIZE_OPTIONS = [
  { value: 'text-lg', label: 'Pequeño' },
  { value: 'text-2xl', label: 'Mediano' },
  { value: 'text-4xl', label: 'Grande' },
]

const GALLERY: { icon: JSX.Element; name: string; material: string; price: string }[] = [
  { icon: <CupSoda class="h-6 w-6" />, name: 'Termo acero 750 ml', material: 'Acero inoxidable · doble pared', price: 'desde $450' },
  { icon: <CupSoda class="h-6 w-6" />, name: 'Termo mate negro 500 ml', material: 'Acero con pintura mate', price: 'desde $420' },
  { icon: <TreePine class="h-6 w-6" />, name: 'Venado de pino', material: 'Madera de pino natural', price: 'desde $380' },
  { icon: <TreePine class="h-6 w-6" />, name: 'Placa corazón de nogal', material: 'Nogal macizo', price: 'desde $320' },
  { icon: <TreePine class="h-6 w-6" />, name: 'Búho decorativo', material: 'Madera de encino', price: 'desde $340' },
  { icon: <Gift class="h-6 w-6" />, name: 'Set pareja de termos', material: 'Acero inoxidable', price: '$820 el set' },
]

const INSPIRATION: { kind: ProductKind; text: string; caption: string; from: string; to: string; ink: string }[] = [
  { kind: 'wood', text: 'Los Hernández 2024', caption: 'Placa de aniversario para boda', from: '#8a5a34', to: '#3d2513', ink: '#f4e3c8' },
  { kind: 'thermo', text: 'Café Aurora', caption: 'Pedido corporativo para cafetería', from: '#3a3733', to: '#141210', ink: '#f2c98a' },
  { kind: 'wood', text: 'Siempre juntos', caption: 'Regalo de cumpleaños', from: '#caa06a', to: '#7a4f24', ink: '#2b1a0c' },
  { kind: 'thermo', text: 'Equipo Ventas', caption: 'Kit de bienvenida corporativo', from: '#d9d9d9', to: '#84838a', ink: '#241f1a' },
]

const TESTIMONIALS = [
  { name: 'Mariana L.', quote: 'Compramos 40 termos grabados para el equipo, quedaron impecables y a tiempo.', rating: 5 },
  { name: 'Jorge T.', quote: 'La figura de mi perro en madera quedó igual a la foto que mandé. Increíble detalle.', rating: 5 },
  { name: 'Ana P.', quote: 'El proceso de personalizar en línea fue súper fácil y el resultado superó lo que esperaba.', rating: 5 },
]

const TIERS: { name: string; price: string; desc: string; features: string[]; popular: boolean }[] = [
  { name: 'Individual', price: '$450', desc: '1 pieza personalizada', features: ['Grabado láser incluido', 'Texto o logo propio', 'Empaque de regalo'], popular: false },
  { name: 'Dúo / Familiar', price: '$1,650', desc: 'Set de 4 piezas', features: ['Diseño coordinado', 'Envío gratis', '15% de descuento'], popular: true },
  { name: 'Corporativo', price: 'Cotización', desc: '25+ piezas', features: ['Logo de empresa', 'Precio por volumen', 'Entrega programada'], popular: false },
]

const FAQ = [
  { value: 'q1', title: '¿En qué materiales graban?', content: 'Trabajamos acero inoxidable, madera de pino, nogal y encino, todos tratados para resistir el uso diario.' },
  { value: 'q2', title: '¿Cuánto dura el grabado?', content: 'El grabado láser es permanente: no se despinta ni se borra con el lavado, y resiste años de uso diario.' },
  { value: 'q3', title: '¿Cuánto tarda mi pedido?', content: 'Piezas individuales: 3–5 días hábiles. Pedidos corporativos o de mayoreo: 7–12 días hábiles según cantidad.' },
  { value: 'q4', title: '¿Cómo cuido mi pieza grabada?', content: 'Termos: lava a mano, evita el lavavajillas. Figuras de madera: limpia con paño seco y aplica aceite mineral cada 6 meses.' },
]

const QUOTE_PRODUCTS = [
  ...CUSTOM_PRODUCTS.map((p) => ({ value: p.id, label: p.label })),
  { value: 'mayoreo', label: 'Pedido corporativo / mayoreo' },
  { value: 'otro', label: 'Otro / no estoy seguro' },
]

function EngravingPreview(props: {
  kind: ProductKind
  from: string
  to: string
  ink: string
  text: string
  fontClass: string
  sizeClass: string
}): JSX.Element {
  return (
    <>
      {props.kind === 'thermo' ? (
        <div class="mx-auto flex w-40 flex-col items-center">
          <div class="h-5 w-16 rounded-t-xl" style={{ background: props.to }} />
          <div
            class="flex h-64 w-40 items-center justify-center rounded-b-[2.25rem] rounded-t-md px-4 text-center shadow-xl"
            style={{ background: `linear-gradient(135deg, ${props.from}, ${props.to})` }}
          >
            <span class={`${props.fontClass} ${props.sizeClass} break-words leading-snug`} style={{ color: props.ink }}>
              {props.text || 'Tu texto aquí'}
            </span>
          </div>
        </div>
      ) : (
        <div
          class="mx-auto flex h-64 w-64 items-center justify-center rounded-full p-8 text-center shadow-xl"
          style={{
            background: `repeating-radial-gradient(circle at 50% 50%, ${props.to}, ${props.to} 3px, ${props.from} 4px, ${props.from} 16px)`,
          }}
        >
          <span class={`${props.fontClass} ${props.sizeClass} break-words leading-snug`} style={{ color: props.ink }}>
            {props.text || 'Tu texto aquí'}
          </span>
        </div>
      )}
    </>
  )
}

export function App(): JSX.Element {
  // Customizer state, driven by the Configurator.
  const [config, setConfig] = createSignal<ConfiguratorState>({
    producto: CUSTOM_PRODUCTS[0].id,
    fuente: FONT_OPTIONS[0].value,
    tamano: SIZE_OPTIONS[1].value,
    texto: 'Familia García',
  })

  const selectedProduct = (): CustomProduct =>
    CUSTOM_PRODUCTS.find((p) => p.id === (config().producto as string)) ?? CUSTOM_PRODUCTS[0]

  // Quote / contact form state.
  const [quoteName, setQuoteName] = createSignal('')
  const [quoteEmail, setQuoteEmail] = createSignal('')
  const [quoteProduct, setQuoteProduct] = createSignal(CUSTOM_PRODUCTS[0].id)
  const [quoteQty, setQuoteQty] = createSignal('1')
  const [quoteMessage, setQuoteMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const requestFromCustomizer = (): void => {
    const product = selectedProduct()
    setQuoteProduct(product.id)
    setQuoteMessage(`Quiero cotizar: ${product.label} grabado con "${config().texto as string}".`)
    location.hash = '#contacto'
  }

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <div class="min-h-screen bg-background text-foreground">
      <ScrollProgress color="hsl(var(--primary))" />

      {/* Nav */}
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" class="flex items-center gap-2 font-semibold tracking-tight">
            <Flame class="h-5 w-5 text-primary" /> Roble & Láser
          </a>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <Button ripple onClick={() => (location.hash = '#personaliza')}>
            Personaliza el tuyo
          </Button>
        </div>
      </header>

      {/* Hero */}
      <div id="top" class="relative overflow-hidden">
        <Parallax amount={50} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.2), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.18), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="neutral" class="mb-5">
            <Flame class="h-3.5 w-3.5" /> Grabado láser artesanal
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Regalos con <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">tu huella</GradientText>, grabados para siempre
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Termos de acero y figuras de madera con grabado láser permanente. Diseña tu pieza en línea y mira la vista previa antes de pedirla.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#personaliza')}>
                Personaliza tu grabado
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => (location.hash = '#catalogo')}>
              Ver catálogo
            </Button>
          </div>
        </Section>
      </div>

      {/* About / craft */}
      <div id="about" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <Badge tone="neutral" class="mb-3"><Hammer class="h-3.5 w-3.5" /> Taller artesanal</Badge>
              <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Hecho a mano, grabado con precisión" onView /></h2>
              <p class="mt-3 text-muted-foreground">
                Somos un taller familiar dedicado a la madera y el acero desde 2017. Cada pieza pasa por diseño, corte y grabado láser propio,
                con acabados que cuidamos como si fueran para nuestra propia mesa.
              </p>
              <div class="mt-5 flex items-center gap-2 text-sm text-muted-foreground">
                <Award class="h-4 w-4 text-primary" /> Materiales certificados y proveedores locales
              </div>
            </div>
            <div class="grid gap-6 sm:grid-cols-3">
              <Stat label="Piezas grabadas" value={15000} format={(n) => `${Math.round(n / 1000)}k+`} tone="primary" icon={<Sparkles class="h-4 w-4" />} />
              <Stat label="Años de oficio" value={9} tone="neutral" icon={<Hammer class="h-4 w-4" />} />
              <Stat label="Clientes felices" value={3200} format={(n) => `${Math.round(n / 100) / 10}k+`} tone="primary" icon={<Users class="h-4 w-4" />} />
            </div>
          </div>
        </Section>
      </div>

      {/* Product showcase gallery */}
      <Section id="catalogo">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Catálogo" onView /></h2>
          <p class="mt-2 text-muted-foreground">Termos y figuras de madera, listos para personalizar.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={GALLERY}>
            {(item) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {item.icon}
                </div>
                <h3 class="text-lg font-semibold">{item.name}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{item.material}</p>
                <p class="mt-4 text-sm font-medium text-primary">{item.price}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Configurator — the standout */}
      <div id="personaliza" class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="mb-10 text-center">
            <Badge tone="neutral" class="mb-3"><Sparkles class="h-3.5 w-3.5" /> Vista previa en vivo</Badge>
            <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Personaliza tu grabado" onView /></h2>
            <p class="mt-2 text-muted-foreground">Elige tu pieza, escribe tu texto y mira cómo quedará antes de pedirla.</p>
          </div>

          <Card glass class="p-6 lg:p-8">
            <p class="mb-6 text-xs text-muted-foreground">
              Los precios de producto incluyen el grabado láser (+${ENGRAVING_FEE} MXN).
            </p>
            <Configurator
              value={config()}
              onChange={setConfig}
              formatTotal={(n) => `$${n} MXN`}
              groups={[
                {
                  type: 'select',
                  name: 'producto',
                  label: '1. Elige tu producto',
                  options: CUSTOM_PRODUCTS.map((p) => ({ value: p.id, label: p.label, price: p.price + ENGRAVING_FEE })),
                },
                { type: 'text', name: 'texto', label: '2. Escribe tu grabado', placeholder: 'Ej. Familia García', maxLength: 40 },
                { type: 'select', name: 'fuente', label: '3. Elige la fuente', options: FONT_OPTIONS },
                { type: 'select', name: 'tamano', label: '4. Elige el tamaño', options: SIZE_OPTIONS },
              ]}
              action={{ label: 'Solicitar este diseño', onClick: requestFromCustomizer }}
              preview={(state) => {
                const product = CUSTOM_PRODUCTS.find((p) => p.id === (state.producto as string)) ?? CUSTOM_PRODUCTS[0]
                return (
                  <Card glass glow class="flex h-full flex-col items-center justify-center gap-6 p-8">
                    <Badge tone="info">Vista previa</Badge>
                    <EngravingPreview
                      kind={product.kind}
                      from={product.from}
                      to={product.to}
                      ink={product.ink}
                      text={(state.texto as string) ?? ''}
                      fontClass={(state.fuente as string) ?? FONT_OPTIONS[0].value}
                      sizeClass={(state.tamano as string) ?? SIZE_OPTIONS[1].value}
                    />
                    <div class="text-center">
                      <p class="font-medium">{product.label}</p>
                      <p class="text-sm text-muted-foreground">{product.material}</p>
                    </div>
                  </Card>
                )
              }}
            />
          </Card>
        </Section>
      </div>

      {/* Inspiration carousel */}
      <Section id="galeria">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Diseños de inspiración" onView /></h2>
          <p class="mt-2 text-muted-foreground">Piezas reales que hemos grabado para nuestros clientes.</p>
        </div>
        <div class="mx-auto max-w-md">
          <Carousel
            swipe
            slides={INSPIRATION.map((i) => (
              <div class="px-2">
                <Card glass class="flex flex-col items-center gap-4 p-8">
                  <EngravingPreview kind={i.kind} from={i.from} to={i.to} ink={i.ink} text={i.text} fontClass="font-serif" sizeClass="text-xl" />
                  <p class="text-center text-sm text-muted-foreground">{i.caption}</p>
                </Card>
              </div>
            ))}
          />
        </div>
      </Section>

      {/* Testimonials */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section id="resenas" class="!py-16">
          <div class="mb-8 text-center">
            <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Lo que dicen" onView /></h2>
          </div>
          <div class="mx-auto max-w-2xl">
            <Carousel
              autoplayMs={5000}
              slides={TESTIMONIALS.map((r) => (
                <div class="px-2">
                  <Card glass class="p-8 text-center">
                    <Rating value={r.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                    <p class="text-lg">“{r.quote}”</p>
                    <p class="mt-4 text-sm font-medium text-muted-foreground">— {r.name}</p>
                  </Card>
                </div>
              ))}
            />
          </div>
        </Section>
      </div>

      {/* Pricing / packages */}
      <Section id="precios">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Precios y paquetes" onView /></h2>
          <p class="mt-2 text-muted-foreground">Desde una pieza individual hasta pedidos corporativos.</p>
        </div>
        <div class="grid gap-6 sm:grid-cols-3">
          <For each={TIERS}>
            {(t) => (
              <Card glass tilt class={`relative p-0 ${t.popular ? 'ring-2 ring-primary' : ''}`}>
                {t.popular && (
                  <Badge tone="warning" pulse class="absolute -top-3 left-1/2 -translate-x-1/2">
                    Más popular
                  </Badge>
                )}
                <CardHeader>
                  <CardTitle>{t.name}</CardTitle>
                  <p class="text-sm text-muted-foreground">{t.desc}</p>
                </CardHeader>
                <CardContent>
                  <p class="mb-4 text-3xl font-semibold text-primary">{t.price}</p>
                  <ul class="space-y-2 text-sm text-muted-foreground">
                    <For each={t.features}>
                      {(f) => (
                        <li class="flex items-center gap-2">
                          <Package class="h-4 w-4 text-primary" /> {f}
                        </li>
                      )}
                    </For>
                  </ul>
                  <Button ripple variant={t.popular ? 'primary' : 'outline'} class="mt-6 w-full" onClick={() => (location.hash = '#contacto')}>
                    Solicitar cotización
                  </Button>
                </CardContent>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* FAQ */}
      <div class="border-t border-border/60 bg-muted/30">
        <Section id="faq" class="!py-16">
          <div class="mx-auto max-w-2xl">
            <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight"><TextReveal text="Preguntas frecuentes" onView /></h2>
            <Accordion items={FAQ} />
          </div>
        </Section>
      </div>

      {/* Contact / quote form */}
      <div id="contacto">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Cotiza tu pedido" onView /></h2>
              <p class="mt-2 text-muted-foreground">Cuéntanos qué quieres grabar y te respondemos con tu cotización el mismo día.</p>
              <ul class="mt-8 space-y-4 text-sm">
                <li class="flex items-center gap-3"><Phone class="h-5 w-5 text-primary" /> +52 33 1234 5678</li>
                <li class="flex items-center gap-3"><Mail class="h-5 w-5 text-primary" /> hola@robleylaser.mx</li>
                <li class="flex items-center gap-3"><MapPin class="h-5 w-5 text-primary" /> Av. Chapultepec 450, Guadalajara</li>
                <li class="flex items-center gap-3"><Clock class="h-5 w-5 text-primary" /> Lun–Sáb · 10:00–19:00</li>
              </ul>
              <div class="mt-6 flex gap-1 text-muted-foreground">
                <a href="#" aria-label="Redes sociales" class="flex h-9 w-9 items-center justify-center rounded-lg transition-colors hover:bg-muted hover:text-primary"><AtSign class="h-5 w-5" /></a>
                <a href="#" aria-label="WhatsApp" class="flex h-9 w-9 items-center justify-center rounded-lg transition-colors hover:bg-muted hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
              </div>
            </div>

            <Card glass class="p-6">
              {sent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {quoteName() || 'nos vemos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Te contactamos con tu cotización a la brevedad.</p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submit}>
                  <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label for="quote-name" class="mb-1 block text-sm font-medium">Nombre</label>
                      <Input id="quote-name" value={quoteName()} onInput={setQuoteName} placeholder="Tu nombre" required />
                    </div>
                    <div>
                      <label for="quote-email" class="mb-1 block text-sm font-medium">Correo</label>
                      <Input id="quote-email" value={quoteEmail()} onInput={setQuoteEmail} placeholder="tu@correo.com" type="email" required />
                    </div>
                  </div>
                  <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label for="quote-product" class="mb-1 block text-sm font-medium">Producto de interés</label>
                      <Select id="quote-product" value={quoteProduct()} onChange={setQuoteProduct}>
                        <For each={QUOTE_PRODUCTS}>{(p) => <option value={p.value}>{p.label}</option>}</For>
                      </Select>
                    </div>
                    <div>
                      <label for="quote-qty" class="mb-1 block text-sm font-medium">Cantidad</label>
                      <Input id="quote-qty" value={quoteQty()} onInput={setQuoteQty} type="number" min="1" placeholder="1" />
                    </div>
                  </div>
                  <div>
                    <label for="quote-message" class="mb-1 block text-sm font-medium">Mensaje</label>
                    <Textarea id="quote-message" value={quoteMessage()} onInput={setQuoteMessage} placeholder="Cuéntanos qué quieres grabar…" rows={4} />
                  </div>
                  <Button ripple type="submit" class="w-full">Solicitar cotización</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2"><Flame class="h-4 w-4 text-primary" /> Roble & Láser · Grabado artesanal</span>
          <span>© 2026 Roble & Láser. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}
