# Template: `fintech` — Digital wallet / neobank

A marketing site plus a logged-in-style app dashboard for a fintech wallet.
Goal: the marketing side converts visitors into signups by selling
simplicity, control, and security; the dashboard demo shows what the product
actually feels like once inside — balances, transactions, cards, transfers.

## Structure

**Multi-route** (`@solidjs/router`). Routes:

- `/` — marketing Home
- `/dashboard` — app Dashboard (accounts, transactions, cards, transfers)
- `/contact` — Contact

## Sections

### Nav / shell (all routes)

Marketing top bar (logo, links, "Log in" / "Open account" CTA) on `/` and
`/contact`. Dashboard uses an app-style shell with sidebar nav (Overview,
Transactions, Cards, Transfers, Settings). (`AppShell`, `NavGroup`,
`BottomNavigation` for the dashboard's mobile view)

### Marketing Home (`/`)

1. **Hero** — headline, subcopy, primary CTA "Open an account", secondary
   "See how it works". Glass card over a themed/gradient backdrop, product
   mockup (dashboard preview) floating with `Parallax`. (`Button` ripple)
2. **Trust bar** — logos/badges (bank-grade encryption, regulator/deposit
   insurance mention, uptime). (`Marquee` or static badge row)
3. **Features grid** — instant transfers, no hidden fees, budgeting
   insights, virtual cards, multi-currency. (`Card` tilt/spotlight, lucide
   icons)
4. **Product preview** — live-feeling snapshot of the dashboard: a `Stat`
   balance count-up + mini `Sparkline` + a few `List` stagger transaction
   rows, framed in a device/browser mockup card.
5. **Security & trust** — encryption, biometric login, fraud monitoring,
   KYC/identity verification callout ("we verify every account to keep your
   money safe"). (`Descriptions` or icon list, `Badge`, `RingProgress` as a
   "security score" visual)
6. **How it works** — sign up → verify identity → fund → spend, 4 steps.
   (`Stepper`)
7. **Pricing** — free vs premium tier comparison. (`Card`, `PriceTag`,
   `Badge` "Popular")
8. **Social proof** — customer quotes, app store ratings. (`Carousel` swipe,
   `Rating`)
9. **FAQ** — collapsible questions (fees, security, supported countries).
   (`Accordion` animated height)
10. **Final CTA + Footer**

### Dashboard (`/dashboard`)

1. **Accounts overview** — checking/savings account cards with balance.
   Count-up `Stat` per account, total net worth stat at the top.
   (`Stat`, `Card` glass)
2. **Spending charts** —
   - Monthly spend by category: `DonutChart`
   - Income vs. spend trend: `BarChart`
   - Balance trend over time: `Sparkline` per account
3. **Transactions table** — searchable/sortable/paginated ledger: date,
   merchant, category, amount, status. Row detail on click. (`DataGrid`,
   `Input` search, `Select` category filter, `DateRangePicker`)
4. **Cards** — virtual + physical card list, freeze/unfreeze toggle, spend
   limit. (`Card` tilt, `Switch`, `Meter` for limit usage, `Modal` for card
   detail / reveal number with `HoldToConfirm`)
5. **Transfer flow** — recipient select or add-new, amount (`NumberInput`),
   schedule (`DateField`), review step, confirm. (`Stepper` or `Form` +
   `AlertDialog` for confirmation, `Toast` on success)
6. **Identity verification banner** — KYC status (verified / pending /
   action needed) shown persistently until complete. (`Alert`, `Progress`
   or `RingProgress` for verification completeness, `Modal` to complete
   steps: ID upload via `FileUpload`/`Dropzone`, selfie step)
7. **Notifications** — recent alerts (large transaction, low balance, card
   frozen). (`NotificationCenter`, `Toast`)
8. **Empty/loading states** — first-time no-transactions state, skeleton
   while data loads. (`Empty`, `Skeleton` shimmer)

### Contact (`/contact`)

Full contact section per CONVENTIONS.md baseline:

1. **Contact form** — name, email/phone, message, topic (support / sales /
   security). (`Form`, `Select`, `Input`, `Textarea`, `Button ripple`)
2. **Contact info** — support phone, address, hours. (`Descriptions`)
3. **Map placeholder** — HQ location. (`Card`)
4. **Social links**
5. **Footer** — nav, contact, socials, legal, regulatory disclosures.

## Custom theme

Confident, modern fintech mood: near-black or deep indigo primary,
electric-teal or lime accent for CTAs and positive amounts, dedicated
negative/red for outflows and alerts. Tighter radius on data-dense
components (`DataGrid`, `Card` in dashboard), slightly larger radius on
marketing cards. Override `--primary` / `--accent` / `--success` /
`--danger` / `--radius-*` tokens. Keep WCAG AA in light + dark — critical
for numeric legibility in the `DataGrid` and chart labels.

## Animation / parallax

- `Parallax` on the Home hero product mockup and trust-bar section.
- `ScrollProgress` on the long marketing Home page.
- `TextReveal` for feature/section headings.
- `GradientText` or `ScrambleText` on the hero headline for a "digital"
  feel.
- Count-up `Stat` everywhere numbers appear: hero product preview, dashboard
  account balances, marketing trust stats.
- `List` stagger for the transaction list preview (marketing) and
  notifications feed.
- `Card` tilt/spotlight on feature cards and card-management cards.
- `Skeleton` shimmer while dashboard data loads (accounts, transactions,
  charts).
- `Badge` pulse on the KYC/verification status badge until verified.
- `Curtain` transition between hero and trust bar.
- `Magnetic`/`Spotlight` on the primary "Open an account" CTA.

## Reusable candidates

- **Stat band** (count-up balances/metrics row) — already a cross-template
  pattern, worth a documented composed variant.
- **Transactions table** (`DataGrid` + search + category filter + date
  range) — generic ledger UI, reusable for any account/billing history.
- **Transfer/payment flow stepper** (recipient → amount → schedule → review
  → confirm) — reusable wizard pattern.
- **KYC/verification status banner + progress** — reusable for any product
  needing identity verification (also relevant if `sports`/`sports-live`
  ever need age verification).
- **Spending breakdown widget** (`DonutChart` + `BarChart` + `Sparkline`
  combo card) — reusable analytics block.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset + `@solidjs/router`)
- [ ] Custom `fintech` theme tokens (incl. success/danger)
- [ ] Marketing: nav + hero + trust bar
- [ ] Marketing: features grid + product preview
- [ ] Marketing: security & trust section + KYC callout
- [ ] Marketing: how-it-works + pricing + testimonials + FAQ
- [ ] Dashboard: app shell + sidebar nav
- [ ] Dashboard: accounts overview (stats)
- [ ] Dashboard: spending charts (donut/bar/sparkline)
- [ ] Dashboard: transactions DataGrid (search/filter/paginate)
- [ ] Dashboard: cards management (freeze, limits, detail modal)
- [ ] Dashboard: transfer flow (stepper + confirmation)
- [ ] Dashboard: identity verification banner + upload flow
- [ ] Dashboard: notifications + empty/loading states
- [ ] Contact page (form + info + map + socials) + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
