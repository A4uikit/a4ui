import { Button } from '@a4ui/core'
import { AppShell, NavGroup } from '@a4ui/core'
import { BottomNavigation, NotificationCenter } from '@a4ui/core'
import { A, Route, Router, useLocation, useNavigate } from '@solidjs/router'
import { ArrowLeft, CreditCard, LayoutDashboard, ShieldCheck, Wallet } from 'lucide-solid'
import { createMemo, For, Show, type JSX } from 'solid-js'

import { NOTIFICATIONS } from './lib/data'
import { Cards } from './pages/Cards'
import { Contact } from './pages/Contact'
import { Dashboard } from './pages/Dashboard'
import { Home } from './pages/Home'
import { NotFound } from './pages/NotFound'

const MARKETING_NAV = [
  { href: '/', label: 'Inicio' },
  { href: '/contact', label: 'Contacto' },
]

const APP_NAV = [
  { href: '/dashboard', label: 'Resumen', icon: <LayoutDashboard class="h-4 w-4" /> },
  { href: '/cards', label: 'Tarjetas', icon: <CreditCard class="h-4 w-4" /> },
]

function isAppRoute(pathname: string): boolean {
  return pathname.startsWith('/dashboard') || pathname.startsWith('/cards')
}

function MarketingHeader(): JSX.Element {
  const navigate = useNavigate()
  return (
    <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
      <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
        <A href="/" class="flex items-center gap-2 font-semibold tracking-tight">
          <Wallet class="h-5 w-5 text-primary" /> Nuvo
        </A>
        <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <For each={MARKETING_NAV}>
            {(n) => (
              <A href={n.href} class="transition-colors hover:text-foreground" activeClass="text-foreground">
                {n.label}
              </A>
            )}
          </For>
        </nav>
        <div class="flex items-center gap-3">
          <Button variant="ghost" onClick={() => navigate('/dashboard')}>
            Iniciar sesión
          </Button>
          <Button ripple onClick={() => navigate('/dashboard')}>
            Abrir cuenta
          </Button>
        </div>
      </div>
    </header>
  )
}

function MarketingFooter(): JSX.Element {
  return (
    <footer class="border-t border-border/60">
      <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
        <span class="flex items-center gap-2">
          <Wallet class="h-4 w-4 text-primary" /> Nuvo · Banca digital regulada
        </span>
        <nav class="flex items-center gap-5">
          <For each={MARKETING_NAV}>{(n) => <A href={n.href} class="transition-colors hover:text-foreground">{n.label}</A>}</For>
        </nav>
        <span>© 2026 Nuvo. Hecho con A4ui.</span>
      </div>
    </footer>
  )
}

function Sidebar(): JSX.Element {
  return (
    <div class="hidden h-full w-[var(--sidebar-w)] shrink-0 flex-col border-r border-border/60 bg-card/60 px-4 py-6 md:flex">
      <A href="/" class="mb-8 flex items-center gap-2 px-2 font-semibold tracking-tight">
        <Wallet class="h-5 w-5 text-primary" /> Nuvo
      </A>
      <NavGroup title="Mi banca">
        <For each={APP_NAV}>
          {(item) => (
            <A
              href={item.href}
              class="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              activeClass="!bg-primary/10 !text-primary"
            >
              {item.icon} {item.label}
            </A>
          )}
        </For>
        <span class="flex cursor-not-allowed items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-muted-foreground/50">
          Transferencias
        </span>
        <span class="flex cursor-not-allowed items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-muted-foreground/50">
          Configuración
        </span>
      </NavGroup>
      <div class="mt-auto">
        <A href="/" class="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft class="h-4 w-4" /> Volver al sitio
        </A>
      </div>
    </div>
  )
}

function Topbar(): JSX.Element {
  return (
    <div class="flex items-center justify-between border-b border-border/60 px-5 py-3">
      <div class="flex items-center gap-2 text-sm text-muted-foreground">
        <ShieldCheck class="h-4 w-4 text-accent" /> Sesión protegida · cifrado de nivel bancario
      </div>
      <div class="flex items-center gap-3">
        <NotificationCenter items={NOTIFICATIONS} />
        <div class="flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-sm font-semibold text-primary">
          AP
        </div>
      </div>
    </div>
  )
}

function AppMobileNav(): JSX.Element {
  const location = useLocation()
  const navigate = useNavigate()
  const tab = createMemo(() => (location.pathname === '/cards' ? 'cards' : 'dashboard'))
  return (
    <div class="fixed inset-x-0 bottom-0 z-40 md:hidden">
      <BottomNavigation
        value={tab()}
        onChange={(v) => navigate(v === 'cards' ? '/cards' : '/dashboard')}
        items={[
          { value: 'dashboard', label: 'Resumen', icon: <LayoutDashboard class="h-5 w-5" /> },
          { value: 'cards', label: 'Tarjetas', icon: <CreditCard class="h-5 w-5" /> },
        ]}
      />
    </div>
  )
}

function Layout(props: { children?: JSX.Element }): JSX.Element {
  const location = useLocation()

  return (
    <Show
      when={isAppRoute(location.pathname)}
      fallback={
        <div class="min-h-screen bg-background text-foreground">
          <MarketingHeader />
          {props.children}
          <MarketingFooter />
        </div>
      }
    >
      <AppShell sidebar={<Sidebar />} topbar={<Topbar />} background={null} maxWidth="1400px">
        <div class="pb-20 md:pb-0">{props.children}</div>
      </AppShell>
      <AppMobileNav />
    </Show>
  )
}

export function App(): JSX.Element {
  return (
    <Router root={Layout}>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/cards" component={Cards} />
      <Route path="/contact" component={Contact} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}
