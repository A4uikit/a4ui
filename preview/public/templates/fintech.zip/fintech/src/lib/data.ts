// Sample data for the Nuvo digital wallet demo — accounts, transactions,
// spending breakdown, cards, and identity-verification state. All amounts in
// Mexican pesos (MXN) unless noted.

export interface Account {
  id: string
  label: string
  number: string
  currency: 'MXN' | 'USD'
  balance: number
  /** Balance trend points for the account's sparkline (oldest → newest). */
  trend: number[]
}

export const ACCOUNTS: Account[] = [
  {
    id: 'acc-corriente',
    label: 'Cuenta corriente',
    number: '•••• 4821',
    currency: 'MXN',
    balance: 48_213.6,
    trend: [31000, 33500, 29800, 36200, 40100, 37600, 44300, 48213.6],
  },
  {
    id: 'acc-ahorro',
    label: 'Cuenta de ahorro',
    number: '•••• 1097',
    currency: 'MXN',
    balance: 126_540.0,
    trend: [98000, 101200, 104500, 108900, 113200, 119800, 122100, 126540],
  },
  {
    id: 'acc-dolares',
    label: 'Cuenta en dólares',
    number: '•••• 7734',
    currency: 'USD',
    balance: 2_180.45,
    trend: [1900, 1950, 2010, 1975, 2040, 2090, 2140, 2180.45],
  },
]

export type TransactionStatus = 'completada' | 'pendiente' | 'rechazada'

export interface Transaction {
  id: string
  date: string
  merchant: string
  category: string
  accountId: string
  /** Negative = cargo/salida, positive = ingreso. */
  amount: number
  status: TransactionStatus
}

export const CATEGORIES = [
  'Comida',
  'Transporte',
  'Compras',
  'Servicios',
  'Entretenimiento',
  'Suscripciones',
  'Salud',
  'Otros',
] as const

export type Category = (typeof CATEGORIES)[number]

export const TRANSACTIONS: Transaction[] = [
  { id: 'tx-01', date: '2026-07-18', merchant: 'Rappi', category: 'Comida', accountId: 'acc-corriente', amount: -284.5, status: 'completada' },
  { id: 'tx-02', date: '2026-07-18', merchant: 'Uber', category: 'Transporte', accountId: 'acc-corriente', amount: -132.0, status: 'completada' },
  { id: 'tx-03', date: '2026-07-17', merchant: 'Nómina · ACME SA', category: 'Otros', accountId: 'acc-corriente', amount: 24_500.0, status: 'completada' },
  { id: 'tx-04', date: '2026-07-17', merchant: 'Oxxo', category: 'Comida', accountId: 'acc-corriente', amount: -96.0, status: 'completada' },
  { id: 'tx-05', date: '2026-07-16', merchant: 'Netflix', category: 'Suscripciones', accountId: 'acc-corriente', amount: -219.0, status: 'completada' },
  { id: 'tx-06', date: '2026-07-16', merchant: 'Spotify', category: 'Suscripciones', accountId: 'acc-corriente', amount: -129.0, status: 'completada' },
  { id: 'tx-07', date: '2026-07-15', merchant: 'CFE', category: 'Servicios', accountId: 'acc-corriente', amount: -845.3, status: 'completada' },
  { id: 'tx-08', date: '2026-07-15', merchant: 'Telcel', category: 'Servicios', accountId: 'acc-corriente', amount: -399.0, status: 'completada' },
  { id: 'tx-09', date: '2026-07-14', merchant: 'Farmacias del Ahorro', category: 'Salud', accountId: 'acc-corriente', amount: -312.8, status: 'completada' },
  { id: 'tx-10', date: '2026-07-14', merchant: 'Walmart', category: 'Compras', accountId: 'acc-corriente', amount: -1_204.9, status: 'completada' },
  { id: 'tx-11', date: '2026-07-13', merchant: 'Cinépolis', category: 'Entretenimiento', accountId: 'acc-corriente', amount: -220.0, status: 'completada' },
  { id: 'tx-12', date: '2026-07-13', merchant: 'Starbucks', category: 'Comida', accountId: 'acc-corriente', amount: -89.0, status: 'completada' },
  { id: 'tx-13', date: '2026-07-12', merchant: 'Amazon MX', category: 'Compras', accountId: 'acc-corriente', amount: -659.0, status: 'pendiente' },
  { id: 'tx-14', date: '2026-07-12', merchant: 'DiDi', category: 'Transporte', accountId: 'acc-corriente', amount: -145.5, status: 'completada' },
  { id: 'tx-15', date: '2026-07-11', merchant: 'Transferencia a Ana P.', category: 'Otros', accountId: 'acc-corriente', amount: -1_500.0, status: 'completada' },
  { id: 'tx-16', date: '2026-07-11', merchant: 'Superama', category: 'Comida', accountId: 'acc-corriente', amount: -540.2, status: 'completada' },
  { id: 'tx-17', date: '2026-07-10', merchant: 'Suscripción gimnasio', category: 'Salud', accountId: 'acc-corriente', amount: -450.0, status: 'completada' },
  { id: 'tx-18', date: '2026-07-10', merchant: 'Pago tarjeta de crédito', category: 'Servicios', accountId: 'acc-ahorro', amount: -3_200.0, status: 'completada' },
  { id: 'tx-19', date: '2026-07-09', merchant: 'Intento de cargo · Aliexpress', category: 'Compras', accountId: 'acc-corriente', amount: -899.0, status: 'rechazada' },
  { id: 'tx-20', date: '2026-07-09', merchant: 'Rendimiento cuenta ahorro', category: 'Otros', accountId: 'acc-ahorro', amount: 312.4, status: 'completada' },
  { id: 'tx-21', date: '2026-07-08', merchant: 'HBO Max', category: 'Suscripciones', accountId: 'acc-corriente', amount: -169.0, status: 'completada' },
  { id: 'tx-22', date: '2026-07-08', merchant: 'Gas Natural', category: 'Servicios', accountId: 'acc-corriente', amount: -410.0, status: 'completada' },
  { id: 'tx-23', date: '2026-07-07', merchant: 'Sanborns', category: 'Comida', accountId: 'acc-corriente', amount: -378.0, status: 'completada' },
  { id: 'tx-24', date: '2026-07-06', merchant: 'Depósito remesa', category: 'Otros', accountId: 'acc-dolares', amount: 4_500.0, status: 'completada' },
]

export const SPENDING_BY_CATEGORY: { label: string; value: number }[] = [
  { label: 'Comida', value: 2_500 },
  { label: 'Servicios', value: 1_654 },
  { label: 'Compras', value: 2_763 },
  { label: 'Suscripciones', value: 517 },
  { label: 'Transporte', value: 1_580 },
  { label: 'Salud', value: 763 },
]

export const MONTHLY_SPEND: { label: string; value: number }[] = [
  { label: 'Feb', value: 12_400 },
  { label: 'Mar', value: 14_100 },
  { label: 'Abr', value: 11_800 },
  { label: 'May', value: 15_600 },
  { label: 'Jun', value: 13_200 },
  { label: 'Jul', value: 9_780 },
]

export type CardKind = 'virtual' | 'física'

export interface WalletCard {
  id: string
  holder: string
  last4: string
  full: string
  expiry: string
  kind: CardKind
  frozen: boolean
  limit: number
  spent: number
  gradient: string
}

export const CARDS: WalletCard[] = [
  {
    id: 'card-virtual',
    holder: 'ANA PATRICIA GÓMEZ',
    last4: '5521',
    full: '4821 3390 7742 5521',
    expiry: '09/29',
    kind: 'virtual',
    frozen: false,
    limit: 15_000,
    spent: 4_260,
    gradient: 'from-primary via-primary/80 to-accent',
  },
  {
    id: 'card-fisica-1',
    holder: 'ANA PATRICIA GÓMEZ',
    last4: '0148',
    full: '5399 1182 6607 0148',
    expiry: '02/28',
    kind: 'física',
    frozen: false,
    limit: 25_000,
    spent: 18_950,
    gradient: 'from-slate-800 via-slate-700 to-slate-900',
  },
  {
    id: 'card-fisica-2',
    holder: 'ANA PATRICIA GÓMEZ',
    last4: '9902',
    full: '4000 1234 5566 9902',
    expiry: '11/27',
    kind: 'física',
    frozen: true,
    limit: 8_000,
    spent: 0,
    gradient: 'from-accent via-emerald-500 to-emerald-700',
  },
]

export interface KycStep {
  id: string
  label: string
  description: string
  done: boolean
}

export const KYC_STEPS: KycStep[] = [
  { id: 'id', label: 'Identificación oficial', description: 'INE, pasaporte o forma migratoria', done: true },
  { id: 'selfie', label: 'Verificación facial', description: 'Selfie en vivo para confirmar tu identidad', done: true },
  { id: 'address', label: 'Comprobante de domicilio', description: 'Recibo no mayor a 3 meses', done: false },
]

export interface NotificationEntry {
  id: string
  title: string
  description: string
  time: string
  read: boolean
}

export const NOTIFICATIONS: NotificationEntry[] = [
  { id: 'n1', title: 'Cargo grande detectado', description: 'Walmart · $1,204.90 MXN', time: 'hace 4 h', read: false },
  { id: 'n2', title: 'Saldo bajo', description: 'Cuenta en dólares por debajo de $2,500 USD', time: 'hace 1 d', read: false },
  { id: 'n3', title: 'Tarjeta congelada', description: 'Tarjeta física •••• 9902', time: 'hace 2 d', read: true },
  { id: 'n4', title: 'Verificación pendiente', description: 'Falta el comprobante de domicilio', time: 'hace 3 d', read: true },
]

export function formatMXN(amount: number, currency: 'MXN' | 'USD' = 'MXN'): string {
  return new Intl.NumberFormat('es-MX', { style: 'currency', currency }).format(amount)
}

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('es-MX', { day: '2-digit', month: 'short' }).format(new Date(iso))
}
