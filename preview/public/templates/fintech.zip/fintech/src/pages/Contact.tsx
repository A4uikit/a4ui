import { Badge, Button, Card, Input, Section, Textarea } from '@a4ui/core'
import { AtSign, Clock, Mail, MapPin, MessageCircle, Phone, ShieldCheck } from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const TOPICS = [
  { value: 'soporte', label: 'Soporte' },
  { value: 'ventas', label: 'Ventas' },
  { value: 'seguridad', label: 'Seguridad' },
] as const

export function Contact(): JSX.Element {
  const [name, setName] = createSignal('')
  const [contact, setContact] = createSignal('')
  const [topic, setTopic] = createSignal<(typeof TOPICS)[number]['value']>('soporte')
  const [message, setMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <Section>
      <div class="mb-10 text-center">
        <Badge tone="info" class="mb-4">
          <MessageCircle class="h-3.5 w-3.5" /> Contacto
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Estamos para ayudarte</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Dudas sobre tu cuenta, ventas o un reporte de seguridad: escríbenos y te respondemos en menos de 24 horas.
        </p>
      </div>

      <div class="grid gap-10 lg:grid-cols-2">
        <div>
          <h2 class="text-2xl font-semibold tracking-tight">Información de contacto</h2>
          <ul class="mt-6 space-y-4 text-sm">
            <li class="flex items-center gap-3">
              <Phone class="h-5 w-5 text-primary" /> +52 55 4321 0000
            </li>
            <li class="flex items-center gap-3">
              <Mail class="h-5 w-5 text-primary" /> hola@nuvo.mx
            </li>
            <li class="flex items-center gap-3">
              <MapPin class="h-5 w-5 text-primary" /> Torre Reforma, Av. Paseo de la Reforma 483, CDMX
            </li>
            <li class="flex items-center gap-3">
              <Clock class="h-5 w-5 text-primary" /> Soporte 24/7 · Oficinas Lun–Vie 9:00–18:00
            </li>
            <li class="flex items-center gap-3">
              <ShieldCheck class="h-5 w-5 text-accent" /> Reportes de seguridad: seguridad@nuvo.mx
            </li>
          </ul>
          <div class="mt-6 flex gap-1 text-muted-foreground">
            <a
              href="#"
              aria-label="Redes sociales"
              class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"
            >
              <AtSign class="h-5 w-5" />
            </a>
            <a
              href="#"
              aria-label="Chat"
              class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"
            >
              <MessageCircle class="h-5 w-5" />
            </a>
          </div>
          <div class="mt-8 flex h-48 items-center justify-center rounded-2xl border border-dashed border-border text-muted-foreground">
            <MapPin class="mr-2 h-5 w-5" /> Mapa de ubicación
          </div>
        </div>

        <Card glass class="p-6">
          {sent() ? (
            <div class="flex h-full flex-col items-center justify-center py-10 text-center">
              <Badge tone="success" pulse class="mb-3">
                Enviado
              </Badge>
              <p class="text-lg font-medium">¡Gracias, {name() || 'ya casi terminamos'}!</p>
              <p class="mt-1 text-sm text-muted-foreground">Nuestro equipo te contacta lo antes posible.</p>
            </div>
          ) : (
            <form class="space-y-4" onSubmit={submit}>
              <div>
                <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                <Input id="contact-name" value={name()} onInput={setName} placeholder="Tu nombre" required />
              </div>
              <div>
                <label for="contact-method" class="mb-1 block text-sm font-medium">Teléfono o correo</label>
                <Input id="contact-method" value={contact()} onInput={setContact} placeholder="55 0000 0000 o tú@correo.com" required />
              </div>
              <div>
                <label for="contact-topic" class="mb-1 block text-sm font-medium">Tema</label>
                <select
                  id="contact-topic"
                  value={topic()}
                  onInput={(e) => setTopic(e.currentTarget.value as (typeof TOPICS)[number]['value'])}
                  class="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <For each={TOPICS}>{(t) => <option value={t.value}>{t.label}</option>}</For>
                </select>
              </div>
              <div>
                <label for="contact-message" class="mb-1 block text-sm font-medium">Mensaje</label>
                <Textarea id="contact-message" value={message()} onInput={setMessage} placeholder="Cuéntanos qué necesitas…" rows={4} />
              </div>
              <Button ripple type="submit" class="w-full">
                Enviar mensaje
              </Button>
            </form>
          )}
        </Card>
      </div>
    </Section>
  )
}
