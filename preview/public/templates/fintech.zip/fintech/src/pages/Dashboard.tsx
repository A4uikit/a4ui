import {
  Alert,
  Badge,
  Button,
  Card,
  DataGrid,
  type DataGridColumn,
  Empty,
  Expandable,
  Modal,
  Progress,
  Select,
  Skeleton,
  Stat,
  Stepper,
  Input,
} from '@a4ui/core'
import { BarChart, DonutChart, Sparkline } from '@a4ui/core/charts'
import {
  CheckCircle2,
  Circle,
  CreditCard,
  ShieldAlert,
  ShieldCheck,
  TrendingUp,
  Wallet,
} from 'lucide-solid'
import { createMemo, createSignal, For, onMount, Show, type JSX } from 'solid-js'

import {
  ACCOUNTS,
  CATEGORIES,
  formatDate,
  formatMXN,
  KYC_STEPS,
  MONTHLY_SPEND,
  SPENDING_BY_CATEGORY,
  TRANSACTIONS,
  type Transaction,
  type TransactionStatus,
} from '../lib/data'

const USD_TO_MXN = 18.5
const DONUT_TONES = ['primary', 'accent', 'destructive', 'emit', 'received', 'net'] as const

const STATUS_TONE: Record<TransactionStatus, 'success' | 'warning' | 'danger'> = {
  completada: 'success',
  pendiente: 'warning',
  rechazada: 'danger',
}

export function Dashboard(): JSX.Element {
  const [loading, setLoading] = createSignal(true)
  onMount(() => {
    setTimeout(() => setLoading(false), 550)
  })

  const netWorth = createMemo(() =>
    ACCOUNTS.reduce((sum, a) => sum + (a.currency === 'USD' ? a.balance * USD_TO_MXN : a.balance), 0),
  )

  // Transactions filtering
  const [search, setSearch] = createSignal('')
  const [category, setCategory] = createSignal<string>('Todas')

  const filteredTransactions = createMemo(() =>
    TRANSACTIONS.filter((t) => {
      const matchesCategory = category() === 'Todas' || t.category === category()
      const matchesSearch = t.merchant.toLowerCase().includes(search().toLowerCase())
      return matchesCategory && matchesSearch
    }),
  )

  const columns: DataGridColumn[] = [
    { key: 'date', header: 'Fecha', sortable: true, render: (row) => <span>{formatDate((row as unknown as Transaction).date)}</span> },
    {
      key: 'merchant',
      header: 'Comercio',
      sortable: true,
      render: (row) => {
        const t = row as unknown as Transaction
        return (
          <Expandable
            size="dialog"
            maxWidth={420}
            panelClass="overflow-hidden rounded-2xl"
            trigger={<span class="cursor-pointer font-medium underline-offset-2 hover:text-primary hover:underline">{t.merchant}</span>}
          >
            <div class="p-6">
              <h3 class="text-lg font-semibold">{t.merchant}</h3>
              <dl class="mt-4 space-y-3 text-sm">
                <div class="flex items-center justify-between">
                  <dt class="text-muted-foreground">Fecha</dt>
                  <dd>{formatDate(t.date)}</dd>
                </div>
                <div class="flex items-center justify-between">
                  <dt class="text-muted-foreground">Categoría</dt>
                  <dd><Badge tone="neutral">{t.category}</Badge></dd>
                </div>
                <div class="flex items-center justify-between">
                  <dt class="text-muted-foreground">Monto</dt>
                  <dd class={`tabular-nums font-medium ${t.amount >= 0 ? 'text-accent' : 'text-foreground'}`}>
                    {t.amount >= 0 ? '+' : ''}
                    {formatMXN(t.amount)}
                  </dd>
                </div>
                <div class="flex items-center justify-between">
                  <dt class="text-muted-foreground">Estado</dt>
                  <dd><Badge tone={STATUS_TONE[t.status]}>{t.status}</Badge></dd>
                </div>
              </dl>
            </div>
          </Expandable>
        )
      },
    },
    {
      key: 'category',
      header: 'Categoría',
      sortable: true,
      render: (row) => <Badge tone="neutral">{(row as unknown as Transaction).category}</Badge>,
    },
    {
      key: 'amount',
      header: 'Monto',
      sortable: true,
      render: (row) => {
        const t = row as unknown as Transaction
        return (
          <span class={`tabular-nums font-medium ${t.amount >= 0 ? 'text-accent' : 'text-foreground'}`}>
            {t.amount >= 0 ? '+' : ''}
            {formatMXN(t.amount)}
          </span>
        )
      },
    },
    {
      key: 'status',
      header: 'Estado',
      sortable: true,
      render: (row) => {
        const t = row as unknown as Transaction
        return <Badge tone={STATUS_TONE[t.status]}>{t.status}</Badge>
      },
    },
  ]

  // KYC verification state
  const [kycSteps, setKycSteps] = createSignal(KYC_STEPS)
  const [kycOpen, setKycOpen] = createSignal(false)
  const doneCount = createMemo(() => kycSteps().filter((s) => s.done).length)
  const kycPct = createMemo(() => Math.round((doneCount() / kycSteps().length) * 100))
  const kycComplete = createMemo(() => doneCount() === kycSteps().length)

  const completeAddressStep = (): void => {
    setKycSteps((prev) => prev.map((s) => (s.id === 'address' ? { ...s, done: true } : s)))
    setKycOpen(false)
  }

  return (
    <div class="mx-auto w-full max-w-6xl px-5 py-8">
      <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight">Hola, Ana</h1>
          <p class="text-sm text-muted-foreground">Este es el resumen de tus finanzas hoy.</p>
        </div>
        <Show
          when={!kycComplete()}
          fallback={
            <Badge tone="success">
              <ShieldCheck class="h-3.5 w-3.5" /> Identidad verificada
            </Badge>
          }
        >
          <Badge tone="warning" pulse>
            <ShieldAlert class="h-3.5 w-3.5" /> Verificación pendiente
          </Badge>
        </Show>
      </div>

      {/* Net worth + accounts */}
      <Show
        when={!loading()}
        fallback={
          <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <For each={[0, 1, 2, 3]}>{() => <Skeleton shimmer class="h-32 w-full rounded-2xl" />}</For>
          </div>
        }
      >
        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card glass class="p-5">
            <Stat label="Patrimonio total" value={netWorth()} format={(n) => formatMXN(n)} tone="primary" icon={<Wallet class="h-5 w-5" />} />
          </Card>
          <For each={ACCOUNTS}>
            {(account, i) => (
              <Card glass tilt spotlight class="p-5">
                <Stat label={account.label} value={account.balance} format={(n) => formatMXN(n, account.currency)} tone="neutral" delay={(i() + 1) * 0.05} />
                <p class="mt-1 text-xs text-muted-foreground">{account.number}</p>
                <div class="mt-3">
                  <Sparkline data={account.trend} tone="primary" area width={200} height={36} />
                </div>
              </Card>
            )}
          </For>
        </div>
      </Show>

      {/* KYC banner */}
      <div class="mt-6">
        <Show when={!kycComplete()}>
          <Alert tone="warning" title="Verifica tu identidad para desbloquear todas las funciones">
            <div class="mt-3">
              <Progress value={kycPct()} max={100} label="Progreso de verificación" />
            </div>
            <div class="mt-4">
              <Button ripple onClick={() => setKycOpen(true)}>
                Verificar identidad
              </Button>
            </div>
          </Alert>
        </Show>
      </div>

      {/* Spending charts */}
      <div class="mt-8 grid gap-5 lg:grid-cols-2">
        <Card glass class="p-6">
          <h2 class="mb-4 text-lg font-semibold">Gasto por categoría</h2>
          <Show when={!loading()} fallback={<Skeleton shimmer class="mx-auto h-40 w-40 rounded-full" />}>
            <div class="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
              <DonutChart
                data={SPENDING_BY_CATEGORY.map((c, i) => ({ ...c, tone: DONUT_TONES[i % DONUT_TONES.length] }))}
                size={168}
              />
              <ul class="w-full space-y-2 text-sm">
                <For each={SPENDING_BY_CATEGORY}>
                  {(c) => (
                    <li class="flex items-center justify-between text-muted-foreground">
                      <span>{c.label}</span>
                      <span class="tabular-nums font-medium text-foreground">{formatMXN(c.value)}</span>
                    </li>
                  )}
                </For>
              </ul>
            </div>
          </Show>
        </Card>

        <Card glass class="p-6">
          <h2 class="mb-4 flex items-center gap-2 text-lg font-semibold">
            <TrendingUp class="h-4 w-4 text-primary" /> Gasto mensual
          </h2>
          <Show when={!loading()} fallback={<Skeleton shimmer class="h-40 w-full" />}>
            <BarChart data={MONTHLY_SPEND} tone="primary" height={180} />
          </Show>
        </Card>
      </div>

      {/* Transactions */}
      <Card glass class="mt-8 p-6">
        <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h2 class="text-lg font-semibold">Movimientos</h2>
          <div class="flex flex-wrap items-center gap-3">
            <Input value={search()} onInput={setSearch} placeholder="Buscar comercio…" aria-label="Buscar comercio" class="w-48" />
            <Select value={category()} onChange={setCategory} aria-label="Filtrar por categoría" class="w-40">
              <option value="Todas">Todas las categorías</option>
              <For each={CATEGORIES}>{(c) => <option value={c}>{c}</option>}</For>
            </Select>
          </div>
        </div>

        <Show
          when={!loading()}
          fallback={
            <div class="space-y-2">
              <For each={[0, 1, 2, 3, 4]}>{() => <Skeleton shimmer class="h-10 w-full" />}</For>
            </div>
          }
        >
          <Show
            when={filteredTransactions().length > 0}
            fallback={<Empty title="Sin movimientos" description="No encontramos transacciones con esos filtros." />}
          >
            <DataGrid
              columns={columns}
              rows={filteredTransactions() as unknown as Record<string, unknown>[]}
              pageSize={8}
              filterable={false}
            />
          </Show>
        </Show>
      </Card>

      {/* KYC verification modal */}
      <Modal open={kycOpen()} onOpenChange={setKycOpen} variant="center" title="Verificación de identidad">
        <Stepper
          orientation="vertical"
          active={doneCount()}
          steps={kycSteps().map((s) => ({ label: s.label, description: s.description }))}
        />
        <ul class="mt-6 space-y-3">
          <For each={kycSteps()}>
            {(s) => (
              <li class="flex items-center gap-3 text-sm">
                {s.done ? <CheckCircle2 class="h-4 w-4 text-accent" /> : <Circle class="h-4 w-4 text-muted-foreground" />}
                <span class={s.done ? 'text-foreground' : 'text-muted-foreground'}>{s.label}</span>
              </li>
            )}
          </For>
        </ul>
        <Show when={!kycComplete()}>
          <div class="mt-6">
            <p class="mb-2 text-sm text-muted-foreground">
              Último paso: sube tu comprobante de domicilio para terminar la verificación.
            </p>
            <Button ripple onClick={completeAddressStep}>
              Subir comprobante
            </Button>
          </div>
        </Show>
      </Modal>

      <div class="mt-8 flex items-center gap-2 text-xs text-muted-foreground">
        <CreditCard class="h-3.5 w-3.5" /> ¿Buscas tus tarjetas? Ve a la sección Tarjetas en el menú lateral.
      </div>
    </div>
  )
}
