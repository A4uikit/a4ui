import { Badge, Button, Card, HoldToConfirm, Meter, Modal, NumberInput, Switch } from '@a4ui/core'
import { CreditCard, Eye, EyeOff, Plus, ShieldCheck, Snowflake, Wallet } from 'lucide-solid'
import { createMemo, createSignal, For, Show, type JSX } from 'solid-js'

import { CARDS, formatMXN, type WalletCard } from '../lib/data'

export function Cards(): JSX.Element {
  const [cards, setCards] = createSignal<WalletCard[]>(CARDS)
  const [revealed, setRevealed] = createSignal<Record<string, boolean>>({})
  const [detailId, setDetailId] = createSignal<string | null>(null)

  const toggleFrozen = (id: string, frozen: boolean): void => {
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, frozen } : c)))
  }

  const setLimit = (id: string, limit: number): void => {
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, limit } : c)))
  }

  const reveal = (id: string): void => {
    setRevealed((prev) => ({ ...prev, [id]: true }))
  }

  const hide = (id: string): void => {
    setRevealed((prev) => ({ ...prev, [id]: false }))
  }

  const detailCard = createMemo<WalletCard | undefined>(() => cards().find((c) => c.id === detailId()))

  return (
    <div class="mx-auto w-full max-w-6xl px-5 py-8">
      <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight">Tus tarjetas</h1>
          <p class="text-sm text-muted-foreground">Congela, ajusta límites y consulta el detalle de cada tarjeta.</p>
        </div>
        <Button variant="outline" class="gap-2">
          <Plus class="h-4 w-4" /> Solicitar tarjeta física
        </Button>
      </div>

      <div class="grid gap-6 lg:grid-cols-2">
        <For each={cards()}>
          {(card) => (
            <Card class="border-0 p-0">
              {/* Card visual */}
              <div class={`relative overflow-hidden rounded-t-2xl bg-gradient-to-br p-6 ${card.gradient} ${card.frozen ? 'grayscale' : ''}`}>
                <div class="flex items-center justify-between">
                  <span class="flex items-center gap-2 text-sm font-medium text-white">
                    <Wallet class="h-4 w-4" /> Nuvo
                  </span>
                  <Badge tone={card.frozen ? 'neutral' : 'success'} class="border-white/30 !bg-white/15 !text-white">
                    {card.frozen ? 'Congelada' : `Tarjeta ${card.kind}`}
                  </Badge>
                </div>
                <p class="mt-10 font-mono text-xl tracking-widest text-white tabular-nums">
                  {revealed()[card.id] ? card.full : `•••• •••• •••• ${card.last4}`}
                </p>
                <div class="mt-6 flex items-center justify-between text-xs text-white/80">
                  <span>{card.holder}</span>
                  <span>{card.expiry}</span>
                </div>
                {card.frozen && (
                  <div class="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-black/40 px-2 py-1 text-[11px] text-white">
                    <Snowflake class="h-3 w-3" /> Congelada
                  </div>
                )}
              </div>

              {/* Controls */}
              <div class="space-y-4 p-6">
                <Switch checked={card.frozen} onChange={(v) => toggleFrozen(card.id, v)} label={card.frozen ? 'Descongelar tarjeta' : 'Congelar tarjeta'} />

                <Meter value={card.spent} max={card.limit} label={`Uso del límite · ${formatMXN(card.spent)} de ${formatMXN(card.limit)}`} />

                <div class="flex items-center gap-3">
                  <Button variant="outline" class="gap-2" onClick={() => setDetailId(card.id)}>
                    <CreditCard class="h-4 w-4" /> Ver detalles
                  </Button>
                  <Button
                    variant="ghost"
                    class="gap-2"
                    onClick={() => (revealed()[card.id] ? hide(card.id) : reveal(card.id))}
                  >
                    {revealed()[card.id] ? <EyeOff class="h-4 w-4" /> : <Eye class="h-4 w-4" />}
                    {revealed()[card.id] ? 'Ocultar número' : 'Ver número'}
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </For>
      </div>

      <Modal open={detailId() !== null} onOpenChange={(open) => !open && setDetailId(null)} variant="drawer" title="Detalle de tarjeta">
        <Show when={detailCard()}>
          {(card) => (
            <div class="space-y-6">
              <div class={`rounded-2xl bg-gradient-to-br p-6 ${card().gradient}`}>
                <p class="font-mono text-lg tracking-widest text-white tabular-nums">
                  {revealed()[card().id] ? card().full : `•••• •••• •••• ${card().last4}`}
                </p>
                <div class="mt-4 flex items-center justify-between text-xs text-white/80">
                  <span>{card().holder}</span>
                  <span>{card().expiry}</span>
                </div>
              </div>

              <Show when={!revealed()[card().id]}>
                <div>
                  <p class="mb-2 text-sm text-muted-foreground">Confirma para revelar el número completo.</p>
                  <HoldToConfirm label="Mantén presionado para revelar" holdMs={1200} onConfirm={() => reveal(card().id)} />
                </div>
              </Show>

              <div>
                <label class="mb-2 block text-sm font-medium">Límite de gasto mensual</label>
                <NumberInput value={card().limit} onChange={(v) => setLimit(card().id, v)} min={1_000} max={100_000} />
                <p class="mt-1 text-xs text-muted-foreground">{formatMXN(card().limit)} MXN por mes</p>
              </div>

              <div class="flex items-center gap-2 rounded-xl border border-border/60 bg-muted/40 p-3 text-xs text-muted-foreground">
                <ShieldCheck class="h-4 w-4 text-accent" /> Esta tarjeta está protegida con autenticación en cada compra en línea.
              </div>
            </div>
          )}
        </Show>
      </Modal>
    </div>
  )
}
