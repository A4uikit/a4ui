import {
  Accordion,
  Badge,
  Button,
  Card,
  Carousel,
  Descriptions,
  GradientText,
  List,
  Magnetic,
  Marquee,
  Parallax,
  PricingTable,
  Rating,
  RingProgress,
  ScrollProgress,
  Section,
  Stat,
  Stepper,
  TextReveal,
} from '@a4ui/core'
import { Sparkline } from '@a4ui/core/charts'
import { useNavigate } from '@solidjs/router'
import {
  BadgeCheck,
  Banknote,
  Bell,
  CreditCard,
  ScanFace,
  Globe2,
  Lock,
  PiggyBank,
  ShieldCheck,
  Sparkles,
  Star,
  UserCheck,
  Users,
  Zap,
} from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { ACCOUNTS, formatMXN } from '../lib/data'

const FEATURES: { icon: JSX.Element; title: string; blurb: string }[] = [
  { icon: <Zap class="h-6 w-6" />, title: 'Transferencias instantáneas', blurb: 'SPEI en segundos, a cualquier banco, sin importar la hora.' },
  { icon: <Banknote class="h-6 w-6" />, title: 'Sin comisiones ocultas', blurb: 'Cuenta gratuita de por vida, sin mínimos ni letras chiquitas.' },
  { icon: <PiggyBank class="h-6 w-6" />, title: 'Insights de gasto', blurb: 'Categorizamos cada movimiento para que sepas en qué se va tu dinero.' },
  { icon: <CreditCard class="h-6 w-6" />, title: 'Tarjetas virtuales', blurb: 'Genera una tarjeta al instante para compras en línea, con límites propios.' },
  { icon: <Globe2 class="h-6 w-6" />, title: 'Multi-moneda', blurb: 'Maneja pesos y dólares en la misma app, sin comisión por conversión.' },
  { icon: <Bell class="h-6 w-6" />, title: 'Alertas en tiempo real', blurb: 'Te avisamos de cada cargo, depósito o intento sospechoso al instante.' },
]

const TRUST_BADGES = [
  'Cifrado AES-256 de nivel bancario',
  'Protección de depósitos IPAB',
  'Autenticación biométrica',
  'Monitoreo de fraude 24/7',
  '99.9% de disponibilidad',
  'Identidad verificada en cada cuenta',
]

const SECURITY_ITEMS = [
  { label: 'Cifrado', value: 'AES-256 en tránsito y en reposo, igual que la banca tradicional.' },
  { label: 'Biometría', value: 'Face ID / huella para entrar a la app y confirmar pagos.' },
  { label: 'Monitoreo de fraude', value: 'Modelos que detectan movimientos inusuales en tiempo real.' },
  { label: 'Verificación de identidad', value: 'Validamos INE y una selfie antes de activar cualquier cuenta.' },
]

const STEPS = [
  { label: 'Regístrate', description: 'Crea tu cuenta en menos de 3 minutos' },
  { label: 'Verifica tu identidad', description: 'Sube tu identificación oficial y una selfie' },
  { label: 'Fondea tu cuenta', description: 'Transferencia, tarjeta o depósito en efectivo' },
  { label: 'Empieza a gastar', description: 'Tu tarjeta virtual queda lista al instante' },
]

const TESTIMONIALS = [
  { name: 'Renata C.', quote: 'Abrí mi cuenta desde el celular y en 10 minutos ya tenía tarjeta virtual. La verificación de identidad fue súper rápida.', rating: 5 },
  { name: 'Iván M.', quote: 'Las alertas en tiempo real me salvaron de un cargo que no reconocía. Lo congelé desde la app en segundos.', rating: 5 },
  { name: 'Daniela S.', quote: 'Por fin una cuenta sin comisiones raras. Los insights de gasto me ayudaron a ahorrar para mi viaje.', rating: 5 },
]

const FAQ = [
  { value: 'q1', title: '¿Nuvo cobra comisiones?', content: 'La cuenta básica es gratuita: sin anualidad, sin mínimos y sin comisión por manejo de cuenta. Nuvo Plus agrega beneficios por una cuota mensual opcional.' },
  { value: 'q2', title: '¿Cómo protegen mi dinero?', content: 'Usamos cifrado de nivel bancario, autenticación biométrica y monitoreo de fraude 24/7. Además, verificamos la identidad de cada cuenta antes de activarla.' },
  { value: 'q3', title: '¿Por qué me piden verificar mi identidad?', content: 'Es un requisito regulatorio (KYC) que nos permite prevenir fraude y lavado de dinero, y así mantener segura la comunidad de Nuvo.' },
  { value: 'q4', title: '¿En qué países funciona Nuvo?', content: 'Hoy operamos en México, con transferencias SPEI y una cuenta en dólares para quienes reciben pagos del extranjero.' },
  { value: 'q5', title: '¿Puedo tener tarjeta física y virtual?', content: 'Sí. La tarjeta virtual se genera al instante al abrir tu cuenta; la física llega a tu domicilio en 5 a 7 días hábiles.' },
]

export function Home(): JSX.Element {
  const navigate = useNavigate()
  const previewAccount = ACCOUNTS[0]

  return (
    <>
      <ScrollProgress />

      {/* Hero */}
      <div class="relative overflow-hidden">
        <div
          class="pointer-events-none absolute inset-0 -z-10 opacity-70"
          style={{
            background:
              'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.25), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.18), transparent 70%)',
          }}
        />
        <Section class="!py-24 lg:!py-32">
          <div class="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <Badge tone="info" class="mb-5">
                <Sparkles class="h-3.5 w-3.5" /> Banca digital para México
              </Badge>
              <h1 class="max-w-xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
                Tu dinero, <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">bajo tu control</GradientText>
              </h1>
              <p class="mt-5 max-w-lg text-lg text-muted-foreground">
                Cuenta, tarjetas y transferencias en una sola app. Sin comisiones ocultas, con identidad verificada y
                cifrado de nivel bancario en cada movimiento.
              </p>
              <div class="mt-8 flex flex-wrap items-center gap-3">
                <Magnetic strength={14}>
                  <Button ripple onClick={() => navigate('/dashboard')}>
                    Abrir una cuenta
                  </Button>
                </Magnetic>
                <Button variant="outline" onClick={() => navigate('/contact')}>
                  Ver cómo funciona
                </Button>
              </div>
            </div>

            <Parallax amount={60}>
              <Card glass glow class="p-4 shadow-2xl">
                <div class="overflow-hidden rounded-xl border border-border/60 bg-card">
                  <div class="flex items-center gap-1.5 border-b border-border/60 px-3 py-2">
                    <span class="h-2.5 w-2.5 rounded-full bg-destructive/70" />
                    <span class="h-2.5 w-2.5 rounded-full bg-accent/70" />
                    <span class="h-2.5 w-2.5 rounded-full bg-primary/70" />
                    <span class="ml-2 text-xs text-muted-foreground">app.nuvo.mx/dashboard</span>
                  </div>
                  <div class="p-5">
                    <Stat label={previewAccount.label} value={previewAccount.balance} format={(n) => formatMXN(n)} tone="primary" />
                    <div class="mt-3">
                      <Sparkline data={previewAccount.trend} area tone="accent" width={280} height={48} />
                    </div>
                    <div class="mt-4">
                      <List
                        stagger
                        items={[
                          { title: 'Nómina · ACME SA', description: 'Hoy', meta: <span class="text-accent">+{formatMXN(24500)}</span> },
                          { title: 'Rappi', description: 'Hoy', meta: <span class="text-muted-foreground">-{formatMXN(284.5)}</span> },
                          { title: 'Netflix', description: 'Ayer', meta: <span class="text-muted-foreground">-{formatMXN(219)}</span> },
                        ]}
                      />
                    </div>
                  </div>
                </div>
              </Card>
            </Parallax>
          </div>
        </Section>
      </div>

      {/* Trust bar */}
      <div class="border-y border-border/60 bg-muted/30 py-4">
        <Marquee speed={28}>
          <For each={TRUST_BADGES}>
            {(t) => (
              <span class="mx-4 flex items-center gap-2 text-sm text-muted-foreground">
                <ShieldCheck class="h-4 w-4 text-primary" /> {t}
              </span>
            )}
          </For>
        </Marquee>
      </div>

      {/* Impact stats */}
      <Section class="!py-14">
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <Card glass class="p-5">
            <Stat label="Cuentas activas" value={480_000} format={(n) => `${Math.round(n / 1000)}K+`} icon={<Users class="h-5 w-5" />} tone="primary" />
          </Card>
          <Card glass class="p-5">
            <Stat
              label="Gestionado en la app"
              value={2_100_000_000}
              format={(n) => `$${(n / 1_000_000_000).toFixed(1)}B`}
              icon={<Banknote class="h-5 w-5" />}
              tone="neutral"
              delay={0.05}
            />
          </Card>
          <Card glass class="p-5">
            <Stat label="Disponibilidad" value={99.9} format={(n) => `${n.toFixed(1)}%`} icon={<ShieldCheck class="h-5 w-5" />} tone="success" delay={0.1} />
          </Card>
          <Card glass class="p-5">
            <Stat label="Calificación en tiendas" value={4.8} format={(n) => n.toFixed(1)} icon={<Star class="h-5 w-5" />} tone="primary" delay={0.15} />
          </Card>
        </div>
      </Section>

      {/* Features */}
      <Section id="features">
        <div class="mb-10 text-center">
          <h2 class="mx-auto max-w-2xl text-3xl font-semibold tracking-tight">
            <TextReveal text="Todo lo que necesitas de un banco, sin las fricciones" onView />
          </h2>
          <p class="mt-3 text-muted-foreground">Diseñado para moverse tan rápido como tú.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={FEATURES}>
            {(f) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {f.icon}
                </div>
                <h3 class="text-lg font-semibold">{f.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{f.blurb}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Security & trust */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="grid items-center gap-12 lg:grid-cols-[1fr_auto]">
            <div>
              <Badge tone="success" class="mb-4">
                <Lock class="h-3.5 w-3.5" /> Seguridad primero
              </Badge>
              <h2 class="max-w-xl text-3xl font-semibold tracking-tight">Verificamos cada cuenta para proteger tu dinero</h2>
              <p class="mt-3 max-w-xl text-muted-foreground">
                Antes de activar cualquier cuenta, confirmamos tu identidad (KYC) con tu identificación oficial y una
                selfie en vivo. Así mantenemos fuera a los fraudes y protegemos a toda la comunidad Nuvo.
              </p>
              <div class="mt-6">
                <Descriptions columns={2} items={SECURITY_ITEMS} />
              </div>
              <div class="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
                <UserCheck class="h-4 w-4 text-accent" /> Identidad verificada requerida antes de tu primera transferencia
              </div>
            </div>
            <Card glass class="flex flex-col items-center gap-3 p-8 text-center">
              <RingProgress value={96} size={120} thickness={10} label={<ScanFace class="h-8 w-8 text-primary" />} />
              <p class="text-sm font-medium">Puntaje de seguridad</p>
              <p class="text-xs text-muted-foreground">Evaluado contra estándares de banca digital</p>
              <Badge tone="success">
                <BadgeCheck class="h-3.5 w-3.5" /> Excelente
              </Badge>
            </Card>
          </div>
        </Section>
      </div>

      {/* How it works */}
      <Section id="como-funciona">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Cómo funciona" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">De cero a tu primera transferencia en el mismo día.</p>
        </div>
        <Stepper steps={STEPS} active={1} />
      </Section>

      {/* Pricing */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section id="precios">
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Un plan para cada quien</h2>
            <p class="mt-2 text-muted-foreground">Empieza gratis, mejora cuando lo necesites.</p>
          </div>
          <div class="mx-auto max-w-3xl">
            <PricingTable
              tiers={[
                {
                  name: 'Nuvo',
                  price: 'Gratis',
                  description: 'Para el día a día',
                  features: ['Cuenta + tarjeta virtual', 'Transferencias SPEI ilimitadas', 'Alertas en tiempo real'],
                  cta: { label: 'Empezar gratis', onClick: () => navigate('/dashboard') },
                },
                {
                  name: 'Nuvo Plus',
                  price: '$99 MXN/mes',
                  description: 'Para quien quiere más control',
                  features: ['Todo lo de Nuvo', 'Tarjeta física sin costo', 'Cuenta en dólares', 'Soporte prioritario 24/7'],
                  highlighted: true,
                  cta: { label: 'Elegir Nuvo Plus', onClick: () => navigate('/dashboard') },
                },
              ]}
            />
          </div>
        </Section>
      </div>

      {/* Social proof */}
      <Section id="opiniones">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Lo que dicen nuestros usuarios</h2>
          <p class="mt-2 text-muted-foreground">4.8 de calificación promedio en tiendas de apps</p>
        </div>
        <div class="mx-auto max-w-2xl">
          <Carousel
            autoplayMs={5000}
            slides={TESTIMONIALS.map((t) => (
              <div class="px-2">
                <Card glass class="p-8 text-center">
                  <Rating value={t.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                  <p class="text-lg">&ldquo;{t.quote}&rdquo;</p>
                  <p class="mt-4 text-sm font-medium text-muted-foreground">— {t.name}</p>
                </Card>
              </div>
            ))}
          />
        </div>
      </Section>

      {/* FAQ */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mx-auto max-w-2xl">
            <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">Preguntas frecuentes</h2>
            <Accordion items={FAQ} />
          </div>
        </Section>
      </div>

      {/* Final CTA */}
      <Section class="text-center">
        <h2 class="mx-auto max-w-xl text-3xl font-semibold tracking-tight">Abre tu cuenta en minutos</h2>
        <p class="mx-auto mt-3 max-w-md text-muted-foreground">
          Sin filas, sin papeleo. Solo tu identificación, tu celular y tres minutos.
        </p>
        <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Button ripple onClick={() => navigate('/dashboard')}>
            Abrir una cuenta
          </Button>
          <Button variant="outline" onClick={() => navigate('/contact')}>
            Hablar con soporte
          </Button>
        </div>
      </Section>
    </>
  )
}
