import { Button, Section } from '@a4ui/core'
import { useNavigate } from '@solidjs/router'
import { Wallet } from 'lucide-solid'
import type { JSX } from 'solid-js'

export function NotFound(): JSX.Element {
  const navigate = useNavigate()

  return (
    <Section class="text-center">
      <Wallet class="mx-auto mb-4 h-10 w-10 text-primary" />
      <h1 class="text-3xl font-semibold tracking-tight">Página no encontrada</h1>
      <p class="mx-auto mt-3 max-w-md text-muted-foreground">
        Esta dirección no existe en Nuvo. Regresa al inicio o entra a tu cuenta.
      </p>
      <div class="mt-6 flex flex-wrap items-center justify-center gap-3">
        <Button ripple onClick={() => navigate('/')}>
          Volver al inicio
        </Button>
        <Button variant="outline" onClick={() => navigate('/dashboard')}>
          Ir a mi cuenta
        </Button>
      </div>
    </Section>
  )
}
