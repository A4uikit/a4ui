# Template: `computers` — Computer repair, parts store & CCTV installation

A multi-line tech company site covering three businesses under one brand:
computer repair services, a parts/hardware store, and surveillance camera
installation. Goal: each line has its own dedicated route so visitors self-
route to the right offering, with a unified home page tying them together.

## Structure

**Multi-route** (`@solidjs/router`), per CONVENTIONS.md. Routes:

- `/` — Home
- `/repair` — Repair services
- `/store` — Parts store (commerce)
- `/cameras` — Surveillance cameras
- `/contact` — Contact

Shared `AppShell` with top nav (route links) and footer across all routes.

## Sections by route

### `/` — Home

1. **Nav** — logo, route links (Repair / Store / Cameras / Contact), phone CTA. (`AppShell`, `Button`)
2. **Hero** — headline covering the three lines, primary CTA "Get a Quote", secondary "Shop Parts". Glass surface over themed backdrop. (`GradientText`, `Button` ripple)
3. **Three business lines** — one card per line (Repair / Store / Cameras) linking to its route, icon + blurb. (`Card` tilt/spotlight)
4. **Trust band** — years in business, devices repaired, cameras installed, clients served. (`Stat` count-up)
5. **Testimonials** — mixed reviews across the three lines. (`Carousel` swipe, `Rating`, `Avatar`)
6. **Footer**

### `/repair` — Repair services

1. **Services grid** — laptop/desktop repair, data recovery, virus removal, screen replacement, upgrades, diagnostics. (`Card` tilt/spotlight, lucide icons)
2. **Pricing / diagnostic tiers** — flat-rate diagnostic + tiered repair packages. (`Card`, `PriceTag`, `Badge` "Most requested")
3. **How it works** — drop-off → diagnostic → quote approval → repair → pickup. (`Stepper`)
4. **Turnaround estimator** — device type `Select` → estimated days via `Meter`/`RingProgress`.
5. **Repair request form** — device type, issue description, name, phone, preferred contact. (`Form`, `Select`, `Textarea`, `FileUpload` for photos of the issue, `Button` ripple)
6. **FAQ** — warranty, data privacy, walk-in vs appointment. (`Accordion`)

### `/store` — Parts store

1. **Filter sidebar** — category (RAM, storage, GPU, peripherals, prebuilt), price range, brand. (`FilterGroup`, `Slider`)
2. **Product grid** — parts & components with price, stock, quick-add. (`ProductGrid`, `ProductCard` tilt/spotlight, `PriceTag`, `Empty` for no-results state)
3. **Product quick view** — spec table, quantity, add to cart. (`Modal` or `Drawer`, `QuantityStepper`, `Descriptions`)
4. **Cart** — line items, totals, checkout CTA. (`CartLine`, `CartSummary`, `Drawer`, `flyToCart` animation on add)
5. **Stock / shipping notices**. (`Alert`, `Skeleton` shimmer while loading grid)

### `/cameras` — Surveillance cameras

1. **Systems overview** — indoor/outdoor, wired/wireless, resolution tiers, NVR/cloud storage options. (`Card` tilt/spotlight, `Tabs` to switch category)
2. **Package comparison** — Basic / Standard / Pro bundles (# of cameras, storage, monitoring). (`Table` or `Card` + `PriceTag`, `Badge` "Recommended")
3. **Installation process** — site survey → placement plan → install → walkthrough/training. (`Timeline`)
4. **Coverage visualizer placeholder** — simple diagram/image of camera placement on a property layout. (`Image` blurUp)
5. **Camera-system quote flow** — property type, # of entry points/cameras needed `NumberInput`, indoor/outdoor mix `Checkbox` group, monitoring preference `Radio`, contact info, submit for custom quote. (`Form`, `NumberInput`, `Checkbox`, `Radio`, `Stepper` for multi-step form, `Button` ripple, `Toast` on submit)
6. **FAQ** — monitoring fees, footage retention, permits. (`Accordion`)

### `/contact` — Contact

1. **Contact form** — name, email/phone, subject (`Select`: repair / parts / cameras / general), message. (`Form`, `Input`, `Select`, `Textarea`, `Button` ripple)
2. **Contact info** — phone, email, address, hours, map placeholder, social links. (`Descriptions`, `Card`)
3. **Footer**

## Custom theme

Tech/precision mood: deep slate/graphite primary, electric-blue accent
(circuit-board feel), tighter radius than the service-vertical templates to
read as "technical" rather than "friendly." Override `--primary` / `--accent`
/ `--radius-*` tokens; keep WCAG AA in light + dark, especially for the
electric-blue accent on dark backgrounds.

## Animation / parallax

- `Parallax` on the home hero backdrop (subtle circuit/hardware texture).
- `ScrollProgress` on longer routes (`/repair`, `/cameras`).
- `TextReveal` / `FillText` on section headings across routes.
- `GradientText` on hero headline, `ScrambleText` on the trust-band stat labels.
- `TiltCard` + `Spotlight` on service cards and `ProductCard`s.
- `Magnetic` + `Ripple` on primary CTAs ("Get a Quote", "Add to Cart").
- `flyToCart` on add-to-cart interactions in `/store`.
- `List` stagger on the product grid and services grid entrance.
- `Skeleton` shimmer while product grid loads; `Image` blurUp for product/camera images.
- `Curtain` transition between route changes (repair ↔ store ↔ cameras) for continuity.
- Respect `prefers-reduced-motion` throughout (default A4ui behavior).

## Reusable candidates

- **Multi-step quote form** (property/device details → preferences → contact → submit, with `Stepper`) — reusable across cameras, hvac, towing, any custom-quote vertical.
- **"Three business lines" home dispatcher card row** (icon + blurb + route link) — reusable pattern for any multi-line-of-business template.
- **Package comparison block** (`Table`/`Card` + `PriceTag` + "Recommended" `Badge`) — already echoes taller's pricing tiers; worth formalizing as a shared `PricingTiers` composite.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset + `@solidjs/router`)
- [ ] Custom `computers` theme tokens
- [ ] Route shell: `AppShell` nav + footer shared across routes
- [ ] `/` Home (hero, three business-line cards, trust band, testimonials)
- [ ] `/repair` (services grid, pricing, how-it-works, turnaround estimator, request form, FAQ)
- [ ] `/store` (filter sidebar, product grid, quick view, cart, stock alerts)
- [ ] `/cameras` (systems overview, package comparison, install timeline, quote flow, FAQ)
- [ ] `/contact` (form + contact info + footer)
- [ ] Cart state (add/remove/quantity, `flyToCart` animation, `CartSummary` totals)
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
