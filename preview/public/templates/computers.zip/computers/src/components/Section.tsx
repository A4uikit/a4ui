import type { JSX } from 'solid-js'

export function Section(props: { id?: string; class?: string; children: JSX.Element }): JSX.Element {
  return (
    <section id={props.id} class={`mx-auto w-full max-w-6xl px-5 py-20 ${props.class ?? ''}`}>
      {props.children}
    </section>
  )
}
