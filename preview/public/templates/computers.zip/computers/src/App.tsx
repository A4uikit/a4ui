import { Badge, Button, ScrollProgress } from '@a4ui/core'
import { A, Route, Router } from '@solidjs/router'
import { Cpu, Phone, ShoppingCart } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { cart } from './lib/cart'
import { Cameras } from './pages/Cameras'
import { Contact } from './pages/Contact'
import { Home } from './pages/Home'
import { NotFound } from './pages/NotFound'
import { Repair } from './pages/Repair'
import { Store } from './pages/Store'

const NAV = [
  { href: '/repair', label: 'Reparación' },
  { href: '/store', label: 'Tienda' },
  { href: '/cameras', label: 'Cámaras' },
  { href: '/contact', label: 'Contacto' },
]

function Layout(props: { children?: JSX.Element }): JSX.Element {
  return (
    <div class="min-h-screen bg-background text-foreground">
      <ScrollProgress />
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <A href="/" class="flex items-center gap-2 font-semibold tracking-tight">
            <Cpu class="h-5 w-5 text-primary" /> TecnoFix
          </A>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>
              {(n) => (
                <A href={n.href} class="transition-colors hover:text-foreground" activeClass="text-foreground">
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <div class="flex items-center gap-4">
            <A
              href="/store"
              class="relative flex h-6 w-6 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
              aria-label="Carrito"
            >
              <ShoppingCart class="h-5 w-5" />
              {cart.count() > 0 && (
                <Badge tone="info" class="absolute -right-2.5 -top-2.5 px-1.5 py-0 text-[10px]">
                  {cart.count()}
                </Badge>
              )}
            </A>
            <Button ripple class="gap-2" onClick={() => (window.location.href = 'tel:+525512345678')}>
              <Phone class="h-4 w-4" /> Llamar
            </Button>
          </div>
        </div>
      </header>

      {props.children}

      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2">
            <Cpu class="h-4 w-4 text-primary" /> TecnoFix · Reparación, refacciones & videovigilancia
          </span>
          <nav class="flex items-center gap-5">
            <For each={NAV}>{(n) => <A href={n.href} class="transition-colors hover:text-foreground">{n.label}</A>}</For>
          </nav>
          <span>© 2026 TecnoFix. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}

export function App(): JSX.Element {
  return (
    <Router root={Layout}>
      <Route path="/" component={Home} />
      <Route path="/repair" component={Repair} />
      <Route path="/store" component={Store} />
      <Route path="/cameras" component={Cameras} />
      <Route path="/contact" component={Contact} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}
