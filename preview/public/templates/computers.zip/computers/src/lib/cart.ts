import { createCart } from '@a4ui/core/commerce'

export interface Product {
  id: string
  name: string
  category: string
  price: number
  stock: number
  spec: string
}

export const cart = createCart<Product>()

export function formatPrice(n: number): string {
  return `$${n.toLocaleString('es-MX')}`
}
