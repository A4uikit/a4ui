import { Badge, Button, Card, Input, Textarea } from '@a4ui/core'
import { AtSign, Clock, Mail, MapPin, MessageCircle, Phone } from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

import { Section } from '../components/Section'

const SUBJECTS = [
  { value: 'reparacion', label: 'Reparación' },
  { value: 'refacciones', label: 'Refacciones' },
  { value: 'camaras', label: 'Cámaras' },
  { value: 'general', label: 'General' },
] as const

export function Contact(): JSX.Element {
  const [name, setName] = createSignal('')
  const [contact, setContact] = createSignal('')
  const [subject, setSubject] = createSignal<(typeof SUBJECTS)[number]['value']>('general')
  const [message, setMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <Section>
      <div class="mb-10 text-center">
        <Badge tone="info" class="mb-4">
          <MessageCircle class="h-3.5 w-3.5" /> Contacto
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Hablemos de tu proyecto</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Reparación, refacciones o cámaras: escríbenos y te respondemos el mismo día hábil.
        </p>
      </div>

      <div class="grid gap-10 lg:grid-cols-2">
        <div>
          <h2 class="text-2xl font-semibold tracking-tight">Información de contacto</h2>
          <ul class="mt-6 space-y-4 text-sm">
            <li class="flex items-center gap-3">
              <Phone class="h-5 w-5 text-primary" /> +52 55 1234 5678
            </li>
            <li class="flex items-center gap-3">
              <Mail class="h-5 w-5 text-primary" /> hola@tecnofix.mx
            </li>
            <li class="flex items-center gap-3">
              <MapPin class="h-5 w-5 text-primary" /> Av. Insurgentes Sur 1234, CDMX
            </li>
            <li class="flex items-center gap-3">
              <Clock class="h-5 w-5 text-primary" /> Lun–Sáb · 9:00–19:00
            </li>
          </ul>
          <div class="mt-6 flex gap-1 text-muted-foreground">
            <a href="#" aria-label="Redes sociales" class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-primary/10 hover:text-primary">
              <AtSign class="h-5 w-5" />
            </a>
            <a href="#" aria-label="WhatsApp" class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-primary/10 hover:text-primary">
              <MessageCircle class="h-5 w-5" />
            </a>
          </div>
          <div class="mt-8 flex h-48 items-center justify-center rounded-2xl border border-dashed border-border text-muted-foreground">
            <MapPin class="mr-2 h-5 w-5" /> Mapa de ubicación
          </div>
        </div>

        <Card glass class="p-6">
          {sent() ? (
            <div class="flex h-full flex-col items-center justify-center py-10 text-center">
              <Badge tone="success" pulse class="mb-3">
                Enviado
              </Badge>
              <p class="text-lg font-medium">¡Gracias, {name() || 'nos vemos pronto'}!</p>
              <p class="mt-1 text-sm text-muted-foreground">Te contactamos lo antes posible.</p>
            </div>
          ) : (
            <form class="space-y-4" onSubmit={submit}>
              <div>
                <label class="mb-1 block text-sm font-medium">Nombre</label>
                <Input value={name()} onInput={setName} placeholder="Tu nombre" aria-label="Nombre" required />
              </div>
              <div>
                <label class="mb-1 block text-sm font-medium">Teléfono o correo</label>
                <Input value={contact()} onInput={setContact} placeholder="55 0000 0000 o tú@correo.com" aria-label="Teléfono o correo" required />
              </div>
              <div>
                <label class="mb-1 block text-sm font-medium">Asunto</label>
                <select
                  value={subject()}
                  onInput={(e) => setSubject(e.currentTarget.value as (typeof SUBJECTS)[number]['value'])}
                  aria-label="Asunto"
                  class="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <For each={SUBJECTS}>{(s) => <option value={s.value}>{s.label}</option>}</For>
                </select>
              </div>
              <div>
                <label class="mb-1 block text-sm font-medium">Mensaje</label>
                <Textarea value={message()} onInput={setMessage} placeholder="Cuéntanos qué necesitas…" aria-label="Mensaje" rows={4} />
              </div>
              <Button ripple type="submit" class="w-full">
                Enviar mensaje
              </Button>
            </form>
          )}
        </Card>
      </div>
    </Section>
  )
}
