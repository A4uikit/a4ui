import { Accordion, Badge, Button, Card, Input } from '@a4ui/core'
import { Camera, Cloud, HardDrive, MonitorSmartphone, ShieldCheck, Video, Wifi } from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

import { Section } from '../components/Section'

const SYSTEMS: { icon: JSX.Element; title: string; blurb: string }[] = [
  { icon: <Camera class="h-6 w-6" />, title: 'Interior', blurb: 'Cámaras discretas para casa, oficina o bodega.' },
  { icon: <ShieldCheck class="h-6 w-6" />, title: 'Exterior', blurb: 'Resistentes a intemperie, visión nocturna incluida.' },
  { icon: <Wifi class="h-6 w-6" />, title: 'Cableada o inalámbrica', blurb: 'Elegimos la instalación según tu inmueble y presupuesto.' },
  { icon: <MonitorSmartphone class="h-6 w-6" />, title: 'Alta resolución', blurb: 'Desde 2MP hasta 4K, según el nivel de detalle que necesites.' },
  { icon: <HardDrive class="h-6 w-6" />, title: 'Grabación en NVR', blurb: 'Almacenamiento local con retención configurable.' },
  { icon: <Cloud class="h-6 w-6" />, title: 'Respaldo en la nube', blurb: 'Accede a tus grabaciones desde cualquier lugar.' },
]

const PACKAGES = [
  {
    name: 'Básico',
    price: '$6,500',
    features: ['4 cámaras', 'Grabación local 7 días', 'Visión nocturna', 'Instalación incluida'],
    recommended: false,
  },
  {
    name: 'Estándar',
    price: '$12,900',
    features: ['8 cámaras', 'NVR + monitoreo remoto', 'Grabación 30 días', 'Instalación y capacitación'],
    recommended: true,
  },
  {
    name: 'Pro',
    price: '$21,500',
    features: ['16 cámaras', 'Detección inteligente', 'Respaldo en la nube 90 días', 'Monitoreo remoto 24/7'],
    recommended: false,
  },
]

const STEPS = [
  { title: 'Visita de sitio', blurb: 'Evaluamos accesos y puntos ciegos en tu propiedad.' },
  { title: 'Plan de colocación', blurb: 'Definimos dónde va cada cámara y el tipo de cableado.' },
  { title: 'Instalación', blurb: 'Montamos el sistema completo en una sola visita.' },
  { title: 'Capacitación', blurb: 'Te enseñamos a usar la app y a revisar tus grabaciones.' },
]

const FAQ = [
  { value: 'q1', title: '¿Hay cuota mensual de monitoreo?', content: 'El monitoreo remoto por app no tiene costo adicional. El monitoreo profesional 24/7 con central es un servicio opcional con cuota mensual.' },
  { value: 'q2', title: '¿Cuánto tiempo se guardan las grabaciones?', content: 'Depende del paquete: desde 7 días en grabación local hasta 90 días con respaldo en la nube. Podemos ajustar la retención a tu necesidad.' },
  { value: 'q3', title: '¿Necesito permisos para instalar cámaras?', content: 'Para uso residencial y comercial dentro de tu propiedad no se requiere permiso especial. Te orientamos si tu caso requiere avisos de privacidad.' },
]

const PROPERTY_TYPES = ['Casa', 'Negocio', 'Oficina', 'Bodega'] as const
const MONITORING_OPTIONS = [
  { value: 'local', label: 'Solo grabación local' },
  { value: 'remoto', label: 'Monitoreo remoto por app' },
  { value: 'profesional', label: 'Monitoreo profesional 24/7' },
] as const

export function Cameras(): JSX.Element {
  const [propertyType, setPropertyType] = createSignal<(typeof PROPERTY_TYPES)[number]>('Casa')
  const [cameraCount, setCameraCount] = createSignal(4)
  const [indoor, setIndoor] = createSignal(true)
  const [outdoor, setOutdoor] = createSignal(true)
  const [monitoring, setMonitoring] = createSignal<(typeof MONITORING_OPTIONS)[number]['value']>('remoto')
  const [name, setName] = createSignal('')
  const [phone, setPhone] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <>
      <Section class="!pb-8 text-center">
        <Badge tone="info" class="mb-4">
          <Video class="h-3.5 w-3.5" /> Videovigilancia
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Cámaras de seguridad para casa y negocio</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Sistemas CCTV a la medida, instalados y configurados en un solo día.
        </p>
      </Section>

      <Section class="!pt-0">
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={SYSTEMS}>
            {(s) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {s.icon}
                </div>
                <h2 class="text-lg font-semibold">{s.title}</h2>
                <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      <div class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Paquetes</h2>
            <p class="mt-2 text-muted-foreground">Elige el nivel de cobertura que necesitas, todos incluyen instalación.</p>
          </div>
          <div class="grid gap-6 lg:grid-cols-3">
            <For each={PACKAGES}>
              {(pkg) => (
                <Card glass tilt class={`relative p-6 ${pkg.recommended ? 'border-primary' : ''}`}>
                  {pkg.recommended && (
                    <Badge tone="info" class="absolute -top-3 left-6">
                      Recomendado
                    </Badge>
                  )}
                  <h3 class="text-lg font-semibold">{pkg.name}</h3>
                  <p class="mt-2 text-3xl font-semibold text-primary">{pkg.price}</p>
                  <ul class="mt-4 space-y-2 text-sm text-muted-foreground">
                    <For each={pkg.features}>
                      {(f) => (
                        <li class="flex items-center gap-2">
                          <ShieldCheck class="h-4 w-4 text-primary" /> {f}
                        </li>
                      )}
                    </For>
                  </ul>
                </Card>
              )}
            </For>
          </div>
        </Section>
      </div>

      <Section>
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Proceso de instalación</h2>
        </div>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <For each={STEPS}>
            {(step, i) => (
              <div class="text-center">
                <div class="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
                  {i() + 1}
                </div>
                <h3 class="font-semibold">{step.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{step.blurb}</p>
              </div>
            )}
          </For>
        </div>

        <div class="mx-auto mt-12 max-w-2xl rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
          <Camera class="mx-auto mb-3 h-8 w-8 text-primary" />
          <p class="text-sm">Vista previa de cobertura — el mapa de cámaras se genera durante la visita de sitio.</p>
        </div>
      </Section>

      <div class="border-y border-border/60 bg-muted/30">
        <Section id="cotizar">
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">Cotiza tu sistema</h2>
              <p class="mt-2 text-muted-foreground">Cuéntanos sobre tu propiedad y te armamos una propuesta a la medida.</p>
            </div>
            <Card glass class="p-6">
              {sent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {name() || 'nos vemos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Te contactamos para agendar la visita de sitio.</p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submit}>
                  <div>
                    <label class="mb-1 block text-sm font-medium">Tipo de propiedad</label>
                    <select
                      value={propertyType()}
                      onInput={(e) => setPropertyType(e.currentTarget.value as (typeof PROPERTY_TYPES)[number])}
                      aria-label="Tipo de propiedad"
                      class="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      <For each={PROPERTY_TYPES}>{(t) => <option value={t}>{t}</option>}</For>
                    </select>
                  </div>
                  <div>
                    <label class="mb-1 block text-sm font-medium">Número de cámaras aproximado</label>
                    <input
                      type="number"
                      min="1"
                      max="32"
                      value={cameraCount()}
                      onInput={(e) => setCameraCount(Number(e.currentTarget.value))}
                      aria-label="Número de cámaras aproximado"
                      class="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                  <div>
                    <p class="mb-1 text-sm font-medium">Zonas a cubrir</p>
                    <div class="flex gap-4 text-sm">
                      <label class="flex items-center gap-2">
                        <input type="checkbox" checked={indoor()} onChange={(e) => setIndoor(e.currentTarget.checked)} class="h-4 w-4 rounded border-border accent-primary" />
                        Interior
                      </label>
                      <label class="flex items-center gap-2">
                        <input type="checkbox" checked={outdoor()} onChange={(e) => setOutdoor(e.currentTarget.checked)} class="h-4 w-4 rounded border-border accent-primary" />
                        Exterior
                      </label>
                    </div>
                  </div>
                  <div>
                    <p class="mb-1 text-sm font-medium">Preferencia de monitoreo</p>
                    <div class="space-y-2 text-sm">
                      <For each={MONITORING_OPTIONS}>
                        {(opt) => (
                          <label class="flex items-center gap-2">
                            <input
                              type="radio"
                              name="monitoring"
                              value={opt.value}
                              checked={monitoring() === opt.value}
                              onChange={() => setMonitoring(opt.value)}
                              class="h-4 w-4 border-border accent-primary"
                            />
                            {opt.label}
                          </label>
                        )}
                      </For>
                    </div>
                  </div>
                  <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label class="mb-1 block text-sm font-medium">Nombre</label>
                      <Input value={name()} onInput={setName} placeholder="Tu nombre" aria-label="Nombre" required />
                    </div>
                    <div>
                      <label class="mb-1 block text-sm font-medium">Teléfono</label>
                      <Input value={phone()} onInput={setPhone} placeholder="55 0000 0000" type="tel" aria-label="Teléfono" required />
                    </div>
                  </div>
                  <Button ripple type="submit" class="w-full">Solicitar cotización</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">Preguntas frecuentes</h2>
          <Accordion items={FAQ} />
        </div>
      </Section>
    </>
  )
}
