import { Badge, Button, Card, Carousel, GradientText, Magnetic, Parallax, Rating, Stat, TextReveal } from '@a4ui/core'
import { A, useNavigate } from '@solidjs/router'
import { Camera, Cpu, HardDrive, ShieldCheck, Sparkles, Wrench } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { Section } from '../components/Section'

const LINES: { icon: JSX.Element; title: string; blurb: string; href: string }[] = [
  {
    icon: <Wrench class="h-6 w-6" />,
    title: 'Reparación',
    blurb: 'Diagnóstico y reparación de laptops y equipos de escritorio, con garantía por escrito.',
    href: '/repair',
  },
  {
    icon: <HardDrive class="h-6 w-6" />,
    title: 'Tienda de refacciones',
    blurb: 'RAM, almacenamiento, tarjetas gráficas, periféricos y equipos armados listos para llevar.',
    href: '/store',
  },
  {
    icon: <Camera class="h-6 w-6" />,
    title: 'Videovigilancia',
    blurb: 'Instalación de cámaras CCTV para casa o negocio, con monitoreo remoto opcional.',
    href: '/cameras',
  },
]

const TESTIMONIALS = [
  { name: 'Rodrigo A.', quote: 'Me arreglaron la laptop el mismo día. Diagnóstico honesto y precio justo.', rating: 5, line: 'Reparación' },
  { name: 'Cecilia M.', quote: 'Compré la RAM y el SSD ahí mismo. Buen precio y me los instalaron sin costo extra.', rating: 5, line: 'Tienda' },
  { name: 'Julio H.', quote: 'Instalaron 8 cámaras en el negocio en un día. Ahora reviso todo desde el celular.', rating: 5, line: 'Cámaras' },
]

export function Home(): JSX.Element {
  const navigate = useNavigate()

  return (
    <>
      <div class="relative overflow-hidden">
        <Parallax amount={100} class="pointer-events-none absolute inset-0 -z-10">
          <div
            class="absolute inset-0 opacity-70"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.22), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.18), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="info" class="mb-5">
            <Sparkles class="h-3.5 w-3.5" /> Reparación · Refacciones · Videovigilancia
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Todo lo que tu equipo necesita, <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">en un solo lugar</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Reparamos tus equipos, te vendemos las refacciones y protegemos tu casa o negocio con cámaras de videovigilancia.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={10}>
              <Button ripple onClick={() => navigate('/contact')}>
                Cotiza tu servicio
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => navigate('/store')}>
              Ver refacciones
            </Button>
          </div>
        </Section>
      </div>

      <Section id="lineas">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Nuestras líneas de negocio</h2>
          <p class="mt-2 text-muted-foreground">Elige lo que necesitas, cada área tiene su propio equipo especializado.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-3">
          <For each={LINES}>
            {(l) => (
              <A href={l.href} class="block">
                <Card glass tilt spotlight class="h-full p-6">
                  <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                    {l.icon}
                  </div>
                  <h3 class="text-lg font-semibold">{l.title}</h3>
                  <p class="mt-1 text-sm text-muted-foreground">{l.blurb}</p>
                  <span class="mt-4 inline-block text-sm font-medium text-primary">Ver más →</span>
                </Card>
              </A>
            )}
          </For>
        </div>
      </Section>

      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Años de experiencia" value={10} tone="primary" icon={<Cpu class="h-5 w-5" />} />
            <Stat label="Equipos reparados" value={8400} format={(n) => `${Math.round(n / 100) / 10}k+`} tone="neutral" icon={<Wrench class="h-5 w-5" />} />
            <Stat label="Cámaras instaladas" value={1250} format={(n) => `${Math.round(n)}+`} tone="primary" icon={<Camera class="h-5 w-5" />} />
            <Stat label="Clientes atendidos" value={3600} format={(n) => `${Math.round(n)}+`} tone="neutral" icon={<ShieldCheck class="h-5 w-5" />} />
          </div>
        </Section>
      </div>

      <Section id="testimonios">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Lo que dicen nuestros clientes" onView />
          </h2>
        </div>
        <div class="mx-auto max-w-2xl">
          <Carousel
            autoplayMs={5000}
            slides={TESTIMONIALS.map((t) => (
              <div class="px-2">
                <Card glass class="p-8 text-center">
                  <Badge tone="neutral" class="mb-3">{t.line}</Badge>
                  <Rating value={t.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                  <p class="text-lg">&ldquo;{t.quote}&rdquo;</p>
                  <p class="mt-4 text-sm font-medium text-muted-foreground">— {t.name}</p>
                </Card>
              </div>
            ))}
          />
        </div>
      </Section>
    </>
  )
}
