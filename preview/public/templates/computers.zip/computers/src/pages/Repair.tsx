import { Accordion, Badge, Button, Card, Expandable, Input, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow, Textarea, TextReveal } from '@a4ui/core'
import { useNavigate } from '@solidjs/router'
import {
  Cpu,
  Download,
  HardDrive,
  MonitorSmartphone,
  ShieldCheck,
  Wrench,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

import { Section } from '../components/Section'

const SERVICES: { icon: JSX.Element; title: string; blurb: string; details: string[] }[] = [
  {
    icon: <Cpu class="h-6 w-6" />,
    title: 'Diagnóstico general',
    blurb: 'Revisión completa de hardware y software antes de cotizar.',
    details: ['Pruebas de hardware (RAM, disco, batería)', 'Revisión de sistema operativo y arranque', 'Cotización sin costo si autorizas la reparación'],
  },
  {
    icon: <MonitorSmartphone class="h-6 w-6" />,
    title: 'Reemplazo de pantalla',
    blurb: 'Pantallas originales y compatibles para laptop y todo en uno.',
    details: ['Pantallas originales o compatibles certificadas', 'Instalación el mismo día si hay stock', 'Garantía de 90 días en la refacción'],
  },
  {
    icon: <HardDrive class="h-6 w-6" />,
    title: 'Recuperación de datos',
    blurb: 'Rescate de archivos en discos dañados o que no encienden.',
    details: ['Diagnóstico del medio dañado sin costo', 'Rescate de archivos, fotos y documentos', 'Entrega en disco externo o nube'],
  },
  {
    icon: <ShieldCheck class="h-6 w-6" />,
    title: 'Eliminación de virus',
    blurb: 'Limpieza de malware y refuerzo de seguridad del equipo.',
    details: ['Escaneo completo de malware y spyware', 'Limpieza de programas no deseados', 'Instalación de protección básica'],
  },
  {
    icon: <Download class="h-6 w-6" />,
    title: 'Actualización de RAM/SSD',
    blurb: 'Mejora de velocidad con memoria y almacenamiento nuevos.',
    details: ['Asesoría sobre la mejor combinación para tu equipo', 'Migración de sistema y archivos incluida', 'Prueba de rendimiento antes de entregar'],
  },
  {
    icon: <Wrench class="h-6 w-6" />,
    title: 'Mantenimiento preventivo',
    blurb: 'Limpieza interna, cambio de pasta térmica y revisión general.',
    details: ['Limpieza de polvo y ventiladores', 'Cambio de pasta térmica', 'Revisión general de temperaturas'],
  },
]

const PRICING = [
  { service: 'Diagnóstico general', price: '$250 (gratis si autorizas la reparación)', time: 'Mismo día' },
  { service: 'Limpieza y mantenimiento', price: '$450', time: '1 día' },
  { service: 'Reemplazo de pantalla', price: 'desde $1,200', time: '1–2 días' },
  { service: 'Recuperación de datos', price: 'desde $900', time: '2–4 días' },
  { service: 'Eliminación de virus/malware', price: '$500', time: 'Mismo día' },
  { service: 'Actualización de RAM/SSD', price: 'desde $600 + refacción', time: '1 día' },
]

const STEPS = [
  { title: 'Recepción', blurb: 'Recibimos el equipo y anotamos la falla reportada.' },
  { title: 'Diagnóstico', blurb: 'Nuestros técnicos identifican la causa del problema.' },
  { title: 'Cotización', blurb: 'Te enviamos el costo y tiempo estimado para tu aprobación.' },
  { title: 'Reparación', blurb: 'Reparamos el equipo con refacciones de calidad.' },
  { title: 'Entrega', blurb: 'Te entregamos el equipo probado y con garantía por escrito.' },
]

const FAQ = [
  { value: 'q1', title: '¿La reparación tiene garantía?', content: 'Sí, todas nuestras reparaciones incluyen garantía por escrito de 90 días sobre la refacción y el trabajo realizado.' },
  { value: 'q2', title: '¿Qué pasa con mis datos y privacidad?', content: 'Tus archivos son confidenciales. No accedemos a datos personales salvo que sea necesario para el diagnóstico, y puedes solicitar borrado de respaldos temporales.' },
  { value: 'q3', title: '¿Necesito cita o puedo ir directo?', content: 'Puedes llegar sin cita para diagnóstico. Para instalaciones o reparaciones programadas, te recomendamos agendar por teléfono o el formulario de contacto.' },
]

const DEVICE_ESTIMATE: Record<string, string> = {
  laptop: '1–2 días hábiles',
  desktop: '1 día hábil',
  consola: '3–5 días hábiles',
  otro: '2–4 días hábiles, según diagnóstico',
}

export function Repair(): JSX.Element {
  const navigate = useNavigate()
  const [device, setDevice] = createSignal('laptop')
  const [formDevice, setFormDevice] = createSignal('laptop')
  const [name, setName] = createSignal('')
  const [phone, setPhone] = createSignal('')
  const [issue, setIssue] = createSignal('')
  const [contactPref, setContactPref] = createSignal('whatsapp')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <>
      <Section class="!pb-10 text-center">
        <Badge tone="info" class="mb-4">
          <Wrench class="h-3.5 w-3.5" /> Servicio técnico
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Reparación de computadoras</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Diagnóstico honesto, refacciones de calidad y garantía por escrito en cada reparación.
        </p>
      </Section>

      <Section id="servicios" class="!pt-0">
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={SERVICES}>
            {(s) => (
              <Expandable
                size="dialog"
                maxWidth={480}
                trigger={
                  <Card glass tilt spotlight class="h-full cursor-pointer p-6">
                    <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                      {s.icon}
                    </div>
                    <h2 class="text-lg font-semibold">{s.title}</h2>
                    <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
                  </Card>
                }
              >
                <div class="p-6">
                  <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                    {s.icon}
                  </div>
                  <h2 class="text-xl font-semibold">{s.title}</h2>
                  <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
                  <ul class="mt-4 space-y-2 text-sm text-muted-foreground">
                    <For each={s.details}>
                      {(item) => (
                        <li class="flex items-start gap-2">
                          <ShieldCheck class="mt-0.5 h-4 w-4 shrink-0 text-primary" /> {item}
                        </li>
                      )}
                    </For>
                  </ul>
                  <Button ripple class="mt-5 w-full" onClick={() => navigate('/contact')}>
                    Solicitar este servicio
                  </Button>
                </div>
              </Expandable>
            )}
          </For>
        </div>
      </Section>

      <div class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="mb-8 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Precios de referencia</h2>
            <p class="mt-2 text-muted-foreground">El costo final se confirma tras el diagnóstico, sin sorpresas.</p>
          </div>
          <Card glass class="p-2 sm:p-4">
            <Table>
              <TableHead>
                <TableRow>
                  <TableHeadCell>Servicio</TableHeadCell>
                  <TableHeadCell>Precio</TableHeadCell>
                  <TableHeadCell>Tiempo estimado</TableHeadCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <For each={PRICING}>
                  {(row) => (
                    <TableRow>
                      <TableCell class="font-medium">{row.service}</TableCell>
                      <TableCell>{row.price}</TableCell>
                      <TableCell class="text-muted-foreground">{row.time}</TableCell>
                    </TableRow>
                  )}
                </For>
              </TableBody>
            </Table>
          </Card>
        </Section>
      </div>

      <Section id="proceso">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="¿Cómo funciona?" onView />
          </h2>
        </div>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          <For each={STEPS}>
            {(step, i) => (
              <div class="text-center">
                <div class="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
                  {i() + 1}
                </div>
                <h3 class="font-semibold">{step.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{step.blurb}</p>
              </div>
            )}
          </For>
        </div>
      </Section>

      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14 text-center">
          <h2 class="text-2xl font-semibold tracking-tight">¿Cuánto tarda mi reparación?</h2>
          <p class="mt-2 text-muted-foreground">Selecciona tu tipo de equipo para ver un estimado de tiempo.</p>
          <div class="mx-auto mt-6 max-w-sm">
            <select
              value={device()}
              onInput={(e) => setDevice(e.currentTarget.value)}
              aria-label="Tipo de equipo para estimado de tiempo"
              class="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="laptop">Laptop</option>
              <option value="desktop">Equipo de escritorio</option>
              <option value="consola">Consola de videojuegos</option>
              <option value="otro">Otro</option>
            </select>
            <Card glass class="mt-4 p-5">
              <p class="text-sm text-muted-foreground">Tiempo estimado</p>
              <p class="mt-1 text-2xl font-semibold text-primary">{DEVICE_ESTIMATE[device()]}</p>
            </Card>
          </div>
        </Section>
      </div>

      <Section id="solicitar">
        <div class="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 class="text-3xl font-semibold tracking-tight">Solicita tu diagnóstico</h2>
            <p class="mt-2 text-muted-foreground">Cuéntanos qué le pasa a tu equipo y te contactamos con una cotización.</p>
          </div>
          <Card glass class="p-6">
            {sent() ? (
              <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                <p class="text-lg font-medium">¡Gracias, {name() || 'ya casi terminamos'}!</p>
                <p class="mt-1 text-sm text-muted-foreground">Te contactamos por {contactPref()} para confirmar el diagnóstico.</p>
              </div>
            ) : (
              <form class="space-y-4" onSubmit={submit}>
                <div>
                  <label class="mb-1 block text-sm font-medium">Nombre</label>
                  <Input value={name()} onInput={setName} placeholder="Tu nombre" aria-label="Nombre" required />
                </div>
                <div>
                  <label class="mb-1 block text-sm font-medium">Teléfono</label>
                  <Input value={phone()} onInput={setPhone} placeholder="55 0000 0000" type="tel" aria-label="Teléfono" required />
                </div>
                <div class="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label class="mb-1 block text-sm font-medium">Tipo de equipo</label>
                    <select
                      value={formDevice()}
                      onInput={(e) => setFormDevice(e.currentTarget.value)}
                      aria-label="Tipo de equipo"
                      class="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      <option value="laptop">Laptop</option>
                      <option value="desktop">Equipo de escritorio</option>
                      <option value="consola">Consola</option>
                      <option value="otro">Otro</option>
                    </select>
                  </div>
                  <div>
                    <label class="mb-1 block text-sm font-medium">Prefiero que me contacten por</label>
                    <select
                      value={contactPref()}
                      onInput={(e) => setContactPref(e.currentTarget.value)}
                      aria-label="Prefiero que me contacten por"
                      class="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      <option value="whatsapp">WhatsApp</option>
                      <option value="llamada">Llamada</option>
                      <option value="correo">Correo</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label class="mb-1 block text-sm font-medium">Describe el problema</label>
                  <Textarea value={issue()} onInput={setIssue} placeholder="Ej. no enciende, pantalla rota, muy lento…" aria-label="Describe el problema" rows={4} />
                </div>
                <Button ripple type="submit" class="w-full">Solicitar diagnóstico</Button>
              </form>
            )}
          </Card>
        </div>
      </Section>

      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">Preguntas frecuentes</h2>
          <Accordion items={FAQ} />
        </div>
      </Section>
    </>
  )
}
