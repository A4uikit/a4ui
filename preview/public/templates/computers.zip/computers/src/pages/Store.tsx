import { Badge, Button, Card, Input } from '@a4ui/core'
import { useNavigate } from '@solidjs/router'
import { Cpu, HardDrive, MonitorSmartphone, Package, ShoppingCart, Wrench, X } from 'lucide-solid'
import { createMemo, createSignal, For, type JSX, Show } from 'solid-js'

import { Section } from '../components/Section'
import { cart, formatPrice, type Product } from '../lib/cart'

const CATEGORIES = ['Todos', 'RAM', 'Almacenamiento', 'Tarjetas gráficas', 'Periféricos', 'Equipos armados'] as const

const PRODUCTS: Product[] = [
  { id: 'p1', name: 'Kingston Fury 16GB DDR4', category: 'RAM', price: 890, stock: 24, spec: '16GB · DDR4 · 3200MHz' },
  { id: 'p2', name: 'Corsair Vengeance 32GB DDR4', category: 'RAM', price: 1690, stock: 11, spec: '32GB (2x16GB) · DDR4 · 3200MHz' },
  { id: 'p3', name: 'SSD NVMe 1TB', category: 'Almacenamiento', price: 1350, stock: 15, spec: '1TB · NVMe · PCIe 4.0' },
  { id: 'p4', name: 'Disco duro externo 2TB', category: 'Almacenamiento', price: 990, stock: 18, spec: '2TB · USB 3.0' },
  { id: 'p5', name: 'Tarjeta gráfica RTX 4060', category: 'Tarjetas gráficas', price: 7999, stock: 6, spec: '8GB GDDR6 · HDMI 2.1' },
  { id: 'p6', name: 'Tarjeta gráfica RTX 4070', category: 'Tarjetas gráficas', price: 12499, stock: 3, spec: '12GB GDDR6X · DisplayPort 1.4a' },
  { id: 'p7', name: 'Teclado mecánico RGB', category: 'Periféricos', price: 650, stock: 30, spec: 'Switches rojos · retroiluminado' },
  { id: 'p8', name: 'Mouse gamer inalámbrico', category: 'Periféricos', price: 420, stock: 40, spec: '16,000 DPI · inalámbrico' },
  { id: 'p9', name: 'Monitor 24" Full HD', category: 'Periféricos', price: 2600, stock: 9, spec: '24" · 75Hz · IPS' },
  { id: 'p10', name: 'PC armada oficina', category: 'Equipos armados', price: 8500, stock: 4, spec: 'Ryzen 5 · 16GB RAM · 512GB SSD' },
  { id: 'p11', name: 'PC armada gamer', category: 'Equipos armados', price: 18900, stock: 2, spec: 'Ryzen 7 · 32GB RAM · RTX 4060 · 1TB SSD' },
]

function categoryIcon(category: string): JSX.Element {
  switch (category) {
    case 'RAM':
      return <Cpu class="h-6 w-6" />
    case 'Almacenamiento':
      return <HardDrive class="h-6 w-6" />
    case 'Tarjetas gráficas':
      return <MonitorSmartphone class="h-6 w-6" />
    case 'Equipos armados':
      return <Wrench class="h-6 w-6" />
    default:
      return <Package class="h-6 w-6" />
  }
}

export function Store(): JSX.Element {
  const navigate = useNavigate()
  const [category, setCategory] = createSignal<(typeof CATEGORIES)[number]>('Todos')
  const [search, setSearch] = createSignal('')

  const filtered = createMemo(() =>
    PRODUCTS.filter((p) => (category() === 'Todos' || p.category === category()) && p.name.toLowerCase().includes(search().toLowerCase())),
  )

  return (
    <>
      <Section class="!pb-8 text-center">
        <Badge tone="info" class="mb-4">
          <ShoppingCart class="h-3.5 w-3.5" /> Tienda de refacciones
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Refacciones y equipo listos para llevar</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          RAM, almacenamiento, tarjetas gráficas, periféricos y equipos armados con garantía de fábrica.
        </p>
      </Section>

      <Section class="!pt-0">
        <div class="grid gap-8 lg:grid-cols-[220px_1fr_280px]">
          {/* Filters */}
          <aside class="space-y-4">
            <div>
              <label class="mb-1 block text-sm font-medium">Buscar</label>
              <Input value={search()} onInput={setSearch} placeholder="Ej. RTX, SSD, mouse…" aria-label="Buscar refacciones" />
            </div>
            <div>
              <p class="mb-2 text-sm font-medium">Categoría</p>
              <div class="flex flex-wrap gap-2 lg:flex-col">
                <For each={CATEGORIES}>
                  {(c) => (
                    <button
                      type="button"
                      onClick={() => setCategory(c)}
                      class={`rounded-lg border px-3 py-1.5 text-left text-sm transition-colors ${
                        category() === c
                          ? 'border-primary bg-primary/15 text-primary'
                          : 'border-border text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      {c}
                    </button>
                  )}
                </For>
              </div>
            </div>
          </aside>

          {/* Product grid */}
          <div>
            <Show when={filtered().length > 0} fallback={<p class="py-12 text-center text-muted-foreground">No encontramos refacciones con ese filtro.</p>}>
              <div class="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                <For each={filtered()}>
                  {(p) => (
                    <Card glass tilt spotlight class="flex flex-col p-5">
                      <div class="mb-3 flex items-start justify-between">
                        <div class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
                          {categoryIcon(p.category)}
                        </div>
                        <Badge tone={p.stock < 5 ? 'warning' : 'success'}>{p.stock < 5 ? 'Últimas piezas' : 'En stock'}</Badge>
                      </div>
                      <h2 class="font-semibold">{p.name}</h2>
                      <p class="mt-1 text-sm text-muted-foreground">{p.spec}</p>
                      <div class="mt-4 flex items-center justify-between">
                        <span class="text-lg font-semibold text-primary">{formatPrice(p.price)}</span>
                        <Button ripple variant="secondary" onClick={() => cart.add(p)}>
                          Agregar
                        </Button>
                      </div>
                    </Card>
                  )}
                </For>
              </div>
            </Show>
          </div>

          {/* Cart */}
          <aside>
            <Card glass class="sticky top-20 p-5">
              <h2 class="flex items-center gap-2 font-semibold">
                <ShoppingCart class="h-5 w-5 text-primary" /> Tu carrito
              </h2>
              <Show when={cart.items().length > 0} fallback={<p class="mt-4 text-sm text-muted-foreground">Aún no has agregado refacciones.</p>}>
                <ul class="mt-4 space-y-3">
                  <For each={cart.items()}>
                    {(entry) => (
                      <li class="flex items-start justify-between gap-2 text-sm">
                        <div>
                          <p class="font-medium">{entry.product.name}</p>
                          <p class="text-muted-foreground">
                            {entry.qty} × {formatPrice(entry.product.price)}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => cart.remove(entry.product.id)}
                          aria-label={`Quitar ${entry.product.name}`}
                          class="flex h-6 w-6 items-center justify-center text-muted-foreground transition-colors hover:text-destructive"
                        >
                          <X class="h-4 w-4" />
                        </button>
                      </li>
                    )}
                  </For>
                </ul>
                <div class="mt-4 flex items-center justify-between border-t border-border/60 pt-4 font-semibold">
                  <span>Total</span>
                  <span class="text-primary">{formatPrice(cart.subtotal())}</span>
                </div>
                <Button ripple class="mt-4 w-full" onClick={() => navigate('/contact')}>
                  Solicitar cotización
                </Button>
              </Show>
            </Card>
          </aside>
        </div>
      </Section>
    </>
  )
}
