# Template: `restaurant` — Restaurant / café

A marketing + reservation site for a restaurant or café. Goal: a visitor
browses the menu, feels the ambiance, and books a table.

## Sections

1. **Top bar / nav** — logo, anchor links (Menu, Gallery, About, Contact), "Reserve a table" CTA. (`AppShell` top bar, `Button`)
2. **Hero** — headline, subcopy, primary CTA "Reserve a table", secondary "View menu". Glass surface over a themed backdrop, ambient food/interior imagery. (`GradientText`, `Image` blurUp)
3. **Menu** — categorized (Starters, Mains, Desserts, Drinks), each item with name, description, price. (`Tabs` or `SegmentedControl` for category switch, `Card`, `PriceTag`)
4. **Chef / about** — short story, portrait, years of experience, awards/press mentions. (`Card` glass, `Stat` count-up for years/awards)
5. **Gallery** — dishes, interior, plating shots. (`Carousel` swipe, `Image` blurUp)
6. **Reservations form** — party size, date, time, name, phone, special requests. (`Form`, `NumberInput` (party size), `DateField`, `Select` or a time picker via `DateField`, `Input`, `Textarea`, `Button` ripple)
7. **Hours & location** — opening hours table, address, map placeholder. (`Descriptions`, `Card`)
8. **Testimonials** — guest reviews, star ratings. (`Carousel` swipe, `Rating`, `Avatar`)
9. **Contact** — working contact form (name, email/phone, message) + phone, address, hours, map placeholder, social links. (`Form`, `Input`, `Textarea`, `Button` ripple, `Descriptions`)
10. **Footer** — nav, contact, socials, legal.

**Structure: single-page** (long scroll + sticky anchor nav via `Anchor`).

## Custom theme

Warm/intimate: deep terracotta or wine-red primary, warm cream background,
gold accent, generous radius on cards to feel hand-crafted. Override
`--primary` / `--accent` / `--background` / `--radius-*` tokens; verify WCAG
AA for menu price text in both light and dark.

## Animation / parallax

- `Parallax` on the hero backdrop and gallery section.
- `TextReveal` for section headings as they scroll into view.
- `GradientText` on the hero headline.
- `TiltCard` + `Spotlight` on chef/about card and featured dish cards.
- `Carousel` swipe for gallery and testimonials.
- `Stat` count-up for years of experience / awards in the about section.
- `Image` blurUp for all dish/gallery photography.
- Respect `prefers-reduced-motion` throughout (A4ui primitives handle this by default).

## Reusable candidates

- Categorized menu block (`Tabs` + `Card` + `PriceTag` grid) — reusable for any food-service vertical.
- Reservations form (`NumberInput` party size + `DateField` + `Select` time) — reusable for any booking-based vertical (salons, clinics).
- Gallery `Carousel` with blurUp images — generic media-showcase pattern.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `restaurant` theme tokens
- [ ] Nav + hero
- [ ] Categorized menu section
- [ ] Chef / about section
- [ ] Gallery carousel
- [ ] Reservations form (with validation)
- [ ] Hours & location section
- [ ] Testimonials carousel
- [ ] Contact section + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
