import {
  Aurora,
  Badge,
  Button,
  Card,
  Carousel,
  DateField,
  Descriptions,
  Expandable,
  GradientText,
  Image,
  Input,
  Magnetic,
  NumberInput,
  Parallax,
  Rating,
  ScrollProgress,
  Section,
  Select,
  Stat,
  Tabs,
  Textarea,
  TextReveal,
  TiltCard,
} from '@a4ui/core'
import { PriceTag } from '@a4ui/core/commerce'
import {
  AtSign,
  Award,
  Cake,
  ChefHat,
  Clock,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Quote,
  Salad,
  Send,
  Star,
  UtensilsCrossed,
  Wine,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const NAV = [
  { href: '#menu', label: 'Menú' },
  { href: '#nosotros', label: 'Nosotros' },
  { href: '#galeria', label: 'Galería' },
  { href: '#testimonios', label: 'Reseñas' },
  { href: '#contacto', label: 'Contacto' },
]

interface Dish {
  name: string
  desc: string
  price: number
}

const MENU: { value: string; label: string; icon: JSX.Element; items: Dish[] }[] = [
  {
    value: 'entradas',
    label: 'Entradas',
    icon: <Salad class="h-4 w-4" />,
    items: [
      { name: 'Guacamole de temporada', desc: 'Aguacate, jitomate, cilantro y totopos recién fritos.', price: 145 },
      { name: 'Queso fundido con chorizo', desc: 'Chorizo artesanal, queso Oaxaca gratinado, tortillas de maíz.', price: 165 },
      { name: 'Tostadas de atún', desc: 'Atún sellado, aguacate, ponzú de chile morita.', price: 185 },
    ],
  },
  {
    value: 'fuertes',
    label: 'Platos fuertes',
    icon: <UtensilsCrossed class="h-4 w-4" />,
    items: [
      { name: 'Mole negro de Oaxaca', desc: 'Pechuga de pollo bañada en mole de 20 ingredientes, arroz rojo.', price: 255 },
      { name: 'Costillar de cerdo al pastor', desc: 'Costillar glaseado en adobo de achiote, piña asada.', price: 295 },
      { name: 'Pescado a la talla', desc: 'Huachinango entero, adobo rojo, arroz blanco y ensalada.', price: 310 },
      { name: 'Risotto de hongos y epazote', desc: 'Arroz arborio, hongos silvestres, queso añejo.', price: 220 },
    ],
  },
  {
    value: 'postres',
    label: 'Postres',
    icon: <Cake class="h-4 w-4" />,
    items: [
      { name: 'Pastel de elote', desc: 'Bizcocho de elote tibio con helado de vainilla.', price: 110 },
      { name: 'Tarta de mango y chile', desc: 'Mango fresco, crema de coco, polvo de chile piquín.', price: 120 },
      { name: 'Chocolate abuelita fundido', desc: 'Volcán de chocolate con centro líquido.', price: 130 },
    ],
  },
  {
    value: 'bebidas',
    label: 'Bebidas',
    icon: <Wine class="h-4 w-4" />,
    items: [
      { name: 'Agua de jamaica', desc: 'Infusión de flor de jamaica, toque de menta.', price: 55 },
      { name: 'Mezcal de la casa', desc: 'Selección artesanal de Oaxaca, copeo de 60ml.', price: 150 },
      { name: 'Café de olla', desc: 'Café de grano con canela y piloncillo.', price: 60 },
      { name: 'Vino tinto de la casa', desc: 'Selección nacional, copa de 150ml.', price: 135 },
    ],
  },
]

const GALLERY = [
  { src: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=800&auto=format&fit=crop', alt: 'Interior cálido del restaurante' },
  { src: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=800&auto=format&fit=crop', alt: 'Plato de autor recién emplatado' },
  { src: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop', alt: 'Tacos servidos en la mesa' },
  { src: 'https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=800&auto=format&fit=crop', alt: 'Mesa puesta para la cena' },
  { src: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=800&auto=format&fit=crop', alt: 'Platillo de temporada de cerca' },
  { src: 'https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?q=80&w=800&auto=format&fit=crop', alt: 'Chef preparando un platillo en cocina' },
]

const REVIEWS = [
  { name: 'Renata Solís', role: 'Cliente frecuente', quote: 'El mole negro es una obra de arte. Cada visita se siente como una celebración.', rating: 5 },
  { name: 'Héctor Duarte', role: 'Food blogger', quote: 'Ambiente cálido, servicio impecable y sabores que no se olvidan. Mi restaurante favorito del barrio.', rating: 5 },
  { name: 'Carla Jiménez', role: 'Cliente frecuente', quote: 'Reservé para un cumpleaños y superaron cada expectativa. Ya tenemos mesa para el próximo mes.', rating: 5 },
]

const HOURS = [
  { label: 'Lunes – Jueves', value: '13:00 – 22:00' },
  { label: 'Viernes – Sábado', value: '13:00 – 23:30' },
  { label: 'Domingo', value: '12:00 – 18:00' },
]

const TIME_SLOTS = ['13:00', '14:00', '15:00', '19:00', '20:00', '21:00', '22:00']

export function App(): JSX.Element {
  const [menuTab, setMenuTab] = createSignal('entradas')

  const [resName, setResName] = createSignal('')
  const [resPhone, setResPhone] = createSignal('')
  const [resParty, setResParty] = createSignal(2)
  const [resDate, setResDate] = createSignal('')
  const [resTime, setResTime] = createSignal('')
  const [resNotes, setResNotes] = createSignal('')
  const [resSent, setResSent] = createSignal(false)

  const submitReservation = (e: Event): void => {
    e.preventDefault()
    setResSent(true)
  }

  const [contactName, setContactName] = createSignal('')
  const [contactChannel, setContactChannel] = createSignal('')
  const [contactMessage, setContactMessage] = createSignal('')
  const [contactSent, setContactSent] = createSignal(false)

  const submitContact = (e: Event): void => {
    e.preventDefault()
    setContactSent(true)
  }

  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress height={3} />
      <Aurora />

      {/* Nav */}
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#inicio" class="flex items-center gap-2 font-semibold tracking-tight">
            <ChefHat class="h-5 w-5 text-primary" /> Sazón
          </a>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="inline-flex items-center py-2 transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <Button ripple onClick={() => (location.hash = '#reservaciones')}>
            Reservar mesa
          </Button>
        </div>
      </header>

      {/* Hero */}
      <div id="inicio" class="relative overflow-hidden">
        <Parallax amount={70} class="absolute inset-0 -z-20">
          <img
            src="https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80&w=1600&auto=format&fit=crop"
            alt=""
            class="h-full w-full object-cover opacity-30"
          />
        </Parallax>
        <div class="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-background/50 via-background/85 to-background" />
        <Section class="!py-28 text-center">
          <Badge tone="neutral" class="mb-5">
            <UtensilsCrossed class="h-3.5 w-3.5" /> Cocina de barrio, alma mexicana
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Sabores que se <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">celebran</GradientText> en cada mesa
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Ingredientes de temporada, recetas de familia y un servicio que te hace sentir en casa. Ven a probar Sazón.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#reservaciones')}>
                Reservar mesa
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => (location.hash = '#menu')}>
              Ver menú
            </Button>
          </div>
        </Section>
      </div>

      {/* Menu */}
      <Section id="menu">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Nuestro menú" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Cocina de autor con raíces mexicanas, por categoría.</p>
        </div>
        <Card glass class="p-6 sm:p-8">
          <Tabs
            value={menuTab()}
            onChange={setMenuTab}
            items={MENU.map((cat) => ({
              value: cat.value,
              label: cat.label,
              content: (
                <div>
                  <h3 class="mb-4 flex items-center gap-2 text-sm font-medium text-primary">
                    {cat.icon} {cat.label}
                  </h3>
                  <div class="divide-y divide-border/60">
                    <For each={cat.items}>
                      {(dish) => (
                        <div class="flex items-start justify-between gap-4 py-4">
                          <div>
                            <h4 class="font-medium">{dish.name}</h4>
                            <p class="mt-1 text-sm text-muted-foreground">{dish.desc}</p>
                          </div>
                          <PriceTag amount={dish.price} currency="MXN" locale="es-MX" class="shrink-0" />
                        </div>
                      )}
                    </For>
                  </div>
                </div>
              ),
            }))}
          />
        </Card>
      </Section>

      {/* Chef / about */}
      <div id="nosotros" class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2 lg:items-center">
            <TiltCard max={8}>
              <Card glass spotlight class="overflow-hidden p-0">
                <Image
                  src="https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?q=80&w=900&auto=format&fit=crop"
                  alt="Chef preparando un platillo en la cocina de Sazón"
                  blurUp
                  class="aspect-[4/5] w-full object-cover"
                />
              </Card>
            </TiltCard>
            <div>
              <Badge tone="neutral" class="mb-4">
                <ChefHat class="h-3.5 w-3.5" /> Nuestra historia
              </Badge>
              <h2 class="text-3xl font-semibold tracking-tight">Cocina que honra la mesa familiar</h2>
              <p class="mt-4 text-muted-foreground">
                Sazón nació de las recetas de nuestra abuela y del gusto por compartir. Cada platillo mezcla técnica
                contemporánea con los sabores que nos formaron: mole recién molido, salsas de temporada y pan hecho
                en casa. Trabajamos con productores locales para que cada visita sepa a México.
              </p>
              <div class="mt-8 grid grid-cols-3 gap-6">
                <Stat label="Años de experiencia" value={18} icon={<Award class="h-5 w-5" />} tone="primary" />
                <Stat label="Platillos en el menú" value={42} tone="neutral" />
                <Stat label="Reconocimientos" value={9} icon={<Star class="h-5 w-5" />} tone="primary" />
              </div>
            </div>
          </div>
        </Section>
      </div>

      {/* Gallery */}
      <Section id="galeria">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Galería</h2>
          <p class="mt-2 text-muted-foreground">Un vistazo a nuestros platillos y nuestro espacio.</p>
        </div>
        <div class="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <For each={GALLERY}>
            {(g) => (
              <Expandable
                size="dialog"
                maxWidth={880}
                class="overflow-hidden rounded-2xl"
                panelClass="overflow-hidden rounded-2xl"
                trigger={
                  <img
                    src={g.src}
                    alt={g.alt}
                    loading="lazy"
                    class="aspect-square w-full cursor-zoom-in object-cover transition-transform duration-500 hover:scale-105"
                  />
                }
              >
                <img src={g.src} alt={g.alt} class="max-h-[78vh] w-full object-contain" />
                <p class="p-3 text-center text-sm text-muted-foreground">{g.alt}</p>
              </Expandable>
            )}
          </For>
        </div>
      </Section>

      {/* Reservations */}
      <div id="reservaciones" class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="mx-auto max-w-2xl">
            <div class="mb-8 text-center">
              <h2 class="text-3xl font-semibold tracking-tight">Reserva tu mesa</h2>
              <p class="mt-2 text-muted-foreground">Elige fecha, hora y número de personas. Confirmamos por teléfono.</p>
            </div>
            <Card glass class="p-6 sm:p-8">
              {resSent() ? (
                <div class="flex flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Reservación recibida</Badge>
                  <p class="text-lg font-medium">¡Gracias, {resName() || 'te esperamos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">
                    Te confirmamos tu mesa para {resParty()} personas
                    {resDate() ? ` el ${resDate()}` : ''}
                    {resTime() ? ` a las ${resTime()}` : ''}.
                  </p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submitReservation}>
                  <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label for="res-name" class="mb-1 block text-sm font-medium">Nombre</label>
                      <Input id="res-name" value={resName()} onInput={setResName} placeholder="Tu nombre" required />
                    </div>
                    <div>
                      <label for="res-phone" class="mb-1 block text-sm font-medium">Teléfono</label>
                      <Input id="res-phone" value={resPhone()} onInput={setResPhone} placeholder="55 0000 0000" type="tel" required />
                    </div>
                  </div>
                  <div class="grid gap-4 sm:grid-cols-3">
                    <div>
                      <label id="res-party-label" class="mb-1 block text-sm font-medium">Personas</label>
                      <div role="group" aria-labelledby="res-party-label">
                        <NumberInput value={resParty()} onChange={setResParty} min={1} max={12} />
                      </div>
                    </div>
                    <div>
                      <label class="mb-1 block text-sm font-medium">Fecha</label>
                      <DateField value={resDate()} onChange={setResDate} label="Elige una fecha" />
                    </div>
                    <div>
                      <label for="res-time" class="mb-1 block text-sm font-medium">Hora</label>
                      <Select id="res-time" value={resTime()} onChange={setResTime} required>
                        <option value="" disabled>
                          Elige una hora
                        </option>
                        <For each={TIME_SLOTS}>{(t) => <option value={t}>{t}</option>}</For>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <label for="res-notes" class="mb-1 block text-sm font-medium">Solicitudes especiales</label>
                    <Textarea
                      id="res-notes"
                      value={resNotes()}
                      onInput={setResNotes}
                      placeholder="Alergias, celebraciones, preferencias de mesa…"
                      rows={3}
                    />
                  </div>
                  <Button ripple type="submit" class="w-full">
                    Confirmar reservación
                  </Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Hours & location */}
      <Section id="horarios">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Horario y ubicación</h2>
        </div>
        <div class="grid gap-6 lg:grid-cols-2">
          <Card glass class="p-6">
            <h3 class="mb-4 flex items-center gap-2 text-lg font-semibold">
              <Clock class="h-5 w-5 text-primary" /> Horario
            </h3>
            <Descriptions columns={1} items={HOURS.map((h) => ({ label: h.label, value: h.value }))} />
          </Card>
          <Card glass class="relative flex min-h-[240px] flex-col items-center justify-center overflow-hidden p-6 text-center">
            <div
              class="pointer-events-none absolute inset-0 -z-10"
              style={{
                background:
                  'radial-gradient(60% 60% at 50% 40%, hsl(var(--primary) / 0.14), transparent 70%), radial-gradient(50% 50% at 80% 80%, hsl(var(--accent) / 0.14), transparent 70%)',
              }}
            />
            <MapPin class="h-8 w-8 text-primary" />
            <p class="mt-3 font-medium">Av. de los Insurgentes 245, Col. Roma Norte, CDMX</p>
            <p class="mt-1 text-sm text-muted-foreground">Mapa disponible al confirmar tu reservación.</p>
          </Card>
        </div>
      </Section>

      {/* Testimonials */}
      <div id="testimonios" class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="mb-8 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Lo que dicen nuestros comensales</h2>
          </div>
          <div class="mx-auto max-w-2xl">
            <Carousel
              autoplayMs={5500}
              slides={REVIEWS.map((r) => (
                <div class="px-2">
                  <Card glass class="p-8 text-center">
                    <Quote class="mx-auto mb-3 h-6 w-6 text-primary" />
                    <Rating value={r.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                    <p class="text-lg">&ldquo;{r.quote}&rdquo;</p>
                    <p class="mt-4 text-sm font-medium text-muted-foreground">
                      {r.name} · {r.role}
                    </p>
                  </Card>
                </div>
              ))}
            />
          </div>
        </Section>
      </div>

      {/* Contact */}
      <Section id="contacto">
        <div class="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 class="text-3xl font-semibold tracking-tight">Contáctanos</h2>
            <p class="mt-2 text-muted-foreground">¿Dudas, eventos privados o grupos grandes? Escríbenos.</p>
            <ul class="mt-8 space-y-4 text-sm">
              <li class="flex items-center gap-3"><Phone class="h-5 w-5 text-primary" /> +52 55 1234 5678</li>
              <li class="flex items-center gap-3"><Mail class="h-5 w-5 text-primary" /> hola@sazon.mx</li>
              <li class="flex items-center gap-3"><MapPin class="h-5 w-5 text-primary" /> Av. de los Insurgentes 245, Col. Roma Norte, CDMX</li>
              <li class="flex items-center gap-3"><Clock class="h-5 w-5 text-primary" /> Lun–Dom · 12:00–23:30</li>
            </ul>
            <div class="mt-6 flex gap-1 text-muted-foreground">
              <a href="#" aria-label="Instagram" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><AtSign class="h-5 w-5" /></a>
              <a href="#" aria-label="WhatsApp" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
            </div>
          </div>

          <Card glass class="p-6">
            {contactSent() ? (
              <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                <p class="text-lg font-medium">¡Gracias, {contactName() || 'nos vemos pronto'}!</p>
                <p class="mt-1 text-sm text-muted-foreground">Te respondemos a la brevedad.</p>
              </div>
            ) : (
              <form class="space-y-4" onSubmit={submitContact}>
                <div>
                  <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                  <Input id="contact-name" value={contactName()} onInput={setContactName} placeholder="Tu nombre" required />
                </div>
                <div>
                  <label for="contact-channel" class="mb-1 block text-sm font-medium">Correo o teléfono</label>
                  <Input id="contact-channel" value={contactChannel()} onInput={setContactChannel} placeholder="tu@correo.com" required />
                </div>
                <div>
                  <label for="contact-message" class="mb-1 block text-sm font-medium">Mensaje</label>
                  <Textarea id="contact-message" value={contactMessage()} onInput={setContactMessage} placeholder="Cuéntanos…" rows={4} />
                </div>
                <Button ripple type="submit" class="w-full">
                  <Send class="h-4 w-4" /> Enviar mensaje
                </Button>
              </form>
            )}
          </Card>
        </div>
      </Section>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2"><ChefHat class="h-4 w-4 text-primary" /> Sazón · Cocina de Barrio</span>
          <nav class="flex flex-wrap items-center justify-center gap-4">
            <For each={NAV}>{(n) => <a href={n.href} class="inline-flex items-center py-2 transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <span>© 2026 Sazón. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}
