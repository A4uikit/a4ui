# Template: `taller` — Auto workshop / mechanic

A marketing + booking site for an auto repair shop. Goal: a visitor understands
the services, sees pricing and trust signals, and books an appointment.

## Sections

1. **Top bar / nav** — logo, service links, phone CTA. (`AppShell` top bar, `Button`)
2. **Hero** — headline, subcopy, primary CTA "Agenda tu cita", secondary "Ver servicios". Glass surface over a themed backdrop.
3. **Services grid** — 6–8 service cards (oil change, brakes, alignment, diagnostics…) with icon, title, blurb. (`Card` tilt/spotlight, lucide icons)
4. **Packages / pricing** — 3 tiers. (`Card`, `PriceTag`, `Badge` "Popular")
5. **How we work** — 4 steps. (`Stepper` or `Timeline`)
6. **Testimonials** — rotating quotes. (`Carousel` with swipe, `Rating`, `Avatar`)
7. **Booking form** — service select, date, time, name, phone, notes. (`Form`, `Select`, `DateField`, `Input`, `Button ripple`)
8. **FAQ** — collapsible questions. (`Accordion` with animated height)
9. **Location & contact** — hours, address, map placeholder. (`Descriptions`, `Card`)
10. **Footer**

## Custom theme

Industrial/warm: steel-blue primary, amber accent, slightly larger radius.
Override `--primary` / `--accent` / `--radius-*` tokens.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `taller` theme tokens
- [ ] Nav + hero
- [ ] Services grid
- [ ] Packages / pricing
- [ ] How-we-work steps
- [ ] Testimonials carousel
- [ ] Booking form (with validation)
- [ ] FAQ accordion
- [ ] Location / contact + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
