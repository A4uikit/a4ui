import {
  Accordion,
  Badge,
  Button,
  Card,
  Carousel,
  DateField,
  Descriptions,
  GradientText,
  Input,
  Magnetic,
  Parallax,
  PricingTable,
  type PricingTier,
  Rating,
  ScrollProgress,
  Section,
  Select,
  Stat,
  Stepper,
  Textarea,
  TextReveal,
} from '@a4ui/core'
import {
  AtSign,
  Battery,
  CircleDot,
  Disc,
  Droplet,
  Gauge,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Settings,
  ShieldCheck,
  Wind,
  Wrench,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const NAV = [
  { href: '#services', label: 'Servicios' },
  { href: '#packages', label: 'Paquetes' },
  { href: '#how-we-work', label: 'Cómo trabajamos' },
  { href: '#reviews', label: 'Reseñas' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contact', label: 'Contacto' },
]

const SERVICES: { icon: JSX.Element; title: string; blurb: string; price: string }[] = [
  { icon: <Droplet class="h-6 w-6" />, title: 'Cambio de aceite', blurb: 'Aceite y filtros de calidad, revisión de niveles incluida.', price: 'desde $450' },
  { icon: <Disc class="h-6 w-6" />, title: 'Frenos', blurb: 'Balatas, discos y líquido de frenos, con prueba de manejo.', price: 'desde $890' },
  { icon: <CircleDot class="h-6 w-6" />, title: 'Alineación y balanceo', blurb: 'Geometría de precisión para un manejo estable y llantas parejas.', price: 'desde $650' },
  { icon: <Gauge class="h-6 w-6" />, title: 'Diagnóstico computarizado', blurb: 'Escaneo completo de fallas y luz de check engine.', price: 'desde $380' },
  { icon: <Settings class="h-6 w-6" />, title: 'Suspensión y dirección', blurb: 'Amortiguadores, rótulas y terminales, revisión de 21 puntos.', price: 'desde $1,200' },
  { icon: <Battery class="h-6 w-6" />, title: 'Batería y sistema eléctrico', blurb: 'Carga, arranque y alternador probados en banco.', price: 'desde $520' },
  { icon: <Wind class="h-6 w-6" />, title: 'Aire acondicionado', blurb: 'Carga de gas, fugas y limpieza del sistema de clima.', price: 'desde $780' },
  { icon: <Wrench class="h-6 w-6" />, title: 'Afinación mayor', blurb: 'Bujías, filtros y ajuste general para máximo rendimiento.', price: 'desde $1,450' },
]

const fmtMXN = (amount: number): string =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 }).format(amount)

const PACKAGES: PricingTier[] = [
  {
    name: 'Básico',
    price: `${fmtMXN(450)}/servicio`,
    features: ['Revisión de 21 puntos', 'Cambio de aceite y filtro', 'Rotación de llantas'],
    cta: { label: 'Elegir plan', onClick: () => (location.hash = '#contact') },
  },
  {
    name: 'Esencial',
    price: `${fmtMXN(890)}/servicio`,
    highlighted: true,
    features: ['Todo lo del plan Básico', 'Revisión de frenos', 'Chequeo de batería', 'Niveles de líquidos completos'],
    cta: { label: 'Elegir plan', onClick: () => (location.hash = '#contact') },
  },
  {
    name: 'Premium',
    price: `${fmtMXN(1650)}/servicio`,
    features: ['Todo lo del plan Esencial', 'Alineación y balanceo', 'Diagnóstico computarizado', 'Garantía de 6 meses'],
    cta: { label: 'Elegir plan', onClick: () => (location.hash = '#contact') },
  },
]

const STEPS = [
  { label: 'Agenda tu cita', description: 'En línea o por teléfono, eliges día y hora.' },
  { label: 'Diagnóstico inicial', description: 'Revisamos tu unidad sin costo antes de cotizar.' },
  { label: 'Autorización', description: 'Te enviamos una cotización clara, tú decides.' },
  { label: 'Entrega y garantía', description: 'Recibes tu auto listo, con garantía por escrito.' },
]

const REVIEWS = [
  { name: 'Javier M.', quote: 'Diagnóstico rápido y honesto, no me vendieron nada de más.', rating: 5 },
  { name: 'Lupita R.', quote: 'Mi auto quedó como nuevo y el precio fue justo desde el inicio.', rating: 5 },
  { name: 'Ricardo T.', quote: 'Puntuales y con garantía por escrito. Ya es mi taller de confianza.', rating: 5 },
]

const FAQ = [
  { value: 'q1', title: '¿Necesito cita previa?', content: 'Sí, agenda desde la sección de contacto o por teléfono para asegurar tu horario y evitar esperas.' },
  { value: 'q2', title: '¿Dan garantía en las reparaciones?', content: 'Todas nuestras reparaciones incluyen garantía por escrito en mano de obra y refacciones instaladas.' },
  { value: 'q3', title: '¿Trabajan con todas las marcas?', content: 'Sí, atendemos autos y camionetas de cualquier marca, nacionales e importados.' },
  { value: 'q4', title: '¿Puedo esperar mientras revisan mi auto?', content: 'Claro, contamos con sala de espera con wifi. También podemos llevarte a tu destino y recogerte al terminar.' },
]

const CONTACT_ITEMS = [
  { label: 'Dirección', value: 'Av. Insurgentes Sur 1420, CDMX' },
  { label: 'Horario', value: 'Lun–Sáb · 8:00–18:00' },
  { label: 'Teléfono', value: '+52 55 4321 0987' },
  { label: 'Correo', value: 'contacto@tallergt.mx' },
]

export function App(): JSX.Element {
  const [service, setService] = createSignal('')
  const [date, setDate] = createSignal('')
  const [time, setTime] = createSignal('')
  const [name, setName] = createSignal('')
  const [phone, setPhone] = createSignal('')
  const [notes, setNotes] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <div class="min-h-screen bg-background text-foreground">
      <ScrollProgress />
      {/* Nav */}
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" class="flex items-center gap-2 font-semibold tracking-tight">
            <Wrench class="h-5 w-5 text-primary" /> Taller GT
          </a>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <Button ripple onClick={() => (location.hash = '#contact')}>
            Agenda tu cita
          </Button>
        </div>
      </header>

      {/* Hero */}
      <div id="top" class="relative overflow-hidden">
        <Parallax amount={40} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.18), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.16), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="neutral" class="mb-5">
            <ShieldCheck class="h-3.5 w-3.5" /> Mecánica automotriz integral
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Tu auto, en <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">manos de confianza</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Diagnóstico honesto, refacciones de calidad y garantía por escrito. Agenda tu cita y recibe tu cotización antes de autorizar nada.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#contact')}>
                Agenda tu cita
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => (location.hash = '#services')}>
              Ver servicios
            </Button>
          </div>
        </Section>
      </div>

      {/* Services */}
      <Section id="services">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Servicios" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Mantenimiento y reparación para que tu auto ande como nuevo.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <For each={SERVICES}>
            {(s) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {s.icon}
                </div>
                <h3 class="text-lg font-semibold">{s.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
                <p class="mt-4 text-sm font-medium text-primary">{s.price}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Stats / about */}
      <div id="about" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="grid gap-6 sm:grid-cols-3">
            <Stat label="Años de experiencia" value={15} tone="primary" />
            <Stat label="Autos atendidos" value={9800} format={(n) => `${Math.round(n / 100) / 10}k+`} tone="neutral" />
            <Stat label="Meses de garantía" value={6} tone="primary" />
          </div>
        </Section>
      </div>

      {/* Packages / pricing */}
      <Section id="packages">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Paquetes" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Elige el plan de mantenimiento que mejor se ajuste a tu auto.</p>
        </div>
        <PricingTable tiers={PACKAGES} />
      </Section>

      {/* How we work */}
      <div id="how-we-work" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Cómo trabajamos" onView />
            </h2>
            <p class="mt-2 text-muted-foreground">Un proceso claro, sin sorpresas en la cuenta final.</p>
          </div>
          <Stepper steps={STEPS} active={STEPS.length} />
        </Section>
      </div>

      {/* Reviews */}
      <Section id="reviews">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Lo que dicen" onView />
          </h2>
        </div>
        <div class="mx-auto max-w-2xl">
          <Carousel
            autoplayMs={5000}
            swipe
            slides={REVIEWS.map((r) => (
              <div class="px-2">
                <Card glass class="p-8 text-center">
                  <Rating value={r.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                  <p class="text-lg">"{r.quote}"</p>
                  <p class="mt-4 text-sm font-medium text-muted-foreground">— {r.name}</p>
                </Card>
              </div>
            ))}
          />
        </div>
      </Section>

      {/* FAQ */}
      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">
            <TextReveal text="Preguntas frecuentes" onView />
          </h2>
          <Accordion items={FAQ} />
        </div>
      </Section>

      {/* Booking + Contact */}
      <div id="contact" class="border-t border-border/60 bg-muted/30">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">
                <TextReveal text="Agenda tu cita" onView />
              </h2>
              <p class="mt-2 text-muted-foreground">Cuéntanos qué necesita tu auto y te confirmamos horario el mismo día.</p>

              <Descriptions class="mt-8" columns={2} items={CONTACT_ITEMS} />

              <Card glass class="mt-6 flex aspect-video items-center justify-center border border-dashed border-border/60 p-6 text-center text-sm text-muted-foreground">
                <span class="flex flex-col items-center gap-2">
                  <MapPin class="h-6 w-6 text-primary" /> Mapa próximamente
                </span>
              </Card>

              <div class="mt-6 flex gap-1 text-muted-foreground">
                <a href="#" aria-label="Correo" class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><Mail class="h-5 w-5" /></a>
                <a href="#" aria-label="Teléfono" class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><Phone class="h-5 w-5" /></a>
                <a href="#" aria-label="WhatsApp" class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
                <a href="#" aria-label="Instagram" class="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><AtSign class="h-5 w-5" /></a>
              </div>
            </div>

            <Card glass class="p-6">
              {sent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {name() || 'nos vemos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Te contactamos para confirmar tu cita.</p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submit}>
                  <div>
                    <label class="mb-1 block text-sm font-medium">Servicio</label>
                    <Select value={service()} onChange={setService} aria-label="Servicio" required>
                      <option value="" disabled>
                        Elige un servicio
                      </option>
                      <option value="aceite">Cambio de aceite</option>
                      <option value="frenos">Frenos</option>
                      <option value="alineacion">Alineación y balanceo</option>
                      <option value="diagnostico">Diagnóstico computarizado</option>
                      <option value="otro">Otro</option>
                    </Select>
                  </div>
                  <div class="grid grid-cols-2 gap-3">
                    <div>
                      <label class="mb-1 block text-sm font-medium">Fecha</label>
                      <DateField value={date()} onChange={setDate} label="Elige fecha" />
                    </div>
                    <div>
                      <label class="mb-1 block text-sm font-medium">Hora</label>
                      <Input value={time()} onInput={setTime} type="time" aria-label="Hora" required />
                    </div>
                  </div>
                  <div>
                    <label class="mb-1 block text-sm font-medium">Nombre</label>
                    <Input value={name()} onInput={setName} placeholder="Tu nombre" aria-label="Nombre" required />
                  </div>
                  <div>
                    <label class="mb-1 block text-sm font-medium">Teléfono</label>
                    <Input value={phone()} onInput={setPhone} placeholder="55 0000 0000" type="tel" aria-label="Teléfono" required />
                  </div>
                  <div>
                    <label class="mb-1 block text-sm font-medium">Notas (opcional)</label>
                    <Textarea value={notes()} onInput={setNotes} placeholder="Cuéntanos qué le pasa a tu auto…" rows={3} aria-label="Notas (opcional)" />
                  </div>
                  <Button ripple type="submit" class="w-full">Solicitar cita</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2"><Wrench class="h-4 w-4 text-primary" /> Taller GT · Mecánica Automotriz</span>
          <span>© 2026 Taller GT. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}
