import { Aurora, Badge, ScrollProgress } from '@a4ui/core'
import { A, Route, Router } from '@solidjs/router'
import { ShoppingCart, Star } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { cartCount } from './lib/cart'
import { Cart } from './pages/Cart'
import { Home } from './pages/Home'
import { NotFound } from './pages/NotFound'
import { Product } from './pages/Product'
import { Shop } from './pages/Shop'

const NAV = [
  { href: '/', label: 'Inicio' },
  { href: '/tienda', label: 'Tienda' },
]

function Layout(props: { children?: JSX.Element }): JSX.Element {
  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress />
      <Aurora />
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <A href="/" class="flex items-center gap-2 font-semibold tracking-tight">
            <Star class="h-5 w-5 fill-primary text-primary" /> Juguetería Luna
          </A>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>
              {(n) => (
                <A href={n.href} class="transition-colors hover:text-foreground" activeClass="text-foreground" end={n.href === '/'}>
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <A
            href="/carrito"
            class="relative flex h-10 w-10 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            aria-label="Carrito"
          >
            <ShoppingCart class="h-5 w-5" />
            {cartCount() > 0 && (
              <Badge tone="info" class="absolute right-1 top-1 px-1.5 py-0 text-[10px]">
                {cartCount()}
              </Badge>
            )}
          </A>
        </div>
      </header>

      {props.children}

      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2">
            <Star class="h-4 w-4 fill-primary text-primary" /> Juguetería Luna · Muñecas, peluches y juegos para crecer jugando
          </span>
          <nav class="flex items-center gap-5">
            <For each={NAV}>{(n) => <A href={n.href} class="transition-colors hover:text-foreground">{n.label}</A>}</For>
            <A href="/carrito" class="transition-colors hover:text-foreground">
              Carrito
            </A>
          </nav>
          <span>© 2026 Juguetería Luna. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}

export function App(): JSX.Element {
  return (
    <Router root={Layout}>
      <Route path="/" component={Home} />
      <Route path="/tienda" component={Shop} />
      <Route path="/producto/:id" component={Product} />
      <Route path="/carrito" component={Cart} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}
