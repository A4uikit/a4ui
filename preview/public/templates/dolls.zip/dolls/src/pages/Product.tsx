import { Badge, Button, Card, Section } from '@a4ui/core'
import { PriceTag, QuantityStepper } from '@a4ui/core/commerce'
import { A, useNavigate, useParams } from '@solidjs/router'
import { Baby, ChevronLeft, ShoppingCart, Sparkles, Star } from 'lucide-solid'
import { createEffect, createMemo, createSignal, For, type JSX, Show } from 'solid-js'

import { addToCart } from '../lib/cart'
import { getCategoryLabel, getProduct } from '../lib/products'

export function Product(): JSX.Element {
  const params = useParams<{ id: string }>()
  const navigate = useNavigate()
  const product = createMemo(() => getProduct(params.id))
  const [activeImage, setActiveImage] = createSignal(0)
  const [qty, setQty] = createSignal(1)
  const [added, setAdded] = createSignal(false)

  createEffect(() => {
    const id = params.id
    if (id) {
      setActiveImage(0)
      setQty(1)
      setAdded(false)
    }
  })

  const handleAdd = (): void => {
    const p = product()
    if (!p) return
    addToCart(p, qty())
    setAdded(true)
  }

  return (
    <Show
      when={product()}
      fallback={
        <Section class="text-center">
          <Sparkles class="mx-auto mb-4 h-10 w-10 text-primary" />
          <h1 class="text-3xl font-semibold tracking-tight">Juguete no encontrado</h1>
          <p class="mx-auto mt-3 max-w-md text-muted-foreground">
            Puede que este juguete ya no esté disponible. Vuelve a la tienda para seguir explorando.
          </p>
          <Button ripple class="mt-6" onClick={() => navigate('/tienda')}>
            Volver a la tienda
          </Button>
        </Section>
      }
    >
      {(p) => (
        <Section>
          <A
            href="/tienda"
            class="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ChevronLeft class="h-4 w-4" /> Volver a la tienda
          </A>
          <div class="grid gap-10 lg:grid-cols-2">
            {/* Gallery */}
            <div>
              <Card glass class="overflow-hidden p-0">
                <img src={p().images[activeImage()]} alt={p().name} class="aspect-square w-full object-cover" />
              </Card>
              <div class="mt-3 flex gap-3">
                <For each={p().images}>
                  {(img, i) => (
                    <button
                      type="button"
                      onClick={() => setActiveImage(i())}
                      class={`h-16 w-16 overflow-hidden rounded-xl border-2 transition-colors ${
                        activeImage() === i() ? 'border-primary' : 'border-transparent'
                      }`}
                    >
                      <img src={img} alt="" class="h-full w-full object-cover" />
                    </button>
                  )}
                </For>
              </div>
            </div>

            {/* Details */}
            <div>
              <div class="flex flex-wrap items-center gap-2">
                <Badge tone="neutral">{getCategoryLabel(p().category)}</Badge>
                <Show when={p().badge}>
                  <Badge tone={p().badgeTone === 'sale' ? 'warning' : 'info'}>{p().badge}</Badge>
                </Show>
                <Badge tone="success">
                  <Baby class="h-3.5 w-3.5" /> {p().age}
                </Badge>
              </div>
              <h1 class="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl">{p().name}</h1>
              <div class="mt-2 flex items-center gap-1 text-sm text-muted-foreground">
                <Star class="h-4 w-4 fill-primary text-primary" /> {p().rating.toFixed(1)} de 5
              </div>
              <div class="mt-4">
                <PriceTag amount={p().price} compareAt={p().compareAt} currency="MXN" locale="es-MX" size="lg" />
              </div>
              <p class="mt-6 text-muted-foreground">{p().description}</p>

              <div class="mt-8 flex items-center gap-4">
                <QuantityStepper value={qty()} onChange={setQty} min={1} max={10} />
                <Button ripple class="flex-1 gap-2" onClick={handleAdd}>
                  <ShoppingCart class="h-4 w-4" /> Agregar al carrito
                </Button>
              </div>
              <Show when={added()}>
                <p class="mt-4 text-sm font-medium text-primary">¡Agregado! Puedes seguir comprando o ir al carrito.</p>
              </Show>
            </div>
          </div>
        </Section>
      )}
    </Show>
  )
}
