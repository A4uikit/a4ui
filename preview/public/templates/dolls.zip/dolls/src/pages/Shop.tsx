import { Badge, Section, TextReveal } from '@a4ui/core'
import { ProductCard, ProductGrid } from '@a4ui/core/commerce'
import { A, useSearchParams } from '@solidjs/router'
import { Baby, Blocks, Gift, Heart, Puzzle, ShoppingBag, Sparkles } from 'lucide-solid'
import { createMemo, For, type JSX, Show } from 'solid-js'

import { addToCart } from '../lib/cart'
import { CATEGORIES, getCategoryLabel, PRODUCTS } from '../lib/products'

function categoryIcon(value: string): JSX.Element {
  switch (value) {
    case 'munecas':
      return <Baby class="h-4 w-4" />
    case 'peluches':
      return <Heart class="h-4 w-4" />
    case 'sets-de-juego':
      return <Gift class="h-4 w-4" />
    case 'bloques':
      return <Blocks class="h-4 w-4" />
    case 'juegos-de-mesa':
      return <Puzzle class="h-4 w-4" />
    default:
      return <Sparkles class="h-4 w-4" />
  }
}

export function Shop(): JSX.Element {
  const [searchParams, setSearchParams] = useSearchParams()

  const activeCategory = createMemo(() => {
    const c = searchParams.categoria
    return typeof c === 'string' ? c : 'todos'
  })

  const filtered = createMemo(() =>
    activeCategory() === 'todos' ? PRODUCTS : PRODUCTS.filter((p) => p.category === activeCategory()),
  )

  const selectCategory = (value: string): void => {
    setSearchParams({ categoria: value === 'todos' ? undefined : value })
  }

  return (
    <>
      <Section class="!pb-8 text-center">
        <Badge tone="info" class="mb-4">
          <ShoppingBag class="h-3.5 w-3.5" /> Tienda
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">
          <TextReveal text="Todos nuestros juguetes" />
        </h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Del primer año a la primaria: encuentra el regalo perfecto para cada etapa.
        </p>
      </Section>

      <Section class="!pt-0">
        {/* Category tiles */}
        <div class="mb-10 flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={() => selectCategory('todos')}
            class={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
              activeCategory() === 'todos'
                ? 'border-primary bg-primary/15 text-primary'
                : 'border-border text-muted-foreground hover:text-foreground'
            }`}
          >
            <Sparkles class="h-4 w-4" /> Todos
          </button>
          <For each={CATEGORIES}>
            {(c) => (
              <button
                type="button"
                onClick={() => selectCategory(c.value)}
                class={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                  activeCategory() === c.value
                    ? 'border-primary bg-primary/15 text-primary'
                    : 'border-border text-muted-foreground hover:text-foreground'
                }`}
              >
                {categoryIcon(c.value)} {c.label}
              </button>
            )}
          </For>
        </div>

        <Show
          when={filtered().length > 0}
          fallback={<p class="py-12 text-center text-muted-foreground">No encontramos juguetes en esta categoría.</p>}
        >
          <ProductGrid>
            <For each={filtered()}>
              {(p) => (
                <div class="flex flex-col gap-2">
                  <ProductCard
                    title={p.name}
                    price={p.price}
                    compareAt={p.compareAt}
                    image={p.image}
                    category={getCategoryLabel(p.category)}
                    rating={p.rating}
                    badge={p.badge}
                    badgeTone={p.badgeTone}
                    currency="MXN"
                    locale="es-MX"
                    tilt
                    spotlight
                    onAddToCart={() => addToCart(p)}
                  />
                  <A
                    href={`/producto/${p.id}`}
                    class="text-center text-sm font-medium text-primary transition-colors hover:underline"
                  >
                    Ver detalle →
                  </A>
                </div>
              )}
            </For>
          </ProductGrid>
        </Show>
      </Section>
    </>
  )
}
