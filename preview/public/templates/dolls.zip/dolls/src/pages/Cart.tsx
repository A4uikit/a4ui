import { Badge, Button, Card, Section } from '@a4ui/core'
import { CartLine, CartSummary } from '@a4ui/core/commerce'
import { useNavigate } from '@solidjs/router'
import { Gift, ShoppingBag } from 'lucide-solid'
import { createMemo, For, type JSX, Show } from 'solid-js'

import { cart, cartTotal, removeFromCart, updateQty } from '../lib/cart'

const SHIPPING = 99
const FREE_SHIPPING_THRESHOLD = 899

export function Cart(): JSX.Element {
  const navigate = useNavigate()

  const shipping = createMemo(() => (cart().length === 0 || cartTotal() >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING))
  const total = createMemo(() => cartTotal() + shipping())

  return (
    <Section>
      <div class="mb-10 text-center">
        <Badge tone="info" class="mb-4">
          <ShoppingBag class="h-3.5 w-3.5" /> Carrito
        </Badge>
        <h1 class="text-4xl font-semibold tracking-tight sm:text-5xl">Tu carrito</h1>
      </div>

      <Show
        when={cart().length > 0}
        fallback={
          <div class="mx-auto max-w-md text-center">
            <Gift class="mx-auto mb-4 h-10 w-10 text-primary" />
            <p class="text-muted-foreground">Tu carrito está vacío. Explora la tienda y encuentra el juguete perfecto.</p>
            <Button ripple class="mt-6" onClick={() => navigate('/tienda')}>
              Ir a la tienda
            </Button>
          </div>
        }
      >
        <div class="grid gap-10 lg:grid-cols-[1fr_320px]">
          <div class="space-y-4">
            <For each={cart()}>
              {(item) => (
                <Card glass class="p-4">
                  <CartLine
                    title={item.product.name}
                    price={item.product.price}
                    quantity={item.qty}
                    image={item.product.image}
                    currency="MXN"
                    locale="es-MX"
                    onQuantityChange={(q) => updateQty(item.product.id, q)}
                    onRemove={() => removeFromCart(item.product.id)}
                  />
                </Card>
              )}
            </For>
          </div>

          <div>
            <CartSummary
              lines={[
                { label: 'Subtotal', amount: cartTotal() },
                { label: 'Envío', amount: shipping() },
              ]}
              total={total()}
              currency="MXN"
              locale="es-MX"
              checkoutLabel="Finalizar compra"
              onCheckout={() => navigate('/')}
              class="sticky top-20"
            />
          </div>
        </div>
      </Show>
    </Section>
  )
}
