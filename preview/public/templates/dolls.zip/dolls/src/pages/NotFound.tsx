import { Button, Section } from '@a4ui/core'
import { useNavigate } from '@solidjs/router'
import { Puzzle } from 'lucide-solid'
import type { JSX } from 'solid-js'

export function NotFound(): JSX.Element {
  const navigate = useNavigate()

  return (
    <Section class="text-center">
      <Puzzle class="mx-auto mb-4 h-10 w-10 text-primary" />
      <h1 class="text-3xl font-semibold tracking-tight">Página no encontrada</h1>
      <p class="mx-auto mt-3 max-w-md text-muted-foreground">
        Parece que esta pieza no encaja. Regresa al inicio para seguir jugando.
      </p>
      <Button ripple class="mt-6" onClick={() => navigate('/')}>
        Volver al inicio
      </Button>
    </Section>
  )
}
