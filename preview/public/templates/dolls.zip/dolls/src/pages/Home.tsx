import { Badge, Button, Card, Carousel, GradientText, Input, Magnetic, Parallax, Section, Stat, TextReveal } from '@a4ui/core'
import { ProductCard } from '@a4ui/core/commerce'
import { A, useNavigate } from '@solidjs/router'
import { Baby, Blocks, Gift, Heart, Mail, Puzzle, ShoppingBag, Sparkles, Star } from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

import { addToCart } from '../lib/cart'
import { CATEGORIES, getCategoryLabel, PRODUCTS } from '../lib/products'

const FEATURED = PRODUCTS.slice(0, 5)

function categoryIcon(value: string): JSX.Element {
  switch (value) {
    case 'munecas':
      return <Baby class="h-6 w-6" />
    case 'peluches':
      return <Heart class="h-6 w-6" />
    case 'sets-de-juego':
      return <Gift class="h-6 w-6" />
    case 'bloques':
      return <Blocks class="h-6 w-6" />
    case 'juegos-de-mesa':
      return <Puzzle class="h-6 w-6" />
    default:
      return <Sparkles class="h-6 w-6" />
  }
}

export function Home(): JSX.Element {
  const navigate = useNavigate()
  const [email, setEmail] = createSignal('')
  const [subscribed, setSubscribed] = createSignal(false)

  const subscribe = (e: Event): void => {
    e.preventDefault()
    setSubscribed(true)
  }

  return (
    <>
      {/* Hero */}
      <div class="relative overflow-hidden">
        <Parallax amount={50} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="absolute inset-0"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.22), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.2), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="info" class="mb-5">
            <Sparkles class="h-3.5 w-3.5" /> Nueva colección de temporada
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Juguetes que hacen <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">brillar</GradientText> cada sonrisa
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Muñecas, peluches, bloques y juegos de mesa para todas las edades. Calidad segura, entrega rápida a todo México.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple class="gap-2" onClick={() => navigate('/tienda')}>
                <ShoppingBag class="h-4 w-4" /> Comprar ahora
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => navigate('/tienda')}>
              Ver categorías
            </Button>
          </div>
        </Section>
      </div>

      {/* Trust stats */}
      <div class="border-y border-border/60 bg-muted/20">
        <Section class="!py-14">
          <div class="grid gap-8 sm:grid-cols-3">
            <Stat
              label="Juguetes entregados"
              value={8500}
              format={(n) => `${Math.round(n).toLocaleString('es-MX')}+`}
              icon={<Gift class="h-5 w-5" />}
              tone="primary"
            />
            <Stat
              label="Familias felices"
              value={50000}
              format={(n) => `${Math.round(n).toLocaleString('es-MX')}+`}
              icon={<Heart class="h-5 w-5" />}
              tone="success"
              delay={0.1}
            />
            <Stat
              label="Calificación promedio"
              value={4.8}
              format={(n) => `${n.toFixed(1)} / 5`}
              icon={<Star class="h-5 w-5" />}
              tone="neutral"
              delay={0.2}
            />
          </div>
        </Section>
      </div>

      {/* Category tiles */}
      <Section id="categorias">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Explora por categoría" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Encuentra el juguete perfecto para cada etapa.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-3 lg:grid-cols-5">
          <For each={CATEGORIES}>
            {(c) => (
              <A href={`/tienda?categoria=${c.value}`} class="block">
                <Card glass tilt spotlight class="h-full p-6 text-center">
                  <div class="mx-auto mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/15 text-primary">
                    {categoryIcon(c.value)}
                  </div>
                  <h3 class="font-semibold">{c.label}</h3>
                </Card>
              </A>
            )}
          </For>
        </div>
      </Section>

      {/* Featured collection */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mb-8 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Colección destacada" onView />
            </h2>
            <p class="mt-2 text-muted-foreground">Los favoritos de la temporada, elegidos por las familias.</p>
          </div>
          <Carousel
            autoplayMs={5000}
            slides={FEATURED.map((p) => (
              <div class="px-2">
                <div class="mx-auto max-w-xs">
                  <ProductCard
                    title={p.name}
                    price={p.price}
                    compareAt={p.compareAt}
                    image={p.image}
                    category={getCategoryLabel(p.category)}
                    rating={p.rating}
                    badge={p.badge}
                    badgeTone={p.badgeTone}
                    currency="MXN"
                    locale="es-MX"
                    tilt
                    spotlight
                    onAddToCart={() => addToCart(p)}
                  />
                  <A
                    href={`/producto/${p.id}`}
                    class="mt-3 block text-center text-sm font-medium text-primary transition-colors hover:underline"
                  >
                    Ver detalle →
                  </A>
                </div>
              </div>
            ))}
          />
        </Section>
      </div>

      {/* Newsletter */}
      <Section class="!py-16 text-center">
        <Badge tone="neutral" class="mb-4">
          <Mail class="h-3.5 w-3.5" /> Newsletter
        </Badge>
        <h2 class="text-3xl font-semibold tracking-tight">Sé la primera en enterarte</h2>
        <p class="mx-auto mt-2 max-w-md text-muted-foreground">
          Ofertas, lanzamientos y sorpresas directo a tu correo. Sin spam, lo prometemos.
        </p>
        {subscribed() ? (
          <Badge tone="success" pulse class="mt-6">
            ¡Gracias por suscribirte!
          </Badge>
        ) : (
          <form class="mx-auto mt-6 flex max-w-md flex-col gap-3 sm:flex-row" onSubmit={subscribe}>
            <Input
              value={email()}
              onInput={setEmail}
              type="email"
              placeholder="tu@correo.com"
              aria-label="Correo electrónico"
              required
              class="flex-1"
            />
            <Button ripple type="submit">
              Suscribirme
            </Button>
          </form>
        )}
      </Section>
    </>
  )
}
