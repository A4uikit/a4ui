import type { ProductBadgeTone } from '@a4ui/core/commerce'

export interface Product {
  id: string
  name: string
  category: string
  price: number
  compareAt?: number
  image: string
  images: string[]
  badge?: string
  badgeTone?: ProductBadgeTone
  age: string
  rating: number
  description: string
}

export interface Category {
  value: string
  label: string
}

export const CATEGORIES: Category[] = [
  { value: 'munecas', label: 'Muñecas' },
  { value: 'peluches', label: 'Peluches' },
  { value: 'sets-de-juego', label: 'Sets de juego' },
  { value: 'bloques', label: 'Bloques' },
  { value: 'juegos-de-mesa', label: 'Juegos de mesa' },
]

function gallery(id: string): string[] {
  return [
    `https://picsum.photos/seed/${id}/600/600`,
    `https://picsum.photos/seed/${id}-2/600/600`,
    `https://picsum.photos/seed/${id}-3/600/600`,
  ]
}

export const PRODUCTS: Product[] = [
  {
    id: 'muneca-luna-estrella',
    name: 'Muñeca Luna Estrella',
    category: 'munecas',
    price: 349,
    image: gallery('muneca-luna-estrella')[0],
    images: gallery('muneca-luna-estrella'),
    badge: 'Nuevo',
    badgeTone: 'new',
    age: '3+ años',
    rating: 4.8,
    description:
      'Muñeca articulada de 30 cm con cabello para peinar y vestido reversible. Incluye cepillo y accesorios para inventar mil historias.',
  },
  {
    id: 'osito-nube',
    name: 'Osito Nube',
    category: 'peluches',
    price: 259,
    image: gallery('osito-nube')[0],
    images: gallery('osito-nube'),
    age: '0+ años',
    rating: 4.9,
    description: 'Peluche súper suave de 25 cm, ideal desde recién nacido. Material hipoalergénico y lavable a máquina.',
  },
  {
    id: 'set-te-princesas',
    name: 'Set de Té de Princesas',
    category: 'sets-de-juego',
    price: 429,
    compareAt: 549,
    image: gallery('set-te-princesas')[0],
    images: gallery('set-te-princesas'),
    badge: 'Oferta',
    badgeTone: 'sale',
    age: '3+ años',
    rating: 4.6,
    description: 'Vajilla de té de 15 piezas en plástico resistente libre de BPA, perfecta para meriendas de fantasía.',
  },
  {
    id: 'mega-torre-bloques',
    name: 'Mega Torre de Bloques',
    category: 'bloques',
    price: 599,
    image: gallery('mega-torre-bloques')[0],
    images: gallery('mega-torre-bloques'),
    age: '4+ años',
    rating: 4.7,
    description: '150 piezas de bloques de construcción compatibles, para armar torres, casas y vehículos sin límite.',
  },
  {
    id: 'cocina-mini-chef',
    name: 'Cocina Mini Chef',
    category: 'sets-de-juego',
    price: 899,
    image: gallery('cocina-mini-chef')[0],
    images: gallery('cocina-mini-chef'),
    badge: 'Nuevo',
    badgeTone: 'new',
    age: '3+ años',
    rating: 4.9,
    description: 'Cocina de juguete con luces, sonidos y 20 accesorios para los chefs más pequeños de la casa.',
  },
  {
    id: 'conejito-algodon',
    name: 'Conejito Algodón',
    category: 'peluches',
    price: 219,
    image: gallery('conejito-algodon')[0],
    images: gallery('conejito-algodon'),
    age: '0+ años',
    rating: 4.8,
    description: 'Peluche de conejito de orejas largas, 20 cm, suave al tacto y del tamaño perfecto para abrazar.',
  },
  {
    id: 'capitan-cometa',
    name: 'Capitán Cometa',
    category: 'munecas',
    price: 299,
    image: gallery('capitan-cometa')[0],
    images: gallery('capitan-cometa'),
    age: '4+ años',
    rating: 4.5,
    description: 'Figura de acción articulada de 15 cm con capa y accesorios espaciales intercambiables.',
  },
  {
    id: 'aventura-magica',
    name: 'Aventura Mágica',
    category: 'juegos-de-mesa',
    price: 349,
    compareAt: 429,
    image: gallery('aventura-magica')[0],
    images: gallery('aventura-magica'),
    badge: 'Oferta',
    badgeTone: 'sale',
    age: '5+ años',
    rating: 4.7,
    description: 'Juego de mesa cooperativo para 2 a 4 jugadores. Una aventura distinta en cada partida.',
  },
]

export function getProduct(id: string): Product | undefined {
  return PRODUCTS.find((p) => p.id === id)
}

export function getCategoryLabel(value: string): string {
  return CATEGORIES.find((c) => c.value === value)?.label ?? value
}
