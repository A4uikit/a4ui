import { createCart } from '@a4ui/core/commerce'

import type { Product } from './products'

const cartStore = createCart<Product>()

export const cart = cartStore.items
export const cartCount = cartStore.count
export const cartTotal = cartStore.subtotal

export function addToCart(product: Product, qty = 1): void {
  cartStore.add(product, qty)
}

export function updateQty(id: string, qty: number): void {
  cartStore.setQty(id, qty)
}

export function removeFromCart(id: string): void {
  cartStore.remove(id)
}
