# Template: `dolls` — Toy / doll store

A colorful storefront for a toy/doll shop. Same commerce bones as `phones`, but a
warm, playful visual identity — proves the design system re-themes to a totally
different mood without new component code.

## Sections

1. **Top bar** — logo, playful nav, cart `Badge`.
2. **Hero** — bright hero with a featured collection, CTA "Shop now".
3. **Category tiles** — Dolls, Plush, Playsets, Ages 0–3… (`Card` grid, big imagery)
4. **Featured collection** — `Carousel` (swipe) of hero products.
5. **Product grid** — `ProductGrid` + `ProductCard` (soft, rounded, `Badge` "New"/"Sale").
6. **Product detail** — gallery, description, age badge, `QuantityStepper`, add-to-cart.
7. **Cart** — `CartLine` + `CartSummary`.
8. **Newsletter** — email capture. (`Input`, `Button ripple`)
9. **Footer**

## Custom theme

Warm/pastel: candy-pink or coral primary, mint/amber accent, **large radius**,
rounded friendly fonts. This is the main point of the template — a bespoke
`dolls` theme (all 15 tokens, light+dark, WCAG AA), possibly registered as a
reusable A4ui theme upstream.

## Tasks (→ issues)

- [ ] Scaffold app
- [ ] `dolls` warm theme (15 tokens, AA contrast, light+dark)
- [ ] Product data + sample catalog
- [ ] Reuse cart store pattern from `phones`
- [ ] Top bar + hero
- [ ] Category tiles
- [ ] Featured carousel
- [ ] Product grid + detail
- [ ] Cart + newsletter + footer
- [ ] Responsive pass + deploy
