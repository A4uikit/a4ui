# Template: `phones` — Phone store (e-commerce)

A storefront for selling phones. Goal: browse a catalog, filter, view a product,
add to cart, and reach checkout. Exercises the full `@a4ui/core/commerce` set.

## Sections / routes

1. **Top bar** — logo, search, cart button with item-count `Badge`. (`AppShell`)
2. **Hero** — featured flagship phone, CTA. Glass + spotlight.
3. **Filters** — brand, price range, storage, 5G. (`FilterGroup`, `SegmentedControl`, `Slider`)
4. **Catalog grid** — `ProductGrid` of `ProductCard tilt spotlight` (image, badge, price, rating, add-to-cart).
5. **Product detail** — gallery (`Image blurUp`), specs (`Descriptions`), `Rating`, `QuantityStepper`, add-to-cart, related.
6. **Cart drawer** — `Drawer` with `CartLine` rows + `CartSummary`.
7. **Checkout** — multi-step (`Stepper`): shipping, payment, review. (`Form`, `Input`, `Select`)
8. **Footer**

## State

Lightweight cart store (Solid store/signal): add / remove / qty / totals.

## Custom theme

Sleek tech: dark default, electric-blue/violet primary, tight radius.

## Tasks (→ issues)

- [ ] Scaffold app + routing (hash or @solidjs/router)
- [ ] `phones` theme tokens
- [ ] Product data model + sample catalog
- [ ] Cart store (add/remove/qty/totals)
- [ ] Top bar + cart badge
- [ ] Hero
- [ ] Filters
- [ ] Catalog grid (ProductCard)
- [ ] Product detail page
- [ ] Cart drawer (CartLine + CartSummary)
- [ ] Checkout stepper + form validation
- [ ] Responsive pass + deploy
