import a4ui from '@a4ui/core/preset'

/** @type {import('tailwindcss').Config} */
export default {
  presets: [a4ui],
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
    // scan the shipped components so their utility classes are generated
    './node_modules/@a4ui/core/dist/**/*.js',
  ],
}
