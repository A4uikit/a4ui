import { defineConfig } from 'vite'
import solid from 'vite-plugin-solid'

export default defineConfig({
  plugins: [solid()],
  // @a4ui/core is consumed as prebuilt ESM (dist); solid-js is external to it, so
  // dedupe to a single copy — two copies silently break Solid reactivity.
  resolve: { dedupe: ['solid-js', '@solidjs/router'] },
})
