import { Badge, Button, Card, Descriptions, Rating, Section } from '@a4ui/core'
import { PriceTag, ProductCard, QuantityStepper } from '@a4ui/core/commerce'
import { A, useNavigate, useParams } from '@solidjs/router'
import { Check, ChevronLeft, ShoppingCart } from 'lucide-solid'
import { createMemo, createSignal, For, type JSX, Show } from 'solid-js'

import { cart } from '../lib/cart'
import { getPhoneBySlug, PHONES } from '../lib/products'

export function Product(): JSX.Element {
  const params = useParams<{ slug: string }>()
  const navigate = useNavigate()
  const [qty, setQty] = createSignal(1)
  const [added, setAdded] = createSignal(false)

  const phone = createMemo(() => getPhoneBySlug(params.slug))

  const related = createMemo(() => {
    const p = phone()
    if (!p) return []
    return PHONES.filter((other) => other.category === p.category && other.id !== p.id).slice(0, 3)
  })

  const handleAdd = (): void => {
    const p = phone()
    if (!p) return
    cart.add(p, qty())
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <Show
      when={phone()}
      fallback={
        <Section class="text-center">
          <h1 class="text-2xl font-semibold">No encontramos ese celular</h1>
          <p class="mt-2 text-muted-foreground">Puede que ya no esté disponible o el enlace sea incorrecto.</p>
          <Button ripple class="mt-6" onClick={() => navigate('/catalogo')}>
            Volver al catálogo
          </Button>
        </Section>
      }
    >
      {(p) => (
        <>
          <Section class="!pb-6">
            <A href="/catalogo" class="inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground">
              <ChevronLeft class="h-4 w-4" /> Volver al catálogo
            </A>
          </Section>

          <Section class="!pt-2">
            <div class="grid gap-10 lg:grid-cols-2">
              {/* Gallery */}
              <div>
                <Card glass class="overflow-hidden p-0">
                  <img src={p().image} alt={p().name} class="aspect-square w-full object-cover" loading="lazy" />
                </Card>
              </div>

              {/* Info */}
              <div>
                <p class="text-sm font-medium text-primary">{p().brand}</p>
                <h1 class="mt-1 text-3xl font-semibold tracking-tight sm:text-4xl">{p().name}</h1>
                <p class="mt-2 text-muted-foreground">{p().tagline}</p>

                <div class="mt-4 flex items-center gap-3">
                  <Rating value={p().rating} readonly max={5} />
                  <span class="text-sm text-muted-foreground">{p().rating.toFixed(1)} / 5</span>
                  {p().badge && (
                    <Badge tone={p().badgeTone === 'sale' ? 'warning' : 'info'}>{p().badge}</Badge>
                  )}
                </div>

                <div class="mt-6">
                  <PriceTag amount={p().price} compareAt={p().compareAt} currency="MXN" locale="es-MX" size="lg" />
                </div>

                <p class="mt-4 text-sm text-muted-foreground">{p().description}</p>

                <div class="mt-6">
                  <p class="mb-2 text-sm font-medium">Colores disponibles</p>
                  <div class="flex flex-wrap gap-2">
                    <For each={p().colors}>
                      {(c) => (
                        <span class="rounded-lg border border-border px-3 py-1.5 text-sm text-muted-foreground">{c}</span>
                      )}
                    </For>
                  </div>
                </div>

                <div class="mt-8 flex flex-wrap items-center gap-4">
                  <QuantityStepper value={qty()} onChange={setQty} min={1} max={10} />
                  <Button ripple class="gap-2" onClick={handleAdd}>
                    {added() ? <Check class="h-4 w-4" /> : <ShoppingCart class="h-4 w-4" />}
                    {added() ? 'Agregado al carrito' : 'Agregar al carrito'}
                  </Button>
                </div>

                <div class="mt-10">
                  <h2 class="mb-3 text-lg font-semibold">Especificaciones</h2>
                  <Descriptions
                    columns={2}
                    items={[
                      { label: 'Chip', value: p().chip },
                      { label: 'RAM', value: `${p().ramGb} GB` },
                      { label: 'Almacenamiento', value: `${p().storageGb} GB` },
                      { label: 'Pantalla', value: `${p().screenIn}"` },
                      { label: 'Cámara', value: p().camera },
                      { label: 'Batería', value: p().battery },
                      { label: 'Conectividad', value: p().fiveG ? '5G / 4G LTE' : '4G LTE' },
                      { label: 'Categoría', value: p().category },
                    ]}
                  />
                </div>
              </div>
            </div>
          </Section>

          {/* Related */}
          <Show when={related().length > 0}>
            <Section>
              <h2 class="mb-6 text-2xl font-semibold tracking-tight">También te puede interesar</h2>
              <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                <For each={related()}>
                  {(r) => (
                    <A href={`/producto/${r.slug}`} class="block h-full">
                      <ProductCard
                        title={r.name}
                        brand={r.brand}
                        category={r.category}
                        price={r.price}
                        compareAt={r.compareAt}
                        image={r.image}
                        rating={r.rating}
                        badge={r.badge}
                        badgeTone={r.badgeTone}
                        currency="MXN"
                        locale="es-MX"
                        tilt
                        spotlight
                      />
                    </A>
                  )}
                </For>
              </div>
            </Section>
          </Show>
        </>
      )}
    </Show>
  )
}
