import { Badge, Button, Card, GradientText, Magnetic, Parallax, Section, Stat, TextReveal } from '@a4ui/core'
import { PriceTag, ProductCard } from '@a4ui/core/commerce'
import { A } from '@solidjs/router'
import { Layers, ShieldCheck, Smartphone, Sparkles, Tag, Truck, Zap } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { cart } from '../lib/cart'
import { getPhoneBySlug, PHONES, type PhoneCategory } from '../lib/products'

const FEATURED_SLUG = 'nova-x15-pro'

const CATEGORIES: { value: PhoneCategory; icon: JSX.Element; blurb: string }[] = [
  { value: 'Gama alta', icon: <Sparkles class="h-6 w-6" />, blurb: 'Lo último en potencia y cámara' },
  { value: 'Gama media', icon: <Smartphone class="h-6 w-6" />, blurb: 'El mejor balance precio-potencia' },
  { value: 'Económico', icon: <Tag class="h-6 w-6" />, blurb: 'Lo esencial, sin pagar de más' },
  { value: 'Plegable', icon: <Layers class="h-6 w-6" />, blurb: 'El futuro de la pantalla, hoy' },
]

const TRUST = [
  { icon: <Truck class="h-5 w-5" />, title: 'Envío a todo México', blurb: 'Gratis en compras mayores a $1,500 MXN.' },
  { icon: <ShieldCheck class="h-5 w-5" />, title: 'Garantía oficial', blurb: 'Todos los equipos con garantía de fábrica.' },
  { icon: <Zap class="h-5 w-5" />, title: 'Activación 5G', blurb: 'Listos para la red 5G de todos los operadores.' },
]

export function Home(): JSX.Element {
  const featured = getPhoneBySlug(FEATURED_SLUG)

  return (
    <>
      {/* Hero */}
      <div class="relative overflow-hidden">
        <Parallax amount={50} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.22), transparent 70%), radial-gradient(40% 40% at 85% 15%, hsl(var(--accent) / 0.18), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-24 text-center">
          <Badge tone="info" class="mb-5">
            <Zap class="h-3.5 w-3.5" /> Envíos a todo México
          </Badge>
          <h1 class="mx-auto max-w-2xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            El celular que buscas, <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">siempre conectado</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Flagships, gama media y equipos plegables de las mejores marcas, con garantía oficial y envío a todo el país.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14} class="inline-flex">
              <A href="/catalogo">
                <Button ripple>Ver catálogo</Button>
              </A>
            </Magnetic>
            {featured && (
              <A href={`/producto/${featured.slug}`}>
                <Button variant="outline">Ver {featured.name}</Button>
              </A>
            )}
          </div>
        </Section>
      </div>

      {/* Featured phone */}
      {featured && (
        <Section class="!pt-0">
          <Card glass tilt spotlight class="grid gap-8 overflow-hidden p-6 sm:p-10 lg:grid-cols-2 lg:items-center">
            <div class="order-2 lg:order-1">
              <Badge tone="info" class="mb-4">
                Destacado
              </Badge>
              <h2 class="text-3xl font-semibold tracking-tight">
                <TextReveal text={featured.name} />
              </h2>
              <p class="mt-2 text-muted-foreground">{featured.tagline}</p>
              <ul class="mt-5 space-y-1.5 text-sm text-muted-foreground">
                <li>• {featured.chip} · {featured.ramGb}GB RAM · {featured.storageGb}GB</li>
                <li>• {featured.camera}</li>
                <li>• {featured.battery}</li>
              </ul>
              <div class="mt-6">
                <PriceTag amount={featured.price} compareAt={featured.compareAt} currency="MXN" locale="es-MX" size="lg" />
              </div>
              <div class="mt-6 flex flex-wrap gap-3">
                <Button ripple onClick={() => cart.add(featured, 1)}>
                  Agregar al carrito
                </Button>
                <A href={`/producto/${featured.slug}`}>
                  <Button variant="outline">Ver detalle</Button>
                </A>
              </div>
            </div>
            <div class="order-1 lg:order-2">
              <ProductCard
                title={featured.name}
                brand={featured.brand}
                category={featured.category}
                price={featured.price}
                compareAt={featured.compareAt}
                image={featured.image}
                rating={featured.rating}
                badge={featured.badge}
                badgeTone={featured.badgeTone}
                currency="MXN"
                locale="es-MX"
                tilt
                spotlight
              />
            </div>
          </Card>
        </Section>
      )}

      {/* Categories */}
      <Section>
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Explora por categoría" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Encuentra el equipo que se ajusta a tu presupuesto.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <For each={CATEGORIES}>
            {(c) => (
              <A href={`/catalogo?categoria=${encodeURIComponent(c.value)}`}>
                <Card glass tilt spotlight class="h-full p-6">
                  <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                    {c.icon}
                  </div>
                  <h3 class="text-lg font-semibold">{c.value}</h3>
                  <p class="mt-1 text-sm text-muted-foreground">{c.blurb}</p>
                </Card>
              </A>
            )}
          </For>
        </div>
      </Section>

      {/* Trust / stats */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="grid gap-6 sm:grid-cols-3">
            <Stat label="Clientes felices" value={18400} format={(n) => `${Math.round(n / 100) / 10}k+`} tone="primary" delay={0} />
            <Stat label="Modelos disponibles" value={PHONES.length} tone="neutral" delay={0.1} />
            <Stat label="Envíos a todo México" value={32} format={(n) => `${Math.round(n)} estados`} tone="primary" delay={0.2} />
          </div>
          <div class="mt-10 grid gap-5 sm:grid-cols-3">
            <For each={TRUST}>
              {(t) => (
                <div class="flex items-start gap-3">
                  <div class="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                    {t.icon}
                  </div>
                  <div>
                    <p class="font-medium">{t.title}</p>
                    <p class="text-sm text-muted-foreground">{t.blurb}</p>
                  </div>
                </div>
              )}
            </For>
          </div>
        </Section>
      </div>
    </>
  )
}
