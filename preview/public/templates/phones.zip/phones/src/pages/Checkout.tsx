import { Badge, Button, Card, Descriptions, Input, Section, Select, Stepper } from '@a4ui/core'
import { CartSummary } from '@a4ui/core/commerce'
import { A } from '@solidjs/router'
import { CheckCircle2, ShoppingBag } from 'lucide-solid'
import { createMemo, createSignal, type JSX, Show } from 'solid-js'

import { cart, cartShipping, cartTotal } from '../lib/cart'

const STEPS = [
  { label: 'Envío', description: 'Dirección de entrega' },
  { label: 'Pago', description: 'Método de pago' },
  { label: 'Revisión', description: 'Confirma tu pedido' },
]

const ESTADOS = ['CDMX', 'Jalisco', 'Nuevo León', 'Puebla', 'Querétaro', 'Yucatán', 'Otro']
const METODOS_PAGO = [
  { value: 'tarjeta', label: 'Tarjeta de crédito o débito' },
  { value: 'transferencia', label: 'Transferencia bancaria' },
  { value: 'contra-entrega', label: 'Pago contra entrega' },
]

export function Checkout(): JSX.Element {
  const [step, setStep] = createSignal(0)
  const [orderPlaced, setOrderPlaced] = createSignal(false)
  const [orderId] = createSignal(`CMX-${Math.floor(100000 + Math.random() * 900000)}`)

  const [nombre, setNombre] = createSignal('')
  const [apellidos, setApellidos] = createSignal('')
  const [direccion, setDireccion] = createSignal('')
  const [ciudad, setCiudad] = createSignal('')
  const [estado, setEstado] = createSignal(ESTADOS[0])
  const [cp, setCp] = createSignal('')
  const [telefono, setTelefono] = createSignal('')

  const [metodoPago, setMetodoPago] = createSignal(METODOS_PAGO[0].value)
  const [numTarjeta, setNumTarjeta] = createSignal('')
  const [vencimiento, setVencimiento] = createSignal('')
  const [cvv, setCvv] = createSignal('')

  const shippingValid = createMemo(
    () => nombre().trim() !== '' && apellidos().trim() !== '' && direccion().trim() !== '' && ciudad().trim() !== '' && cp().trim() !== '' && telefono().trim() !== '',
  )
  const paymentValid = createMemo(() => (metodoPago() !== 'tarjeta' ? true : numTarjeta().trim() !== '' && vencimiento().trim() !== '' && cvv().trim() !== ''))

  const summaryLines = createMemo(() => [
    { label: 'Subtotal', amount: cart.subtotal() },
    { label: 'Envío', amount: cartShipping() },
  ])

  const confirmOrder = (): void => {
    cart.clear()
    setOrderPlaced(true)
  }

  return (
    <Section>
      <Show
        when={!orderPlaced()}
        fallback={
          <div class="flex flex-col items-center py-16 text-center">
            <CheckCircle2 class="mb-4 h-12 w-12 text-primary" />
            <Badge tone="success" pulse class="mb-3">
              Pedido confirmado
            </Badge>
            <h1 class="text-2xl font-semibold">¡Gracias por tu compra!</h1>
            <p class="mt-2 text-muted-foreground">
              Tu número de pedido es <span class="font-medium text-foreground">{orderId()}</span>. Te enviaremos la confirmación por correo.
            </p>
            <A href="/">
              <Button ripple class="mt-6">
                Volver al inicio
              </Button>
            </A>
          </div>
        }
      >
        <Show
          when={cart.items().length > 0}
          fallback={
            <div class="flex flex-col items-center py-16 text-center">
              <ShoppingBag class="mb-4 h-10 w-10 text-muted-foreground" />
              <p class="text-lg font-medium">Tu carrito está vacío</p>
              <p class="mt-1 text-sm text-muted-foreground">Agrega productos antes de continuar al pago.</p>
              <A href="/catalogo">
                <Button ripple class="mt-6">
                  Ir al catálogo
                </Button>
              </A>
            </div>
          }
        >
          <h1 class="mb-8 text-3xl font-semibold tracking-tight">Checkout</h1>

          <Stepper steps={STEPS} active={step()} onStepClick={(i) => i < step() && setStep(i)} class="mb-10" />

          <div class="mx-auto max-w-2xl">
            <Card glass class="p-6 sm:p-8">
              <Show when={step() === 0}>
                <div class="space-y-4">
                  <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label for="checkout-nombre" class="mb-1 block text-sm font-medium">Nombre</label>
                      <Input id="checkout-nombre" value={nombre()} onInput={setNombre} placeholder="Tu nombre" required />
                    </div>
                    <div>
                      <label for="checkout-apellidos" class="mb-1 block text-sm font-medium">Apellidos</label>
                      <Input id="checkout-apellidos" value={apellidos()} onInput={setApellidos} placeholder="Tus apellidos" required />
                    </div>
                  </div>
                  <div>
                    <label for="checkout-direccion" class="mb-1 block text-sm font-medium">Dirección</label>
                    <Input id="checkout-direccion" value={direccion()} onInput={setDireccion} placeholder="Calle, número, colonia" required />
                  </div>
                  <div class="grid gap-4 sm:grid-cols-3">
                    <div>
                      <label for="checkout-ciudad" class="mb-1 block text-sm font-medium">Ciudad</label>
                      <Input id="checkout-ciudad" value={ciudad()} onInput={setCiudad} placeholder="Ciudad" required />
                    </div>
                    <div>
                      <label for="checkout-estado" class="mb-1 block text-sm font-medium">Estado</label>
                      <Select id="checkout-estado" value={estado()} onChange={setEstado}>
                        {ESTADOS.map((e) => (
                          <option value={e}>{e}</option>
                        ))}
                      </Select>
                    </div>
                    <div>
                      <label for="checkout-cp" class="mb-1 block text-sm font-medium">Código postal</label>
                      <Input id="checkout-cp" value={cp()} onInput={setCp} placeholder="00000" required />
                    </div>
                  </div>
                  <div>
                    <label for="checkout-telefono" class="mb-1 block text-sm font-medium">Teléfono</label>
                    <Input id="checkout-telefono" value={telefono()} onInput={setTelefono} placeholder="55 0000 0000" type="tel" required />
                  </div>
                  <Button ripple class="mt-2 w-full" disabled={!shippingValid()} onClick={() => setStep(1)}>
                    Continuar a pago
                  </Button>
                </div>
              </Show>

              <Show when={step() === 1}>
                <div class="space-y-4">
                  <div>
                    <label for="checkout-metodo-pago" class="mb-1 block text-sm font-medium">Método de pago</label>
                    <Select id="checkout-metodo-pago" value={metodoPago()} onChange={setMetodoPago}>
                      {METODOS_PAGO.map((m) => (
                        <option value={m.value}>{m.label}</option>
                      ))}
                    </Select>
                  </div>
                  <Show when={metodoPago() === 'tarjeta'}>
                    <div>
                      <label for="checkout-num-tarjeta" class="mb-1 block text-sm font-medium">Número de tarjeta</label>
                      <Input id="checkout-num-tarjeta" value={numTarjeta()} onInput={setNumTarjeta} placeholder="0000 0000 0000 0000" required />
                    </div>
                    <div class="grid gap-4 sm:grid-cols-2">
                      <div>
                        <label for="checkout-vencimiento" class="mb-1 block text-sm font-medium">Vencimiento</label>
                        <Input id="checkout-vencimiento" value={vencimiento()} onInput={setVencimiento} placeholder="MM/AA" required />
                      </div>
                      <div>
                        <label for="checkout-cvv" class="mb-1 block text-sm font-medium">CVV</label>
                        <Input id="checkout-cvv" value={cvv()} onInput={setCvv} placeholder="123" required />
                      </div>
                    </div>
                  </Show>
                  <div class="flex gap-3">
                    <Button variant="outline" class="w-full" onClick={() => setStep(0)}>
                      Atrás
                    </Button>
                    <Button ripple class="w-full" disabled={!paymentValid()} onClick={() => setStep(2)}>
                      Revisar pedido
                    </Button>
                  </div>
                </div>
              </Show>

              <Show when={step() === 2}>
                <div class="space-y-6">
                  <div>
                    <h2 class="mb-3 text-sm font-medium">Dirección de entrega</h2>
                    <Descriptions
                      columns={1}
                      items={[
                        { label: 'Nombre', value: `${nombre()} ${apellidos()}` },
                        { label: 'Dirección', value: `${direccion()}, ${ciudad()}, ${estado()}, CP ${cp()}` },
                        { label: 'Teléfono', value: telefono() },
                        { label: 'Método de pago', value: METODOS_PAGO.find((m) => m.value === metodoPago())?.label ?? '' },
                      ]}
                    />
                  </div>
                  <CartSummary lines={summaryLines()} total={cartTotal()} currency="MXN" locale="es-MX" checkoutLabel="Confirmar pedido" onCheckout={confirmOrder} />
                  <Button variant="outline" class="w-full" onClick={() => setStep(1)}>
                    Atrás
                  </Button>
                </div>
              </Show>
            </Card>
          </div>
        </Show>
      </Show>
    </Section>
  )
}
