import { Button, Section } from '@a4ui/core'
import { CartLine, CartSummary } from '@a4ui/core/commerce'
import { A, useNavigate } from '@solidjs/router'
import { ShoppingCart } from 'lucide-solid'
import { createMemo, For, type JSX, Show } from 'solid-js'

import { cart, cartShipping, cartTotal } from '../lib/cart'

export function Cart(): JSX.Element {
  const navigate = useNavigate()

  const lines = createMemo(() => [
    { label: 'Subtotal', amount: cart.subtotal() },
    { label: 'Envío', amount: cartShipping() },
  ])

  return (
    <Section>
      <h1 class="mb-8 text-3xl font-semibold tracking-tight">Tu carrito</h1>

      <Show
        when={cart.items().length > 0}
        fallback={
          <div class="flex flex-col items-center py-16 text-center">
            <ShoppingCart class="mb-4 h-10 w-10 text-muted-foreground" />
            <p class="text-lg font-medium">Tu carrito está vacío</p>
            <p class="mt-1 text-sm text-muted-foreground">Explora el catálogo y encuentra tu próximo celular.</p>
            <A href="/catalogo">
              <Button ripple class="mt-6">
                Ir al catálogo
              </Button>
            </A>
          </div>
        }
      >
        <div class="grid gap-8 lg:grid-cols-[1fr_320px]">
          <ul class="space-y-4">
            <For each={cart.items()}>
              {(entry) => (
                <li>
                  <CartLine
                    title={entry.product.name}
                    price={entry.product.price}
                    quantity={entry.qty}
                    image={entry.product.image}
                    currency="MXN"
                    locale="es-MX"
                    onQuantityChange={(q) => cart.setQty(entry.product.id, q)}
                    onRemove={() => cart.remove(entry.product.id)}
                  />
                </li>
              )}
            </For>
          </ul>

          <div>
            <CartSummary
              lines={lines()}
              total={cartTotal()}
              currency="MXN"
              locale="es-MX"
              checkoutLabel="Ir a pagar"
              onCheckout={() => navigate('/checkout')}
              class="sticky top-20"
            />
            <p class="mt-3 text-center text-xs text-muted-foreground">
              Envío gratis en compras mayores a $1,500 MXN. Precios en pesos mexicanos.
            </p>
          </div>
        </div>
      </Show>
    </Section>
  )
}
