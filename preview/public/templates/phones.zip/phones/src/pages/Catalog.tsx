import { Badge, SegmentedControl, Section, Slider, TextReveal } from '@a4ui/core'
import { FilterGroup, ProductCard, ProductGrid } from '@a4ui/core/commerce'
import { A, useSearchParams } from '@solidjs/router'
import { ShoppingBag } from 'lucide-solid'
import { createMemo, createSignal, For, type JSX, Show } from 'solid-js'

import { getBrands, getCategories, PHONES } from '../lib/products'

const MAX_PRICE = 35000
const CONNECTIVITY_OPTIONS = [
  { value: 'todos', label: 'Todos' },
  { value: '5g', label: 'Solo 5G' },
]

export function Catalog(): JSX.Element {
  const [searchParams] = useSearchParams()
  const initialCategory = typeof searchParams.categoria === 'string' ? searchParams.categoria : undefined

  const [selectedBrands, setSelectedBrands] = createSignal<string[]>([])
  const [selectedCategories, setSelectedCategories] = createSignal<string[]>(
    initialCategory ? [initialCategory] : [],
  )
  const [connectivity, setConnectivity] = createSignal('todos')
  const [maxPrice, setMaxPrice] = createSignal(MAX_PRICE)

  const brandOptions = createMemo(() =>
    getBrands().map((b) => ({ value: b, label: b, count: PHONES.filter((p) => p.brand === b).length })),
  )
  const categoryOptions = createMemo(() =>
    getCategories().map((c) => ({ value: c, label: c, count: PHONES.filter((p) => p.category === c).length })),
  )

  const filtered = createMemo(() =>
    PHONES.filter((p) => {
      if (selectedBrands().length > 0 && !selectedBrands().includes(p.brand)) return false
      if (selectedCategories().length > 0 && !selectedCategories().includes(p.category)) return false
      if (connectivity() === '5g' && !p.fiveG) return false
      if (p.price > maxPrice()) return false
      return true
    }),
  )

  return (
    <>
      <Section class="!pb-6 text-center">
        <Badge tone="info" class="mb-4">
          <ShoppingBag class="h-3.5 w-3.5" /> Catálogo completo
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">
          <TextReveal text="Encuentra tu próximo celular" />
        </h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Filtra por marca, categoría, conectividad y presupuesto.
        </p>
      </Section>

      <Section class="!pt-4">
        <div class="grid gap-8 lg:grid-cols-[240px_1fr]">
          {/* Filters */}
          <aside class="space-y-6">
            <FilterGroup title="Marca" options={brandOptions()} selected={selectedBrands()} onChange={setSelectedBrands} />
            <FilterGroup title="Categoría" options={categoryOptions()} selected={selectedCategories()} onChange={setSelectedCategories} />
            <div>
              <p class="mb-2 text-sm font-medium">Conectividad</p>
              <SegmentedControl value={connectivity()} onChange={setConnectivity} options={CONNECTIVITY_OPTIONS} />
            </div>
            <Slider label="Precio máximo" value={maxPrice()} onChange={setMaxPrice} min={2000} max={MAX_PRICE} step={1000} />
          </aside>

          {/* Grid */}
          <div>
            <Show
              when={filtered().length > 0}
              fallback={<p class="py-16 text-center text-muted-foreground">No encontramos celulares con esos filtros.</p>}
            >
              <ProductGrid>
                <For each={filtered()}>
                  {(p) => (
                    <A href={`/producto/${p.slug}`} class="block h-full">
                      <ProductCard
                        title={p.name}
                        brand={p.brand}
                        category={p.category}
                        price={p.price}
                        compareAt={p.compareAt}
                        image={p.image}
                        rating={p.rating}
                        badge={p.badge}
                        badgeTone={p.badgeTone}
                        currency="MXN"
                        locale="es-MX"
                        tilt
                        spotlight
                      />
                    </A>
                  )}
                </For>
              </ProductGrid>
            </Show>
          </div>
        </div>
      </Section>
    </>
  )
}
