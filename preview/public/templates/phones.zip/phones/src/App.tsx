import { Aurora, Badge, ScrollProgress } from '@a4ui/core'
import { A, Route, Router } from '@solidjs/router'
import { AtSign, Clock, Mail, MapPin, MessageCircle, Phone, ShoppingCart, Zap } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { cart } from './lib/cart'
import { Cart } from './pages/Cart'
import { Catalog } from './pages/Catalog'
import { Checkout } from './pages/Checkout'
import { Home } from './pages/Home'
import { NotFound } from './pages/NotFound'
import { Product } from './pages/Product'

const NAV = [
  { href: '/', label: 'Inicio' },
  { href: '/catalogo', label: 'Catálogo' },
]

function Layout(props: { children?: JSX.Element }): JSX.Element {
  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress />
      <Aurora />
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <A href="/" class="flex items-center gap-2 font-semibold tracking-tight">
            <Zap class="h-5 w-5 text-primary" /> CelMX
          </A>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>
              {(n) => (
                <A href={n.href} end={n.href === '/'} class="transition-colors hover:text-foreground" activeClass="text-foreground">
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <A
            href="/carrito"
            class="relative flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            aria-label="Carrito"
          >
            <ShoppingCart class="h-5 w-5" />
            {cart.count() > 0 && (
              <Badge tone="info" class="absolute right-0.5 top-0.5 px-1.5 py-0 text-[10px]">
                {cart.count()}
              </Badge>
            )}
          </A>
        </div>
      </header>

      {props.children}

      <footer class="border-t border-border/60 bg-muted/30">
        <div class="mx-auto grid max-w-6xl gap-8 px-5 py-10 sm:grid-cols-3">
          <div>
            <span class="flex items-center gap-2 font-semibold tracking-tight">
              <Zap class="h-4 w-4 text-primary" /> CelMX
            </span>
            <p class="mt-3 text-sm text-muted-foreground">
              Celulares de las mejores marcas, con envío a todo México y garantía oficial.
            </p>
            <div class="mt-4 flex gap-1 text-muted-foreground">
              <a
                href="#"
                aria-label="Contacto por mensaje"
                class="flex h-9 w-9 items-center justify-center rounded-lg transition-colors hover:bg-muted hover:text-primary"
              >
                <MessageCircle class="h-5 w-5" />
              </a>
              <a
                href="#"
                aria-label="Síguenos"
                class="flex h-9 w-9 items-center justify-center rounded-lg transition-colors hover:bg-muted hover:text-primary"
              >
                <AtSign class="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <p class="mb-3 text-sm font-medium">Navegación</p>
            <nav class="flex flex-col gap-2 text-sm text-muted-foreground">
              <For each={NAV}>{(n) => <A href={n.href} class="transition-colors hover:text-foreground">{n.label}</A>}</For>
            </nav>
          </div>

          <div>
            <p class="mb-3 text-sm font-medium">Contacto</p>
            <ul class="space-y-2 text-sm text-muted-foreground">
              <li class="flex items-center gap-2">
                <Phone class="h-4 w-4 text-primary" /> +52 55 8765 4321
              </li>
              <li class="flex items-center gap-2">
                <Mail class="h-4 w-4 text-primary" /> hola@celmx.mx
              </li>
              <li class="flex items-center gap-2">
                <MapPin class="h-4 w-4 text-primary" /> CDMX y envíos a toda la república
              </li>
              <li class="flex items-center gap-2">
                <Clock class="h-4 w-4 text-primary" /> Lun–Sáb · 9:00–19:00
              </li>
            </ul>
          </div>
        </div>
        <div class="border-t border-border/60 px-5 py-4 text-center text-xs text-muted-foreground">
          © 2026 CelMX. Hecho con A4ui.
        </div>
      </footer>
    </div>
  )
}

export function App(): JSX.Element {
  return (
    <Router root={Layout}>
      <Route path="/" component={Home} />
      <Route path="/catalogo" component={Catalog} />
      <Route path="/producto/:slug" component={Product} />
      <Route path="/carrito" component={Cart} />
      <Route path="/checkout" component={Checkout} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}
