import { createCart } from '@a4ui/core/commerce'

import type { Phone } from './products'

export const cart = createCart<Phone>()

/** Free shipping over this subtotal (MXN); flat rate otherwise. */
export const FREE_SHIPPING_THRESHOLD = 1500
export const SHIPPING_COST = 149

export function cartShipping(): number {
  const subtotal = cart.subtotal()
  if (subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD) return 0
  return SHIPPING_COST
}

export function cartTotal(): number {
  return cart.subtotal() + cartShipping()
}
