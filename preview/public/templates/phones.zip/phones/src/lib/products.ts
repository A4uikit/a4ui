export type PhoneCategory = 'Gama alta' | 'Gama media' | 'Económico' | 'Plegable'

export interface Phone {
  id: string
  slug: string
  brand: string
  name: string
  tagline: string
  price: number
  compareAt?: number
  image: string
  rating: number
  category: PhoneCategory
  fiveG: boolean
  ramGb: number
  storageGb: number
  screenIn: number
  chip: string
  camera: string
  battery: string
  colors: string[]
  badge?: string
  badgeTone?: 'sale' | 'new' | 'featured'
  description: string
}

function placeholder(label: string): string {
  return `https://placehold.co/700x700/0f172a/60a5fa?text=${encodeURIComponent(label)}`
}

export const PHONES: Phone[] = [
  {
    id: 'nova-x15-pro',
    slug: 'nova-x15-pro',
    brand: 'NovaTech',
    name: 'Nova X15 Pro',
    tagline: 'El flagship que redefine la velocidad',
    price: 18999,
    compareAt: 20999,
    image: placeholder('Nova X15 Pro'),
    rating: 4.8,
    category: 'Gama alta',
    fiveG: true,
    ramGb: 12,
    storageGb: 256,
    screenIn: 6.7,
    chip: 'NovaCore X2',
    camera: 'Triple 50MP + zoom óptico 5x',
    battery: '5000 mAh · carga rápida 80W',
    colors: ['Negro medianoche', 'Azul eléctrico', 'Titanio'],
    badge: 'Nuevo',
    badgeTone: 'new',
    description:
      'La punta de lanza de NovaTech: pantalla AMOLED de 120Hz, cámara con zoom óptico real y el chip más rápido de la marca.',
  },
  {
    id: 'nova-x15',
    slug: 'nova-x15',
    brand: 'NovaTech',
    name: 'Nova X15',
    tagline: 'Potencia flagship, precio accesible',
    price: 13999,
    image: placeholder('Nova X15'),
    rating: 4.6,
    category: 'Gama alta',
    fiveG: true,
    ramGb: 8,
    storageGb: 128,
    screenIn: 6.5,
    chip: 'NovaCore X1',
    camera: 'Dual 50MP + ultra gran angular',
    battery: '4800 mAh · carga rápida 65W',
    colors: ['Negro medianoche', 'Violeta', 'Plata'],
    description: 'Toda la esencia de la línea Nova en un cuerpo más compacto y un precio más amigable.',
  },
  {
    id: 'orbit-s8',
    slug: 'orbit-s8',
    brand: 'Orbit',
    name: 'Orbit S8',
    tagline: 'Equilibrio perfecto entre precio y potencia',
    price: 8999,
    compareAt: 9999,
    image: placeholder('Orbit S8'),
    rating: 4.4,
    category: 'Gama media',
    fiveG: true,
    ramGb: 8,
    storageGb: 128,
    screenIn: 6.4,
    chip: 'Orbit A6',
    camera: '50MP + macro',
    battery: '5000 mAh',
    colors: ['Grafito', 'Azul océano'],
    badge: 'Oferta',
    badgeTone: 'sale',
    description: 'El más vendido de Orbit: batería que dura todo el día y 5G sin pagar de más.',
  },
  {
    id: 'orbit-s8-lite',
    slug: 'orbit-s8-lite',
    brand: 'Orbit',
    name: 'Orbit S8 Lite',
    tagline: 'Lo esencial, bien hecho',
    price: 5999,
    image: placeholder('Orbit S8 Lite'),
    rating: 4.1,
    category: 'Económico',
    fiveG: false,
    ramGb: 6,
    storageGb: 128,
    screenIn: 6.3,
    chip: 'Orbit A4',
    camera: '48MP',
    battery: '5000 mAh',
    colors: ['Negro', 'Verde menta'],
    description: 'La versión accesible del Orbit S8, ideal para uso diario sin complicaciones.',
  },
  {
    id: 'zenith-fold-3',
    slug: 'zenith-fold-3',
    brand: 'Zenith',
    name: 'Zenith Fold 3',
    tagline: 'La pantalla se dobla, la experiencia se multiplica',
    price: 34999,
    image: placeholder('Zenith Fold 3'),
    rating: 4.7,
    category: 'Plegable',
    fiveG: true,
    ramGb: 16,
    storageGb: 512,
    screenIn: 7.6,
    chip: 'ZenSilicon Ultra',
    camera: 'Triple 50MP',
    battery: '4600 mAh · carga rápida 45W',
    colors: ['Negro', 'Crema'],
    badge: 'Destacado',
    badgeTone: 'featured',
    description: 'Un teléfono y una tablet en un solo dispositivo, con bisagra reforzada y pantalla sin pliegue visible.',
  },
  {
    id: 'pulse-a2',
    slug: 'pulse-a2',
    brand: 'Pulse',
    name: 'Pulse A2',
    tagline: 'Tu primer smartphone, sin complicaciones',
    price: 3499,
    image: placeholder('Pulse A2'),
    rating: 3.9,
    category: 'Económico',
    fiveG: false,
    ramGb: 4,
    storageGb: 64,
    screenIn: 6.1,
    chip: 'Pulse Snap 4',
    camera: '13MP',
    battery: '4000 mAh',
    colors: ['Negro', 'Azul'],
    description: 'Confiable para llamadas, redes sociales y lo básico del día a día, al mejor precio.',
  },
  {
    id: 'aria-12-mini',
    slug: 'aria-12-mini',
    brand: 'Aria',
    name: 'Aria 12 Mini',
    tagline: 'Flagship compacto para una sola mano',
    price: 15999,
    image: placeholder('Aria 12 Mini'),
    rating: 4.5,
    category: 'Gama alta',
    fiveG: true,
    ramGb: 8,
    storageGb: 256,
    screenIn: 5.8,
    chip: 'Aria Silicon 3',
    camera: 'Dual 48MP',
    battery: '3500 mAh · carga rápida 30W',
    colors: ['Blanco perla', 'Negro', 'Rosa'],
    description: 'Todo el poder de un flagship en un cuerpo pequeño, pensado para quien no quiere un teléfono gigante.',
  },
  {
    id: 'titan-rugged-x',
    slug: 'titan-rugged-x',
    brand: 'Titan',
    name: 'Titan Rugged X',
    tagline: 'Resistente a todo, en cualquier lugar',
    price: 7499,
    image: placeholder('Titan Rugged X'),
    rating: 4.3,
    category: 'Gama media',
    fiveG: true,
    ramGb: 8,
    storageGb: 128,
    screenIn: 6.6,
    chip: 'Titan Core R2',
    camera: '64MP resistente a impactos',
    battery: '6000 mAh · certificación IP68',
    colors: ['Verde militar', 'Negro'],
    description: 'Sumergible, resistente a caídas y con batería de dos días. Hecho para trabajo pesado y outdoor.',
  },
]

export function getPhoneBySlug(slug: string): Phone | undefined {
  return PHONES.find((p) => p.slug === slug)
}

export function getBrands(): string[] {
  return Array.from(new Set(PHONES.map((p) => p.brand))).sort()
}

export function getCategories(): PhoneCategory[] {
  return Array.from(new Set(PHONES.map((p) => p.category)))
}
