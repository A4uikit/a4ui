# Template: `beauty` — Beauty & aesthetics salon / skincare clinic

A single-page marketing + booking site for a beauty/aesthetics salon (facials,
skincare, aesthetic treatments, waxing, lashes). Goal: a visitor understands
the treatment menu, trusts the results (before/after), and books an
appointment.

## Sections

1. **Top bar / nav** — logo, sticky anchor nav (Services, About, Before/After, Pricing, Testimonials, FAQ, Contact), "Book now" CTA. (`AppShell` top bar, `Anchor`, `Button` ripple, `BackToTop`)
2. **Hero** — headline, subcopy, primary CTA "Book your treatment", secondary "View services". Glass `Card` over a themed/glass backdrop with slow `Parallax` layers. (`GradientText` or `TextReveal` on headline, `Button` ripple)
3. **About / our story** — short story + trust signals (years in business, clients served, certifications/licenses). (`Stat` count-up for years/clients, `Card` glass)
4. **Treatments / services grid** — 6–9 treatment cards (facials, chemical peels, microdermabrasion, waxing, lash lift/extensions, aesthetic/skin-tightening) with icon, title, blurb, duration. (`Card` tilt/spotlight, `ProductGrid` layout, lucide icons)
5. **Before / after gallery** — paired image comparisons with reveal-on-scroll. (`Image` blurUp, `Carousel` swipe, `TextReveal` captions)
6. **Process / how it works** — 3–4 steps (consult → customize plan → treat → aftercare). (`Stepper` or `Timeline`)
7. **Pricing / membership plans** — 3 tiers (single session, package, membership). (`Card`, `PriceTag`, `Badge` "Most popular")
8. **Testimonials** — rotating client quotes + star ratings. (`Carousel` swipe, `Rating`, `Avatar`)
9. **FAQ** — collapsible questions (prep, downtime, contraindications). (`Accordion` animated height)
10. **Booking form** — treatment select, preferred date/time, name, phone, email, notes. (`Form`, `Select`, `DateField`, `Input`, `Button` ripple, `Toast` on submit)
11. **Contact** — hours, address, map placeholder, phone/email, social links, plus the booking form context. (`Descriptions`, `Card` glass)
12. **Footer** — nav, contact, socials, legal.

## Structure

Single-page (long scroll + sticky anchor nav).

## Custom theme

Soft, calming, spa-like mood: blush/rose primary, warm ivory background,
sage-green accent, generous radius (soft, rounded cards) and airy spacing.
Override `--primary`, `--accent`, `--background`, `--radius-*` tokens; verify
WCAG AA contrast in both light and dark.

## Animation / parallax

- `Parallax` — hero backdrop layers and section-to-section depth as the user scrolls.
- `ScrollProgress` — thin reading/scroll progress bar in the sticky nav.
- `TextReveal` / `FillText` — headline and section-title reveals on scroll.
- `GradientText` — hero headline accent word.
- Before/after gallery uses `Image` blurUp + scroll-triggered reveal (paired with `TiltCard`/`Spotlight` on hover for the comparison cards).
- `Card` tilt/spotlight on treatment and pricing cards; `Magnetic` on primary CTAs.
- `Curtain` transition between the Treatments and Before/After sections.
- `Stat` count-up for years/clients trust numbers.
- All motion respects `prefers-reduced-motion`.

## Reusable candidates

A before/after comparison card (paired `Image` blurUp + swipe/slider reveal)
is generic enough for any body-care/renovation vertical — worth proposing as
an `A4uikit/a4ui` component (e.g. `CompareCard` or `BeforeAfter`).

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `beauty` theme tokens
- [ ] Nav + hero
- [ ] About / story + trust stats
- [ ] Treatments / services grid
- [ ] Before/after gallery
- [ ] Process / how it works steps
- [ ] Pricing / membership plans
- [ ] Testimonials carousel
- [ ] FAQ accordion
- [ ] Booking form (with validation)
- [ ] Contact section + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
