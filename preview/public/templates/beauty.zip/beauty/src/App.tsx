import {
  Accordion,
  Aurora,
  Badge,
  BeforeAfter,
  Button,
  Card,
  Carousel,
  GradientText,
  Input,
  Magnetic,
  Parallax,
  Rating,
  ScrollProgress,
  Section,
  Stat,
  Textarea,
  TextReveal,
} from '@a4ui/core'
import {
  AtSign,
  Clock,
  Droplets,
  Flower2,
  HeartHandshake,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Scissors,
  Sparkles,
  Sun,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const NAV = [
  { href: '#services', label: 'Servicios' },
  { href: '#results', label: 'Resultados' },
  { href: '#about', label: 'Nosotros' },
  { href: '#reviews', label: 'Reseñas' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contact', label: 'Contacto' },
]

const SERVICES: { icon: JSX.Element; title: string; blurb: string; price: string }[] = [
  { icon: <Sparkles class="h-6 w-6" />, title: 'Facial de lujo', blurb: 'Limpieza profunda, exfoliación y mascarilla a medida.', price: 'desde $850' },
  { icon: <Droplets class="h-6 w-6" />, title: 'Hidratación', blurb: 'Ácido hialurónico + luz LED para una piel radiante.', price: 'desde $1,200' },
  { icon: <Sun class="h-6 w-6" />, title: 'Antiedad', blurb: 'Radiofrecuencia y péptidos para firmeza visible.', price: 'desde $1,600' },
  { icon: <Flower2 class="h-6 w-6" />, title: 'Skincare ritual', blurb: 'Masaje facial relajante con aceites botánicos.', price: 'desde $700' },
  { icon: <Scissors class="h-6 w-6" />, title: 'Cejas & pestañas', blurb: 'Diseño, laminado y lifting de pestañas.', price: 'desde $450' },
  { icon: <HeartHandshake class="h-6 w-6" />, title: 'Cuidado corporal', blurb: 'Exfoliación corporal y masaje descontracturante.', price: 'desde $980' },
]

const REVIEWS = [
  { name: 'Marina V.', quote: 'Salí con la piel como nunca. El facial de lujo es otro nivel.', rating: 5 },
  { name: 'Paola R.', quote: 'Ambiente relajante y resultados reales. Ya soy cliente fija.', rating: 5 },
  { name: 'Dani M.', quote: 'El ritual de skincare me cambió la rutina. 100% recomendado.', rating: 5 },
]

const FAQ = [
  { value: 'q1', title: '¿Necesito cita previa?', content: 'Sí, trabajamos con cita para dedicarte atención completa. Agenda desde la sección de contacto o por WhatsApp.' },
  { value: 'q2', title: '¿Cada cuánto debo hacerme un facial?', content: 'Recomendamos cada 3–4 semanas para mantener resultados, ajustando según tu tipo de piel.' },
  { value: 'q3', title: '¿Los tratamientos son para piel sensible?', content: 'Sí. Personalizamos cada protocolo tras una valoración inicial sin costo.' },
]

export function App(): JSX.Element {
  const [name, setName] = createSignal('')
  const [phone, setPhone] = createSignal('')
  const [message, setMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress color="hsl(var(--primary))" />

      <Aurora animated />

      {/* Nav */}
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" class="flex items-center gap-2 font-semibold tracking-tight">
            <Flower2 class="h-5 w-5 text-primary" /> Lumière
          </a>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <Button ripple onClick={() => (location.hash = '#contact')}>
            Agenda tu cita
          </Button>
        </div>
      </header>

      {/* Hero */}
      <div id="top" class="relative overflow-hidden">
        <Parallax amount={100}>
          <div
            class="pointer-events-none absolute inset-0 -z-10 opacity-70"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.18), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.16), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="neutral" class="mb-5">
            <Sparkles class="h-3.5 w-3.5" /> Estética facial & skincare
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Tu piel, en su <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">mejor versión</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Tratamientos personalizados en un espacio pensado para tu calma. Resultados reales, cuidado de verdad.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#contact')}>
                Agenda tu cita
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => (location.hash = '#services')}>
              Ver servicios
            </Button>
          </div>
        </Section>
      </div>

      {/* Services */}
      <Section id="services">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Servicios" onView /></h2>
          <p class="mt-2 text-muted-foreground">Protocolos a medida para cada tipo de piel.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={SERVICES}>
            {(s) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {s.icon}
                </div>
                <h3 class="text-lg font-semibold">{s.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
                <p class="mt-4 text-sm font-medium text-primary">{s.price}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Before / after */}
      <Section id="results">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Resultados que se notan" onView /></h2>
          <p class="mt-2 text-muted-foreground">Desliza para ver el efecto de nuestro ritual de skincare.</p>
        </div>
        <BeforeAfter
          before="https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?q=80&w=900&auto=format&fit=crop"
          after="https://images.unsplash.com/photo-1519699047748-de8e457a634e?q=80&w=900&auto=format&fit=crop"
          alt="Piel antes y después del ritual de skincare"
          labels={['Antes', 'Después']}
          class="mx-auto aspect-video max-w-3xl rounded-2xl border border-border"
        />
      </Section>

      {/* Stats / about */}
      <div id="about" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="grid gap-6 sm:grid-cols-3">
            <Stat label="Clientas felices" value={2400} format={(n) => `${Math.round(n / 100) / 10}k+`} tone="primary" />
            <Stat label="Años de experiencia" value={12} tone="neutral" />
            <Stat label="Tratamientos al mes" value={480} format={(n) => `${Math.round(n)}+`} tone="primary" />
          </div>
        </Section>
      </div>

      {/* Reviews */}
      <Section id="reviews">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Lo que dicen" onView /></h2>
        </div>
        <div class="mx-auto max-w-2xl">
          <Carousel
            autoplayMs={5000}
            slides={REVIEWS.map((r) => (
              <div class="px-2">
                <Card glass class="p-8 text-center">
                  <Rating value={r.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                  <p class="text-lg">“{r.quote}”</p>
                  <p class="mt-4 text-sm font-medium text-muted-foreground">— {r.name}</p>
                </Card>
              </div>
            ))}
          />
        </div>
      </Section>

      {/* FAQ */}
      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight"><TextReveal text="Preguntas frecuentes" onView /></h2>
          <Accordion items={FAQ} />
        </div>
      </Section>

      {/* Contact */}
      <div id="contact" class="border-t border-border/60 bg-muted/30">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Agenda tu cita" onView /></h2>
              <p class="mt-2 text-muted-foreground">Déjanos tus datos y te confirmamos horario el mismo día.</p>
              <ul class="mt-8 space-y-4 text-sm">
                <li class="flex items-center gap-3"><Phone class="h-5 w-5 text-primary" /> +52 55 1234 5678</li>
                <li class="flex items-center gap-3"><Mail class="h-5 w-5 text-primary" /> hola@lumiere.mx</li>
                <li class="flex items-center gap-3"><MapPin class="h-5 w-5 text-primary" /> Av. Reforma 123, CDMX</li>
                <li class="flex items-center gap-3"><Clock class="h-5 w-5 text-primary" /> Lun–Sáb · 10:00–20:00</li>
              </ul>
              <div class="mt-6 flex gap-1 text-muted-foreground">
                <a href="#" aria-label="Instagram" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><AtSign class="h-5 w-5" /></a>
                <a href="#" aria-label="WhatsApp" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
              </div>
            </div>

            <Card glass class="p-6">
              {sent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {name() || 'nos vemos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Te contactamos para confirmar tu cita.</p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submit}>
                  <div>
                    <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                    <Input id="contact-name" value={name()} onInput={setName} placeholder="Tu nombre" required />
                  </div>
                  <div>
                    <label for="contact-phone" class="mb-1 block text-sm font-medium">Teléfono</label>
                    <Input id="contact-phone" value={phone()} onInput={setPhone} placeholder="55 0000 0000" type="tel" required />
                  </div>
                  <div>
                    <label for="contact-message" class="mb-1 block text-sm font-medium">¿Qué tratamiento te interesa?</label>
                    <Textarea id="contact-message" value={message()} onInput={setMessage} placeholder="Cuéntanos…" rows={4} />
                  </div>
                  <Button ripple type="submit" class="w-full">Solicitar cita</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2"><Flower2 class="h-4 w-4 text-primary" /> Lumière · Estética & Skincare</span>
          <span>© 2026 Lumière. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}
