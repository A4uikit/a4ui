# Template: `realestate` — Real-estate agency

A listings + brand site for a real-estate agency. Goal: a visitor can browse
and filter active listings, dig into a property's full detail (gallery, specs,
mortgage estimate), find the right agent, and reach out.

## Structure

**Multi-route** (`@solidjs/router`). Routes:

- `/` — Home
- `/listings` — Listings (grid + filters)
- `/listings/:id` — Property detail
- `/agents` — Agents
- `/contact` — Contact

## Sections (per route)

### Nav / shell (all routes)

Persistent top bar with logo, route links, phone CTA. (`AppShell` top bar,
`Button`)

### Home (`/`)

1. **Hero** — headline, subcopy, primary CTA "Browse listings", secondary
   "Talk to an agent". Glass surface over a themed backdrop. Address/keyword
   search bar inline. (`Input`, `Select` for property type, `Button ripple`)
2. **Featured listings** — 6 highlighted properties. (`ProductCard`
   tilt/spotlight repurposed as property card, `PriceTag`, `Image` blurUp)
3. **About / why us** — short story + trust signals (years active, homes
   sold, avg. days on market). (`Stat` count-up band)
4. **Neighborhoods / services** — areas served or service types (buying,
   selling, renting, property management). (`Card` tilt/spotlight grid)
5. **Social proof** — client testimonials. (`Carousel` swipe, `Rating`,
   `Avatar`)
6. **Process** — how buying/selling works, 4 steps. (`Stepper`)
7. **FAQ** — collapsible questions. (`Accordion` animated height)
8. **Contact teaser + Footer**

### Listings (`/listings`)

1. **Filter sidebar** (collapsible on mobile) —
   - Price range (`Slider`, dual-thumb)
   - Bedrooms / bathrooms (`NumberInput`)
   - Property type: house, apartment, condo, land (`Select`)
   - Min/max area (`NumberInput` pair)
   - Neighborhood (`Combobox`)
   - Amenities (`Checkbox` group)
   - Applied filters as removable chips (`Badge`)
2. **Results grid** — property cards with `Image` blurUp, `PriceTag`,
   quick specs (`Descriptions` inline mini), favorite toggle. (`ProductGrid`
   pattern, `Skeleton` shimmer while loading)
3. **Sort + view toggle** — grid/list, sort by price/date/area.
   (`SegmentedControl`, `Dropdown`)
4. **Pagination** — (`Pagination`)
5. **Empty state** — no results match filters. (`Empty`)

### Property detail (`/listings/:id`)

1. **Gallery** — hero image + thumbnail strip, lightbox. (`Image` blurUp,
   `Carousel` swipe)
2. **Header** — address, price (`PriceTag`), status badge (for sale / under
   offer), save/share actions. (`Button`, `Badge`)
3. **Specs** — beds, baths, area, lot size, year built, parking.
   (`Descriptions`)
4. **Description** — full copy, expandable if long. (`Expandable`)
5. **Amenities list** — icon list. (`List` stagger)
6. **Mortgage calculator** — down payment, rate, term inputs → estimated
   monthly payment, breakdown chart. (`NumberInput`, `Slider` for rate/term,
   `Form`, `DonutChart` for principal/interest split, `Stat` for the result)
7. **Map placeholder** — location card. (`Card`)
8. **Listing agent card** — photo, name, contact buttons, link to `/agents`.
   (`Card`, `Avatar`, `Button`)
9. **Similar listings** — carousel of comparable properties. (`Carousel`
   swipe)
10. **Contact form** — "Schedule a viewing" inline form. (`Form`, `DateField`,
    `Input`, `Button ripple`)

### Agents (`/agents`)

1. **Intro** — team headline + count-up stats (agents, years combined,
   listings closed). (`Stat`)
2. **Agent grid** — photo, name, specialty, rating, listings count, contact
   CTA. (`Card` tilt/spotlight, `Rating`, `Avatar`)
3. **Agent detail** (`HoverCard` or `Modal` on click) — bio, active listings,
   contact form.

### Contact (`/contact`)

Full contact section per CONVENTIONS.md baseline:

1. **Contact form** — name, email/phone, message, reason (buying/selling/
   renting/other). (`Form`, `Select`, `Input`, `Textarea`, `Button ripple`)
2. **Contact info** — phone, address, hours. (`Descriptions`)
3. **Map placeholder** — office location. (`Card`)
4. **Social links**
5. **Footer** — nav, contact, socials, legal.

## Custom theme

Trustworthy/premium real-estate mood: deep navy or forest-green primary,
warm gold/brass accent, generous whitespace, slightly larger radius on
property cards for a polished feel. Override `--primary` / `--accent` /
`--radius-*` / `--surface` tokens. Keep WCAG AA in light + dark (gold accent
needs a darker shade for text-on-accent contrast).

## Animation / parallax

- `Parallax` on the Home hero backdrop and section transitions.
- `ScrollProgress` on the property detail page (long content).
- `TextReveal` for section headings on Home (About, Process).
- `GradientText` on the Home hero headline.
- `Image` blurUp everywhere listing photos load (grid, gallery, cards).
- `List` stagger for the amenities list and filter checkbox group reveal.
- `Carousel` swipe for featured listings, similar listings, testimonials,
  and the property gallery.
- `Card` tilt/spotlight on featured listing cards and agent cards.
- `Curtain` transition between Home hero and featured listings section.
- Count-up `Stat` on Home trust signals and Agents page team stats.

## Reusable candidates

- **Mortgage calculator** (inputs + `DonutChart` breakdown + `Stat` result) —
  generic enough for any property-buying flow.
- **Filter sidebar** (price `Slider` + `NumberInput` + `Select` + amenity
  `Checkbox` group + chip summary) — reusable for any filterable catalog
  (also relevant to `computers`, `phones`).
- **Property/listing card** (`Image` blurUp + `PriceTag` + inline
  `Descriptions`) — a `ProductCard` variant worth proposing upstream.
- **Agent/team-member card** with contact CTA.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset + `@solidjs/router`)
- [ ] Custom `realestate` theme tokens
- [ ] App shell + route nav
- [ ] Home: hero + search bar
- [ ] Home: featured listings + about/stats + neighborhoods
- [ ] Home: testimonials + process + FAQ + contact teaser
- [ ] Listings: filter sidebar (price slider, bedrooms, type, area)
- [ ] Listings: results grid + sort/view toggle + pagination + empty state
- [ ] Property detail: gallery + header + specs + description + amenities
- [ ] Property detail: mortgage calculator
- [ ] Property detail: agent card + similar listings + viewing form
- [ ] Agents: intro stats + agent grid + agent detail
- [ ] Contact page (form + info + map + socials) + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
