import { Badge } from '@a4ui/core'
import { A, Route, Router } from '@solidjs/router'
import { AtSign, Building2, Clock, Mail, MapPin, MessageCircle, Phone } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { Agents } from './pages/Agents'
import { Contact } from './pages/Contact'
import { Home } from './pages/Home'
import { Listings } from './pages/Listings'
import { NotFound } from './pages/NotFound'
import { Property } from './pages/Property'

const NAV = [
  { href: '/', label: 'Inicio' },
  { href: '/listings', label: 'Listados' },
  { href: '/agents', label: 'Agentes' },
  { href: '/contact', label: 'Contacto' },
]

function Layout(props: { children?: JSX.Element }): JSX.Element {
  return (
    <div class="min-h-screen bg-background text-foreground">
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <A href="/" class="flex items-center gap-2 font-semibold tracking-tight">
            <Building2 class="h-5 w-5 text-primary" /> Casa Nova
          </A>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>
              {(n) => (
                <A href={n.href} end={n.href === '/'} class="transition-colors hover:text-foreground" activeClass="text-foreground">
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <a
            href="tel:+524421234567"
            class="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            <Phone class="h-4 w-4" /> Llamar
          </a>
        </div>
      </header>

      {props.children}

      <footer class="border-t border-border/60 bg-muted/30">
        <div class="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <span class="flex items-center gap-2 font-semibold tracking-tight">
              <Building2 class="h-5 w-5 text-primary" /> Casa Nova
            </span>
            <p class="mt-3 text-sm text-muted-foreground">
              Inmobiliaria boutique en Querétaro. Te acompañamos a comprar, vender o rentar con confianza.
            </p>
          </div>
          <div>
            <p class="text-sm font-semibold">Navegación</p>
            <nav class="mt-3 flex flex-col gap-2 text-sm text-muted-foreground">
              <For each={NAV}>{(n) => <A href={n.href} class="transition-colors hover:text-foreground">{n.label}</A>}</For>
            </nav>
          </div>
          <div>
            <p class="text-sm font-semibold">Contacto</p>
            <ul class="mt-3 space-y-2 text-sm text-muted-foreground">
              <li class="flex items-center gap-2"><Phone class="h-4 w-4 text-primary" /> +52 442 123 4567</li>
              <li class="flex items-center gap-2"><Mail class="h-4 w-4 text-primary" /> hola@casanova.mx</li>
              <li class="flex items-center gap-2"><MapPin class="h-4 w-4 text-primary" /> Av. Constituyentes 300, Querétaro</li>
              <li class="flex items-center gap-2"><Clock class="h-4 w-4 text-primary" /> Lun–Sáb · 9:00–19:00</li>
            </ul>
          </div>
          <div>
            <p class="text-sm font-semibold">Síguenos</p>
            <div class="mt-3 flex gap-3 text-muted-foreground">
              <a href="#" aria-label="Instagram" class="transition-colors hover:text-primary"><Badge tone="neutral" class="!p-2"><AtSign class="h-4 w-4" /></Badge></a>
              <a href="#" aria-label="WhatsApp" class="transition-colors hover:text-primary"><Badge tone="neutral" class="!p-2"><MessageCircle class="h-4 w-4" /></Badge></a>
            </div>
          </div>
        </div>
        <div class="border-t border-border/60 py-6 text-center text-xs text-muted-foreground">
          © 2026 Casa Nova. Hecho con A4ui.
        </div>
      </footer>
    </div>
  )
}

export function App(): JSX.Element {
  return (
    <Router root={Layout}>
      <Route path="/" component={Home} />
      <Route path="/listings" component={Listings} />
      <Route path="/listings/:id" component={Property} />
      <Route path="/agents" component={Agents} />
      <Route path="/contact" component={Contact} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}
