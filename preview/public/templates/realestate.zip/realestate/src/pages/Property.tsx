import { Badge, Button, Card, Descriptions, Expandable, Image, Parallax, Section, Select, Slider, Stat, TextReveal } from '@a4ui/core'
import { DonutChart } from '@a4ui/core/charts'
import { A, useNavigate, useParams } from '@solidjs/router'
import {
  ArrowLeft,
  Bath,
  BedDouble,
  Calendar,
  Car,
  Check,
  Mail,
  MapPin,
  Phone,
  Ruler,
  Trees,
} from 'lucide-solid'
import { createMemo, createSignal, For, type JSX, Show } from 'solid-js'

import { AGENTS, formatPrice, PROPERTIES, PROPERTY_STATUS_LABEL, PROPERTY_TYPE_LABEL } from '../lib/data'

const TERM_OPTIONS = [10, 15, 20, 30]

export function Property(): JSX.Element {
  const params = useParams<{ id: string }>()
  const navigate = useNavigate()

  const property = createMemo(() => PROPERTIES.find((p) => p.id === params.id))

  return (
    <Show
      when={property()}
      fallback={
        <Section class="text-center">
          <h1 class="text-2xl font-semibold">Propiedad no encontrada</h1>
          <Button ripple class="mt-6" onClick={() => navigate('/listings')}>Volver a listados</Button>
        </Section>
      }
    >
      {(p) => {
        const agent = createMemo(() => AGENTS[PROPERTIES.findIndex((x) => x.id === p().id) % AGENTS.length])
        const similar = createMemo(() => PROPERTIES.filter((x) => x.type === p().type && x.id !== p().id).slice(0, 3))

        return (
          <>
            <Section class="!pb-0">
              <A href="/listings" class="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
                <ArrowLeft class="h-4 w-4" /> Volver a listados
              </A>

              {/* Gallery */}
              <div class="mt-4 grid gap-3">
                <Expandable
                  size="dialog"
                  maxWidth={1100}
                  class="overflow-hidden rounded-2xl"
                  panelClass="overflow-hidden rounded-2xl"
                  trigger={
                    <Parallax amount={30} class="aspect-[16/9] overflow-hidden">
                      <Image
                        src={p().images[0]}
                        alt={p().title}
                        blurUp
                        preview={false}
                        class="h-full w-full cursor-zoom-in object-cover transition-transform duration-500 hover:scale-105"
                      />
                    </Parallax>
                  }
                >
                  <img src={p().images[0]} alt={p().title} class="max-h-[78vh] w-full object-contain" />
                  <p class="p-3 text-center text-sm text-muted-foreground">{p().title}</p>
                </Expandable>
                <div class="flex gap-3 overflow-x-auto">
                  <For each={p().images}>
                    {(src, i) => (
                      <Expandable
                        size="dialog"
                        maxWidth={1100}
                        class="h-16 w-24 shrink-0 overflow-hidden rounded-xl"
                        panelClass="overflow-hidden rounded-2xl"
                        trigger={
                          <img
                            src={src}
                            alt={`${p().title} — foto ${i() + 1}`}
                            loading="lazy"
                            class="h-full w-full cursor-zoom-in object-cover transition-transform duration-300 hover:scale-105"
                          />
                        }
                      >
                        <img src={src} alt={`${p().title} — foto ${i() + 1}`} class="max-h-[78vh] w-full object-contain" />
                        <p class="p-3 text-center text-sm text-muted-foreground">{p().title} — foto {i() + 1}</p>
                      </Expandable>
                    )}
                  </For>
                </div>
              </div>

              {/* Header */}
              <div class="mt-8 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div class="mb-2 flex items-center gap-2">
                    <Badge tone="info">{PROPERTY_TYPE_LABEL[p().type]}</Badge>
                    <Badge tone={p().status === 'for-sale' ? 'success' : 'warning'}>{PROPERTY_STATUS_LABEL[p().status]}</Badge>
                  </div>
                  <h1 class="text-3xl font-semibold tracking-tight"><TextReveal text={p().title} /></h1>
                  <p class="mt-2 flex items-center gap-1.5 text-muted-foreground">
                    <MapPin class="h-4 w-4" /> {p().address}, {p().neighborhood}, {p().city}
                  </p>
                </div>
                <p class="text-3xl font-semibold text-primary">{formatPrice(p().price)}</p>
              </div>

              {/* Specs */}
              <Card glass class="mt-8 p-6">
                <Descriptions
                  columns={3}
                  items={[
                    { label: 'Recámaras', value: <span class="flex items-center gap-1.5"><BedDouble class="h-4 w-4 text-primary" /> {p().bedrooms || '—'}</span> },
                    { label: 'Baños', value: <span class="flex items-center gap-1.5"><Bath class="h-4 w-4 text-primary" /> {p().bathrooms || '—'}</span> },
                    { label: 'Área construida', value: <span class="flex items-center gap-1.5"><Ruler class="h-4 w-4 text-primary" /> {p().area > 0 ? `${p().area} m²` : '—'}</span> },
                    { label: 'Terreno', value: <span class="flex items-center gap-1.5"><Trees class="h-4 w-4 text-primary" /> {p().lotSize ? `${p().lotSize} m²` : '—'}</span> },
                    { label: 'Año de construcción', value: <span class="flex items-center gap-1.5"><Calendar class="h-4 w-4 text-primary" /> {p().yearBuilt ?? '—'}</span> },
                    { label: 'Estacionamientos', value: <span class="flex items-center gap-1.5"><Car class="h-4 w-4 text-primary" /> {p().parking || '—'}</span> },
                  ]}
                />
              </Card>

              {/* Description */}
              <div class="mt-8 max-w-3xl">
                <h2 class="text-xl font-semibold">Descripción</h2>
                <p class="mt-3 leading-relaxed text-muted-foreground">{p().description}</p>
              </div>

              {/* Amenities */}
              <div class="mt-8">
                <h2 class="text-xl font-semibold">Amenidades</h2>
                <ul class="mt-3 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
                  <For each={p().amenities}>
                    {(a) => (
                      <li class="flex items-center gap-2 text-sm text-muted-foreground">
                        <Check class="h-4 w-4 shrink-0 text-primary" /> {a}
                      </li>
                    )}
                  </For>
                </ul>
              </div>
            </Section>

            {/* Mortgage calculator */}
            <div class="mt-14 border-y border-border/60 bg-muted/30">
              <Section class="!py-14">
                <div class="mb-8 text-center">
                  <h2 class="text-3xl font-semibold tracking-tight">
                    <TextReveal text="Calculadora de hipoteca" onView />
                  </h2>
                  <p class="mx-auto mt-2 max-w-xl text-muted-foreground">
                    Estima tu pago mensual y visualiza cuánto de tu crédito va a capital vs. intereses.
                  </p>
                </div>
                <MortgageCalculator initialPrice={p().price} />
              </Section>
            </div>

            <Section>
              <div class="grid gap-8 lg:grid-cols-[2fr_1fr]">
                {/* Map placeholder */}
                <Card glass class="flex min-h-[220px] flex-col items-center justify-center gap-2 p-6 text-center text-muted-foreground">
                  <MapPin class="h-8 w-8 text-primary" />
                  <p class="font-medium text-foreground">{p().address}</p>
                  <p class="text-sm">{p().neighborhood}, {p().city}</p>
                </Card>

                {/* Agent card */}
                <Card glass class="p-6">
                  <div class="flex items-center gap-4">
                    <img src={agent().photo} alt={agent().name} class="h-14 w-14 rounded-full object-cover" />
                    <div>
                      <p class="font-semibold">{agent().name}</p>
                      <p class="text-sm text-muted-foreground">{agent().specialty}</p>
                    </div>
                  </div>
                  <div class="mt-4 flex flex-col gap-2">
                    <a href={`tel:${agent().phone.replace(/\s/g, '')}`} class="inline-flex items-center gap-2 py-1 text-sm text-muted-foreground hover:text-foreground">
                      <Phone class="h-4 w-4 text-primary" /> {agent().phone}
                    </a>
                    <a href={`mailto:${agent().email}`} class="inline-flex items-center gap-2 py-1 text-sm text-muted-foreground hover:text-foreground">
                      <Mail class="h-4 w-4 text-primary" /> {agent().email}
                    </a>
                  </div>
                  <Button ripple class="mt-4 w-full" onClick={() => navigate('/agents')}>Ver todos los agentes</Button>
                </Card>
              </div>
            </Section>

            {/* Similar listings */}
            <Show when={similar().length > 0}>
              <Section>
                <h2 class="mb-6 text-2xl font-semibold tracking-tight">Propiedades similares</h2>
                <div class="grid gap-5 sm:grid-cols-3">
                  <For each={similar()}>
                    {(s) => (
                      <A href={`/listings/${s.id}`}>
                        <Card glass tilt spotlight class="flex h-full flex-col overflow-hidden p-0">
                          <div class="aspect-[4/3] overflow-hidden">
                            <Image src={s.images[0]} alt={s.title} blurUp preview={false} class="h-full w-full object-cover" />
                          </div>
                          <div class="p-4">
                            <h3 class="text-sm font-semibold leading-snug">{s.title}</h3>
                            <p class="mt-2 font-semibold text-primary">{formatPrice(s.price)}</p>
                          </div>
                        </Card>
                      </A>
                    )}
                  </For>
                </div>
              </Section>
            </Show>

            {/* Schedule a viewing */}
            <Section class="!pt-0">
              <ScheduleViewing propertyTitle={p().title} />
            </Section>
          </>
        )
      }}
    </Show>
  )
}

function MortgageCalculator(props: { initialPrice: number }): JSX.Element {
  const [price, setPrice] = createSignal(props.initialPrice)
  const [downPct, setDownPct] = createSignal(20)
  const [rate, setRate] = createSignal(10.5)
  const [years, setYears] = createSignal(20)

  const downPayment = createMemo(() => price() * (downPct() / 100))
  const principal = createMemo(() => Math.max(price() - downPayment(), 0))
  const monthlyRate = createMemo(() => rate() / 100 / 12)
  const numPayments = createMemo(() => years() * 12)

  const monthlyPayment = createMemo(() => {
    const P = principal()
    const r = monthlyRate()
    const n = numPayments()
    if (P <= 0) return 0
    if (r === 0) return P / n
    const factor = (1 + r) ** n
    return (P * r * factor) / (factor - 1)
  })

  const totalPaid = createMemo(() => monthlyPayment() * numPayments())
  const totalInterest = createMemo(() => Math.max(totalPaid() - principal(), 0))

  return (
    <div class="grid gap-8 lg:grid-cols-[1fr_1fr]">
      <Card glass class="space-y-6 p-6">
        <Slider label="Precio de la propiedad" value={price()} onChange={setPrice} min={500000} max={15000000} step={50000} />
        <Slider label="Enganche (%)" value={downPct()} onChange={setDownPct} min={0} max={50} step={5} />
        <Slider label="Tasa de interés anual (%)" value={rate()} onChange={setRate} min={6} max={16} step={0.25} />
        <div>
          <p class="mb-2 text-sm font-medium">Plazo del crédito</p>
          <Select value={String(years())} onChange={(v) => setYears(Number(v))} aria-label="Plazo del crédito">
            <For each={TERM_OPTIONS}>{(t) => <option value={String(t)}>{t} años</option>}</For>
          </Select>
        </div>
        <p class="text-xs text-muted-foreground">
          Enganche: {formatPrice(downPayment())} · Monto a financiar: {formatPrice(principal())}
        </p>
      </Card>

      <Card glass class="flex flex-col items-center justify-center gap-6 p-6 text-center">
        <Stat label="Pago mensual estimado" value={monthlyPayment()} format={(n) => formatPrice(n)} tone="primary" />
        <DonutChart
          data={[
            { label: 'Capital', value: Math.round(principal()), tone: 'primary' },
            { label: 'Intereses', value: Math.round(totalInterest()), tone: 'accent' },
          ]}
          size={180}
          thickness={22}
        />
        <div class="flex gap-6 text-sm">
          <span class="flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-primary" /> Capital · {formatPrice(principal())}</span>
          <span class="flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-accent" /> Intereses · {formatPrice(totalInterest())}</span>
        </div>
      </Card>
    </div>
  )
}

function ScheduleViewing(props: { propertyTitle: string }): JSX.Element {
  const [name, setName] = createSignal('')
  const [email, setEmail] = createSignal('')
  const [date, setDate] = createSignal('')
  const [message, setMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <Card glass class="mx-auto max-w-2xl p-6">
      <h2 class="text-xl font-semibold">Agenda una visita</h2>
      <p class="mt-1 text-sm text-muted-foreground">Te contactamos para coordinar la mejor fecha para conocer &ldquo;{props.propertyTitle}&rdquo;.</p>
      <Show
        when={!sent()}
        fallback={
          <div class="flex flex-col items-center py-8 text-center">
            <Badge tone="success" pulse class="mb-3">Solicitud enviada</Badge>
            <p class="text-lg font-medium">¡Gracias, {name() || 'pronto te contactamos'}!</p>
            <p class="mt-1 text-sm text-muted-foreground">Un agente confirmará tu visita por correo o teléfono.</p>
          </div>
        }
      >
        <form class="mt-5 grid gap-4 sm:grid-cols-2" onSubmit={submit}>
          <div>
            <label for="visit-name" class="mb-1 block text-sm font-medium">Nombre</label>
            <input
              id="visit-name"
              value={name()}
              onInput={(e) => setName(e.currentTarget.value)}
              required
              placeholder="Tu nombre"
              class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div>
            <label for="visit-email" class="mb-1 block text-sm font-medium">Correo</label>
            <input
              id="visit-email"
              value={email()}
              onInput={(e) => setEmail(e.currentTarget.value)}
              type="email"
              required
              placeholder="tu@correo.com"
              class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div class="sm:col-span-2">
            <label for="visit-date" class="mb-1 block text-sm font-medium">Fecha preferida</label>
            <input
              id="visit-date"
              value={date()}
              onInput={(e) => setDate(e.currentTarget.value)}
              type="date"
              class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div class="sm:col-span-2">
            <label for="visit-message" class="mb-1 block text-sm font-medium">Mensaje (opcional)</label>
            <textarea
              id="visit-message"
              value={message()}
              onInput={(e) => setMessage(e.currentTarget.value)}
              rows={3}
              placeholder="Cuéntanos qué te gustaría saber…"
              class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <Button ripple type="submit" class="sm:col-span-2">Solicitar visita</Button>
        </form>
      </Show>
    </Card>
  )
}
