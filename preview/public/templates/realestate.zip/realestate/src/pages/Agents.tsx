import { Badge, Button, Card, Rating, Section, Stat } from '@a4ui/core'
import { Award, Home as HomeIcon, Mail, Phone, Users } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { AGENTS } from '../lib/data'

export function Agents(): JSX.Element {
  return (
    <>
      <Section class="!pb-8 text-center">
        <Badge tone="neutral" class="mb-4">
          <Users class="h-3.5 w-3.5" /> Nuestro equipo
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Agentes que conocen Querétaro</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Un equipo de asesores certificados, listos para acompañarte en la compra, venta o renta de tu próxima propiedad.
        </p>
      </Section>

      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-12">
          <div class="grid gap-6 sm:grid-cols-3">
            <Stat label="Agentes certificados" value={AGENTS.length} tone="primary" icon={<Users class="h-5 w-5" />} />
            <Stat label="Años combinados" value={38} format={(n) => `${Math.round(n)}+`} tone="primary" icon={<Award class="h-5 w-5" />} delay={0.1} />
            <Stat label="Propiedades cerradas" value={69} format={(n) => `${Math.round(n)}+`} tone="neutral" icon={<HomeIcon class="h-5 w-5" />} delay={0.2} />
          </div>
        </Section>
      </div>

      <Section>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <For each={AGENTS}>
            {(a) => (
              <Card glass tilt spotlight class="flex flex-col items-center p-6 text-center">
                <img src={a.photo} alt={a.name} class="h-24 w-24 rounded-full object-cover" />
                <h2 class="mt-4 font-semibold">{a.name}</h2>
                <p class="text-sm text-muted-foreground">{a.role}</p>
                <Badge tone="info" class="mt-2">{a.specialty}</Badge>
                <Rating value={a.rating} readonly class="mt-3 justify-center" />
                <p class="mt-1 text-xs text-muted-foreground">{a.listings} propiedades activas</p>
                <p class="mt-3 text-sm text-muted-foreground">{a.bio}</p>
                <div class="mt-5 flex w-full flex-col gap-2">
                  <Button ripple variant="secondary" class="gap-2" onClick={() => (window.location.href = `tel:${a.phone.replace(/\s/g, '')}`)}>
                    <Phone class="h-4 w-4" /> Llamar
                  </Button>
                  <Button variant="outline" class="gap-2" onClick={() => (window.location.href = `mailto:${a.email}`)}>
                    <Mail class="h-4 w-4" /> Escribir
                  </Button>
                </div>
              </Card>
            )}
          </For>
        </div>
      </Section>
    </>
  )
}
