import { Badge, Button, Card, Descriptions, Section, Select } from '@a4ui/core'
import { AtSign, Clock, Mail, MapPin, MessageCircle, Phone } from 'lucide-solid'
import { createSignal, For, type JSX, Show } from 'solid-js'

const REASONS = [
  { value: 'buying', label: 'Quiero comprar' },
  { value: 'selling', label: 'Quiero vender' },
  { value: 'renting', label: 'Quiero rentar' },
  { value: 'other', label: 'Otro' },
]

export function Contact(): JSX.Element {
  const [name, setName] = createSignal('')
  const [contact, setContact] = createSignal('')
  const [reason, setReason] = createSignal('buying')
  const [message, setMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <>
      <Section class="!pb-8 text-center">
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Hablemos de tu próxima propiedad</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Escríbenos y un agente te contactará en menos de 24 horas hábiles.
        </p>
      </Section>

      <Section class="!pt-0">
        <div class="grid gap-10 lg:grid-cols-2">
          <div>
            <Card glass class="p-6">
              <h2 class="text-xl font-semibold">Información de contacto</h2>
              <Descriptions
                class="mt-4"
                columns={1}
                items={[
                  { label: 'Teléfono', value: <span class="flex items-center gap-2"><Phone class="h-4 w-4 text-primary" /> +52 442 123 4567</span> },
                  { label: 'Correo', value: <span class="flex items-center gap-2"><Mail class="h-4 w-4 text-primary" /> hola@casanova.mx</span> },
                  { label: 'Dirección', value: <span class="flex items-center gap-2"><MapPin class="h-4 w-4 text-primary" /> Av. Constituyentes 300, Centro, Querétaro, Qro.</span> },
                  { label: 'Horario', value: <span class="flex items-center gap-2"><Clock class="h-4 w-4 text-primary" /> Lun–Vie 9:00–19:00 · Sáb 10:00–14:00</span> },
                ]}
              />
              <div class="mt-6 flex gap-1 text-muted-foreground">
                <a href="#" aria-label="Instagram" class="inline-flex items-center justify-center rounded-lg p-2 transition-colors hover:bg-muted hover:text-primary"><AtSign class="h-5 w-5" /></a>
                <a href="#" aria-label="WhatsApp" class="inline-flex items-center justify-center rounded-lg p-2 transition-colors hover:bg-muted hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
              </div>
            </Card>

            <Card glass class="mt-6 flex min-h-[180px] flex-col items-center justify-center gap-2 p-6 text-center text-muted-foreground">
              <MapPin class="h-8 w-8 text-primary" />
              <p class="font-medium text-foreground">Nuestra oficina</p>
              <p class="text-sm">Av. Constituyentes 300, Centro, Querétaro, Qro.</p>
            </Card>
          </div>

          <Card glass class="p-6">
            <Show
              when={!sent()}
              fallback={
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {name() || 'nos vemos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Un agente se pondrá en contacto contigo muy pronto.</p>
                </div>
              }
            >
              <form class="space-y-4" onSubmit={submit}>
                <div>
                  <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                  <input
                    id="contact-name"
                    value={name()}
                    onInput={(e) => setName(e.currentTarget.value)}
                    placeholder="Tu nombre"
                    required
                    class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div>
                  <label for="contact-info" class="mb-1 block text-sm font-medium">Correo o teléfono</label>
                  <input
                    id="contact-info"
                    value={contact()}
                    onInput={(e) => setContact(e.currentTarget.value)}
                    placeholder="tu@correo.com o 55 0000 0000"
                    required
                    class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div>
                  <label for="contact-reason" class="mb-1 block text-sm font-medium">Motivo</label>
                  <Select id="contact-reason" value={reason()} onChange={setReason}>
                    <For each={REASONS}>{(r) => <option value={r.value}>{r.label}</option>}</For>
                  </Select>
                </div>
                <div>
                  <label for="contact-message" class="mb-1 block text-sm font-medium">Mensaje</label>
                  <textarea
                    id="contact-message"
                    value={message()}
                    onInput={(e) => setMessage(e.currentTarget.value)}
                    placeholder="Cuéntanos qué estás buscando…"
                    rows={4}
                    class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <Button ripple type="submit" class="w-full">Enviar mensaje</Button>
              </form>
            </Show>
          </Card>
        </div>
      </Section>
    </>
  )
}
