import { Badge, Card, Image, NumberInput, Section, Select, Slider } from '@a4ui/core'
import { A, useSearchParams } from '@solidjs/router'
import { Bath, BedDouble, MapPin, Ruler, SearchX } from 'lucide-solid'
import { createMemo, createSignal, For, type JSX, Show } from 'solid-js'

import { formatPrice, PROPERTIES, PROPERTY_STATUS_LABEL, PROPERTY_TYPE_LABEL, type PropertyType } from '../lib/data'

const MAX_PRICE = 10000000
const PRICE_STEP = 100000

export function Listings(): JSX.Element {
  const [searchParams] = useSearchParams()

  const [query, setQuery] = createSignal((searchParams.q as string) ?? '')
  const [type, setType] = createSignal<PropertyType | ''>((searchParams.type as PropertyType) ?? '')
  const [maxPrice, setMaxPrice] = createSignal(MAX_PRICE)
  const [minBedrooms, setMinBedrooms] = createSignal(0)

  const filtered = createMemo(() =>
    PROPERTIES.filter((p) => {
      const matchesQuery =
        query() === '' ||
        p.title.toLowerCase().includes(query().toLowerCase()) ||
        p.neighborhood.toLowerCase().includes(query().toLowerCase()) ||
        p.city.toLowerCase().includes(query().toLowerCase())
      const matchesType = type() === '' || p.type === type()
      const matchesPrice = p.price <= maxPrice()
      const matchesBedrooms = p.bedrooms >= minBedrooms()
      return matchesQuery && matchesType && matchesPrice && matchesBedrooms
    }),
  )

  const resetFilters = (): void => {
    setQuery('')
    setType('')
    setMaxPrice(MAX_PRICE)
    setMinBedrooms(0)
  }

  return (
    <>
      <Section class="!pb-8 text-center">
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">Propiedades en venta</h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Filtra por precio, recámaras y tipo de propiedad para encontrar la que se ajusta a ti.
        </p>
      </Section>

      <Section class="!pt-0">
        <div class="grid gap-8 lg:grid-cols-[280px_1fr]">
          {/* Filter sidebar */}
          <aside class="space-y-6">
            <Card glass class="space-y-6 p-5">
              <div>
                <label for="listings-query" class="mb-1 block text-sm font-medium">Buscar</label>
                <input
                  id="listings-query"
                  value={query()}
                  onInput={(e) => setQuery(e.currentTarget.value)}
                  placeholder="Colonia, ciudad…"
                  class="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </div>

              <Slider label="Precio máximo" value={maxPrice()} onChange={setMaxPrice} min={1000000} max={MAX_PRICE} step={PRICE_STEP} />
              <p class="-mt-4 text-right text-xs text-muted-foreground">hasta {formatPrice(maxPrice())}</p>

              <div>
                <p class="mb-2 text-sm font-medium">Recámaras mínimas</p>
                <NumberInput value={minBedrooms()} onChange={setMinBedrooms} min={0} max={6} />
              </div>

              <div>
                <p class="mb-2 text-sm font-medium">Tipo de propiedad</p>
                <Select value={type()} onChange={(v) => setType(v as PropertyType | '')} aria-label="Tipo de propiedad">
                  <option value="">Todos los tipos</option>
                  <For each={Object.entries(PROPERTY_TYPE_LABEL)}>{([value, label]) => <option value={value}>{label}</option>}</For>
                </Select>
              </div>

              <button type="button" onClick={resetFilters} class="text-sm font-medium text-primary hover:underline">
                Limpiar filtros
              </button>
            </Card>
          </aside>

          {/* Results grid */}
          <div>
            <p class="mb-4 text-sm text-muted-foreground">{filtered().length} propiedades encontradas</p>
            <Show
              when={filtered().length > 0}
              fallback={
                <div class="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-20 text-center">
                  <SearchX class="mb-3 h-10 w-10 text-muted-foreground" />
                  <p class="font-medium">No encontramos propiedades con esos filtros</p>
                  <p class="mt-1 text-sm text-muted-foreground">Intenta ampliar el rango de precio o cambiar el tipo.</p>
                </div>
              }
            >
              <div class="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                <For each={filtered()}>
                  {(p) => (
                    <A href={`/listings/${p.id}`}>
                      <Card glass tilt spotlight class="flex h-full flex-col overflow-hidden p-0">
                        <div class="relative aspect-[4/3] overflow-hidden">
                          <Image src={p.images[0]} alt={p.title} blurUp preview={false} class="h-full w-full object-cover" />
                          <Badge tone={p.status === 'for-sale' ? 'success' : 'warning'} class="absolute left-3 top-3">
                            {PROPERTY_STATUS_LABEL[p.status]}
                          </Badge>
                        </div>
                        <div class="flex flex-1 flex-col p-5">
                          <Badge tone="info" class="mb-2 w-fit">{PROPERTY_TYPE_LABEL[p.type]}</Badge>
                          <h2 class="font-semibold leading-snug">{p.title}</h2>
                          <p class="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                            <MapPin class="h-3.5 w-3.5" /> {p.neighborhood}, {p.city}
                          </p>
                          <div class="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
                            <Show when={p.bedrooms > 0}>
                              <span class="flex items-center gap-1"><BedDouble class="h-4 w-4" /> {p.bedrooms}</span>
                            </Show>
                            <Show when={p.bathrooms > 0}>
                              <span class="flex items-center gap-1"><Bath class="h-4 w-4" /> {p.bathrooms}</span>
                            </Show>
                            <span class="flex items-center gap-1"><Ruler class="h-4 w-4" /> {p.area > 0 ? p.area : p.lotSize} m²</span>
                          </div>
                          <p class="mt-4 text-lg font-semibold text-primary">{formatPrice(p.price)}</p>
                        </div>
                      </Card>
                    </A>
                  )}
                </For>
              </div>
            </Show>
          </div>
        </div>
      </Section>
    </>
  )
}
