import {
  Badge,
  Button,
  Card,
  Carousel,
  GradientText,
  Image,
  Magnetic,
  Parallax,
  Rating,
  ScrollProgress,
  Section,
  Select,
  Stat,
  TextReveal,
} from '@a4ui/core'
import { A, useNavigate } from '@solidjs/router'
import { Award, Bath, BedDouble, Building2, Home as HomeIcon, Key, MapPin, Ruler, Search, ShieldCheck, TrendingUp } from 'lucide-solid'
import { createSignal, For, type JSX, Show } from 'solid-js'

import { formatPrice, PROPERTIES, PROPERTY_TYPE_LABEL, type PropertyType, TESTIMONIALS } from '../lib/data'

const SERVICES: { icon: JSX.Element; title: string; blurb: string }[] = [
  { icon: <Key class="h-6 w-6" />, title: 'Compra', blurb: 'Te ayudamos a encontrar la propiedad que se ajusta a tu presupuesto y estilo de vida.' },
  { icon: <TrendingUp class="h-6 w-6" />, title: 'Venta', blurb: 'Valuación, marketing profesional y negociación para vender al mejor precio.' },
  { icon: <Building2 class="h-6 w-6" />, title: 'Renta', blurb: 'Encuentra inquilinos confiables o tu próximo hogar en renta sin complicaciones.' },
  { icon: <ShieldCheck class="h-6 w-6" />, title: 'Administración', blurb: 'Gestionamos tu propiedad de inversión: cobro, mantenimiento y reportes.' },
]

export function Home(): JSX.Element {
  const navigate = useNavigate()
  const [query, setQuery] = createSignal('')
  const [type, setType] = createSignal<PropertyType | ''>('')

  const featured = PROPERTIES.filter((p) => p.featured)

  const search = (e: Event): void => {
    e.preventDefault()
    const params = new URLSearchParams()
    if (query()) params.set('q', query())
    if (type()) params.set('type', type())
    navigate(`/listings${params.toString() ? `?${params.toString()}` : ''}`)
  }

  return (
    <>
      <ScrollProgress />

      {/* Hero */}
      <div class="relative overflow-hidden">
        <Parallax amount={50} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.16), transparent 70%), radial-gradient(40% 40% at 85% 15%, hsl(var(--accent) / 0.18), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-24 text-center">
          <Badge tone="neutral" class="mb-5">
            <HomeIcon class="h-3.5 w-3.5" /> Inmobiliaria en Querétaro
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Encuentra el hogar que <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">mereces</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Casas, departamentos, condominios y terrenos verificados, con asesoría experta en cada paso de la compra o venta.
          </p>

          <form onSubmit={search} class="mx-auto mt-8 flex max-w-2xl flex-col gap-3 rounded-2xl border border-border/60 bg-background/70 p-3 shadow-sm backdrop-blur sm:flex-row">
            <div class="flex flex-1 items-center gap-2 rounded-xl border border-border/60 px-3">
              <Search class="h-4 w-4 shrink-0 text-muted-foreground" />
              <input
                value={query()}
                onInput={(e) => setQuery(e.currentTarget.value)}
                placeholder="Colonia, ciudad o palabra clave…"
                aria-label="Buscar por colonia, ciudad o palabra clave"
                class="w-full bg-transparent py-2.5 text-sm outline-none placeholder:text-muted-foreground"
              />
            </div>
            <Select value={type()} onChange={(v) => setType(v as PropertyType | '')} aria-label="Tipo de propiedad" class="sm:w-48">
              <option value="">Todos los tipos</option>
              <For each={Object.entries(PROPERTY_TYPE_LABEL)}>{([value, label]) => <option value={value}>{label}</option>}</For>
            </Select>
            <Button ripple type="submit" class="gap-2">
              <Search class="h-4 w-4" /> Buscar
            </Button>
          </form>

          <div class="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={12}>
              <Button ripple onClick={() => navigate('/listings')}>Ver listados</Button>
            </Magnetic>
            <Button variant="outline" onClick={() => navigate('/agents')}>Hablar con un agente</Button>
          </div>
        </Section>
      </div>

      {/* Featured listings */}
      <Section id="featured">
        <div class="mb-10 flex items-end justify-between gap-4">
          <div>
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Propiedades destacadas" onView />
            </h2>
            <p class="mt-2 text-muted-foreground">Una selección de nuestros mejores listados esta semana.</p>
          </div>
          <A href="/listings" class="hidden shrink-0 text-sm font-medium text-primary hover:underline sm:block">
            Ver todos →
          </A>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={featured}>
            {(p) => (
              <A href={`/listings/${p.id}`}>
                <Card glass tilt spotlight class="flex h-full flex-col overflow-hidden p-0">
                  <div class="aspect-[4/3] overflow-hidden">
                    <Image src={p.images[0]} alt={p.title} blurUp preview={false} class="h-full w-full object-cover" />
                  </div>
                  <div class="flex flex-1 flex-col p-5">
                    <Badge tone="info" class="mb-2 w-fit">{PROPERTY_TYPE_LABEL[p.type]}</Badge>
                    <h3 class="font-semibold leading-snug">{p.title}</h3>
                    <p class="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                      <MapPin class="h-3.5 w-3.5" /> {p.neighborhood}, {p.city}
                    </p>
                    <div class="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
                      <Show when={p.bedrooms > 0}>
                        <span class="flex items-center gap-1"><BedDouble class="h-4 w-4" /> {p.bedrooms}</span>
                      </Show>
                      <Show when={p.bathrooms > 0}>
                        <span class="flex items-center gap-1"><Bath class="h-4 w-4" /> {p.bathrooms}</span>
                      </Show>
                      <span class="flex items-center gap-1"><Ruler class="h-4 w-4" /> {p.lotSize && p.area === 0 ? p.lotSize : p.area} m²</span>
                    </div>
                    <p class="mt-4 text-lg font-semibold text-primary">{formatPrice(p.price)}</p>
                  </div>
                </Card>
              </A>
            )}
          </For>
        </div>
      </Section>

      {/* About / trust signals */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Por qué elegir Casa Nova</h2>
            <p class="mx-auto mt-2 max-w-xl text-muted-foreground">
              Más de una década ayudando a familias e inversionistas a tomar la mejor decisión inmobiliaria en Querétaro.
            </p>
          </div>
          <div class="grid gap-6 sm:grid-cols-3">
            <Stat label="Años de experiencia" value={14} tone="primary" icon={<Award class="h-5 w-5" />} />
            <Stat label="Propiedades vendidas" value={860} format={(n) => `${Math.round(n)}+`} tone="primary" icon={<HomeIcon class="h-5 w-5" />} delay={0.1} />
            <Stat label="Días promedio en mercado" value={38} tone="neutral" icon={<TrendingUp class="h-5 w-5" />} delay={0.2} />
          </div>
        </Section>
      </div>

      {/* Services */}
      <Section>
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Nuestros servicios</h2>
          <p class="mt-2 text-muted-foreground">Te acompañamos en cada etapa del proceso inmobiliario.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <For each={SERVICES}>
            {(s) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">{s.icon}</div>
                <h3 class="text-lg font-semibold">{s.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Testimonials */}
      <div class="border-t border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mb-8 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Lo que dicen nuestros clientes</h2>
          </div>
          <div class="mx-auto max-w-2xl">
            <Carousel
              autoplayMs={5500}
              slides={TESTIMONIALS.map((t) => (
                <div class="px-2">
                  <Card glass class="p-8 text-center">
                    <Rating value={t.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                    <p class="text-lg">&ldquo;{t.quote}&rdquo;</p>
                    <p class="mt-4 text-sm font-medium text-muted-foreground">— {t.name}</p>
                  </Card>
                </div>
              ))}
            />
          </div>
        </Section>
      </div>

      {/* Contact teaser */}
      <Section class="text-center !py-16">
        <h2 class="text-3xl font-semibold tracking-tight">¿Listo para dar el siguiente paso?</h2>
        <p class="mx-auto mt-2 max-w-xl text-muted-foreground">
          Agenda una asesoría gratuita con uno de nuestros agentes y encuentra tu próxima propiedad.
        </p>
        <Button ripple class="mt-6" onClick={() => navigate('/contact')}>Contáctanos</Button>
      </Section>
    </>
  )
}
