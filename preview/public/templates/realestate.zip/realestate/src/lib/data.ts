export type PropertyType = 'house' | 'apartment' | 'condo' | 'land'
export type PropertyStatus = 'for-sale' | 'under-offer'

export interface Property {
  id: string
  title: string
  type: PropertyType
  status: PropertyStatus
  price: number
  address: string
  neighborhood: string
  city: string
  bedrooms: number
  bathrooms: number
  area: number
  lotSize?: number
  yearBuilt?: number
  parking: number
  description: string
  amenities: string[]
  images: string[]
  featured?: boolean
}

export const PROPERTY_TYPE_LABEL: Record<PropertyType, string> = {
  house: 'Casa',
  apartment: 'Departamento',
  condo: 'Condominio',
  land: 'Terreno',
}

export const PROPERTY_STATUS_LABEL: Record<PropertyStatus, string> = {
  'for-sale': 'En venta',
  'under-offer': 'En negociación',
}

function images(seed: string, count: number): string[] {
  return Array.from({ length: count }, (_, i) => `https://picsum.photos/seed/casanova-${seed}-${i}/1000/700`)
}

export const PROPERTIES: Property[] = [
  {
    id: 'p1',
    title: 'Casa moderna con jardín en Juriquilla',
    type: 'house',
    status: 'for-sale',
    price: 4850000,
    address: 'Cerrada de los Encinos 118',
    neighborhood: 'Juriquilla',
    city: 'Querétaro, Qro.',
    bedrooms: 3,
    bathrooms: 3.5,
    area: 280,
    lotSize: 320,
    yearBuilt: 2021,
    parking: 2,
    description:
      'Casa de diseño contemporáneo en privada con vigilancia 24/7. Doble altura en la sala, cocina integral con isla, jardín trasero techado y roof garden con vista a la reserva ecológica. A 5 minutos de zonas comerciales y colegios.',
    amenities: ['Alberca', 'Jardín privado', 'Roof garden', 'Seguridad 24/7', 'Cocina integral', 'Estacionamiento techado'],
    images: images('p1', 5),
    featured: true,
  },
  {
    id: 'p2',
    title: 'Departamento con vista al lago en Zibatá',
    type: 'apartment',
    status: 'for-sale',
    price: 2390000,
    address: 'Av. Zibatá 220, Torre B, piso 6',
    neighborhood: 'Zibatá',
    city: 'Querétaro, Qro.',
    bedrooms: 2,
    bathrooms: 2,
    area: 95,
    yearBuilt: 2019,
    parking: 1,
    description:
      'Departamento amplio con balcón y vista al lago artificial de Zibatá. Amenidades de clase mundial: alberca, gimnasio, salón de eventos y área pet friendly. Cercano a Antea Lifestyle Center.',
    amenities: ['Alberca', 'Gimnasio', 'Salón de eventos', 'Pet friendly', 'Elevador', 'Bodega'],
    images: images('p2', 5),
    featured: true,
  },
  {
    id: 'p3',
    title: 'Loft remodelado en el Centro Histórico',
    type: 'condo',
    status: 'under-offer',
    price: 3150000,
    address: 'Calle Ignacio Allende 45',
    neighborhood: 'Centro Histórico',
    city: 'Querétaro, Qro.',
    bedrooms: 1,
    bathrooms: 1.5,
    area: 78,
    yearBuilt: 1998,
    parking: 1,
    description:
      'Loft de altos techos con vigas de madera original, totalmente remodelado en 2020 conservando el carácter colonial. A pasos de la Plaza de Armas, restaurantes y galerías.',
    amenities: ['Terraza', 'Techos altos', 'Cocina integral', 'Cercano al centro', 'Seguridad'],
    images: images('p3', 4),
    featured: true,
  },
  {
    id: 'p4',
    title: 'Terreno residencial en El Refugio',
    type: 'land',
    status: 'for-sale',
    price: 1890000,
    address: 'Circuito El Refugio Lote 12',
    neighborhood: 'El Refugio',
    city: 'Querétaro, Qro.',
    bedrooms: 0,
    bathrooms: 0,
    area: 0,
    lotSize: 400,
    parking: 0,
    description:
      'Terreno plano listo para construir, dentro de fraccionamiento con acceso controlado. Servicios de agua, luz y drenaje ya introducidos. Uso de suelo habitacional.',
    amenities: ['Acceso controlado', 'Servicios introducidos', 'Uso habitacional', 'Calle pavimentada'],
    images: images('p4', 3),
    featured: true,
  },
  {
    id: 'p5',
    title: 'Casa familiar en Milenio III',
    type: 'house',
    status: 'for-sale',
    price: 5600000,
    address: 'Av. Milenio 880',
    neighborhood: 'Milenio III',
    city: 'Querétaro, Qro.',
    bedrooms: 4,
    bathrooms: 3,
    area: 310,
    lotSize: 260,
    yearBuilt: 2016,
    parking: 3,
    description:
      'Amplia casa de dos plantas en una de las zonas más consolidadas de la ciudad. Cuarto de estudio, cocina abierta a la sala familiar, y patio de servicio independiente.',
    amenities: ['Jardín', 'Cuarto de estudio', 'Cocina abierta', 'Patio de servicio', 'Estacionamiento para 3 autos'],
    images: images('p5', 5),
    featured: true,
  },
  {
    id: 'p6',
    title: 'Departamento ejecutivo en Cumbres del Lago',
    type: 'apartment',
    status: 'for-sale',
    price: 2750000,
    address: 'Blvd. de las Ciencias 500, Torre A',
    neighborhood: 'Cumbres del Lago',
    city: 'Querétaro, Qro.',
    bedrooms: 2,
    bathrooms: 2,
    area: 88,
    yearBuilt: 2022,
    parking: 1,
    description:
      'Torre de reciente entrega con acabados de lujo, roof garden con alberca y coworking para residentes. Ideal para profesionistas o inversión en renta.',
    amenities: ['Roof garden', 'Coworking', 'Gimnasio', 'Elevador', 'Seguridad 24/7'],
    images: images('p6', 4),
    featured: true,
  },
  {
    id: 'p7',
    title: 'Casa con alberca en La Vista Country Club',
    type: 'house',
    status: 'for-sale',
    price: 8900000,
    address: 'Club de Golf La Vista 22',
    neighborhood: 'La Vista Country Club',
    city: 'Querétaro, Qro.',
    bedrooms: 5,
    bathrooms: 4.5,
    area: 420,
    lotSize: 500,
    yearBuilt: 2018,
    parking: 4,
    description:
      'Residencia de lujo frente al campo de golf, con alberca climatizada, cine en casa y cava. Acabados importados y vigilancia privada las 24 horas.',
    amenities: ['Alberca climatizada', 'Cine en casa', 'Cava', 'Vista al campo de golf', 'Vigilancia privada'],
    images: images('p7', 5),
  },
  {
    id: 'p8',
    title: 'Condominio horizontal en Balvanera',
    type: 'condo',
    status: 'under-offer',
    price: 3980000,
    address: 'Privada Balvanera 8',
    neighborhood: 'Balvanera',
    city: 'Corregidora, Qro.',
    bedrooms: 3,
    bathrooms: 2.5,
    area: 165,
    lotSize: 140,
    yearBuilt: 2020,
    parking: 2,
    description:
      'Condominio en privada boutique de solo 10 casas, con alberca común y áreas verdes. Diseño moderno de doble altura y ventanales de piso a techo.',
    amenities: ['Alberca común', 'Áreas verdes', 'Ventanales piso a techo', 'Privada boutique'],
    images: images('p8', 4),
  },
  {
    id: 'p9',
    title: 'Terreno comercial sobre Carretera 57',
    type: 'land',
    status: 'for-sale',
    price: 3200000,
    address: 'Carretera Federal 57 Km 190',
    neighborhood: 'Carretera 57',
    city: 'Querétaro, Qro.',
    bedrooms: 0,
    bathrooms: 0,
    area: 0,
    lotSize: 800,
    parking: 0,
    description:
      'Terreno con excelente visibilidad y alto flujo vehicular, ideal para uso comercial o mixto. Uso de suelo compatible con plaza comercial o showroom.',
    amenities: ['Alta visibilidad', 'Uso comercial', 'Frente de 20m', 'Servicios disponibles'],
    images: images('p9', 3),
  },
]

export interface Agent {
  id: string
  name: string
  role: string
  specialty: string
  phone: string
  email: string
  rating: number
  listings: number
  photo: string
  bio: string
}

export const AGENTS: Agent[] = [
  {
    id: 'a1',
    name: 'Fernanda Ruiz',
    role: 'Directora de ventas',
    specialty: 'Residencial premium',
    phone: '+52 442 123 4567',
    email: 'fernanda@casanova.mx',
    rating: 5,
    listings: 18,
    photo: 'https://picsum.photos/seed/casanova-agent-1/400/400',
    bio: 'Más de 12 años colocando propiedades residenciales de alto nivel en Querétaro. Especialista en negociación y cierre de operaciones complejas.',
  },
  {
    id: 'a2',
    name: 'Carlos Medina',
    role: 'Agente senior',
    specialty: 'Casas y terrenos',
    phone: '+52 442 234 5678',
    email: 'carlos@casanova.mx',
    rating: 4.8,
    listings: 24,
    photo: 'https://picsum.photos/seed/casanova-agent-2/400/400',
    bio: 'Conoce cada fraccionamiento de la zona metropolitana como la palma de su mano. Enfocado en asesorar a familias que compran su primera casa.',
  },
  {
    id: 'a3',
    name: 'Ana Sofía López',
    role: 'Agente',
    specialty: 'Departamentos y condominios',
    phone: '+52 442 345 6789',
    email: 'anasofia@casanova.mx',
    rating: 4.9,
    listings: 15,
    photo: 'https://picsum.photos/seed/casanova-agent-3/400/400',
    bio: 'Experta en desarrollos verticales y condominios de nueva entrega. Acompaña a inversionistas que buscan propiedades para renta.',
  },
  {
    id: 'a4',
    name: 'Roberto Vega',
    role: 'Agente',
    specialty: 'Propiedades comerciales',
    phone: '+52 442 456 7890',
    email: 'roberto@casanova.mx',
    rating: 4.7,
    listings: 12,
    photo: 'https://picsum.photos/seed/casanova-agent-4/400/400',
    bio: 'Asesor en terrenos y locales comerciales, con experiencia en estudios de factibilidad y cambios de uso de suelo.',
  },
]

export interface Testimonial {
  name: string
  quote: string
  rating: number
}

export const TESTIMONIALS: Testimonial[] = [
  { name: 'Laura Gómez', quote: 'Encontramos nuestra casa ideal en menos de un mes. El equipo de Casa Nova estuvo con nosotros en cada paso.', rating: 5 },
  { name: 'Miguel Ángel Torres', quote: 'Vendieron mi departamento en tiempo récord y al precio que esperábamos. Muy profesionales.', rating: 5 },
  { name: 'Renata Islas', quote: 'La calculadora de hipoteca me ayudó a decidir cuánto podía pagar antes de agendar visitas. Excelente atención.', rating: 5 },
]

export function formatPrice(amount: number): string {
  return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 }).format(amount)
}
