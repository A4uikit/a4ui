import {
  Accordion,
  Aurora,
  Badge,
  Button,
  Card,
  Carousel,
  GradientText,
  Input,
  Magnetic,
  Marquee,
  Parallax,
  type PricingTier,
  PricingTable,
  Rating,
  ScrambleText,
  ScrollProgress,
  Section,
  Stat,
  Stepper,
  Textarea,
  TextReveal,
  Typewriter,
} from '@a4ui/core'
import {
  AtSign,
  BarChart3,
  Clock,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Puzzle,
  Quote,
  Rocket,
  Send,
  ShieldCheck,
  Sparkles,
  Users,
  Zap,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const NAV = [
  { href: '#features', label: 'Características' },
  { href: '#how', label: 'Cómo funciona' },
  { href: '#pricing', label: 'Precios' },
  { href: '#testimonials', label: 'Testimonios' },
  { href: '#faq', label: 'FAQ' },
]

const FEATURES: { icon: JSX.Element; title: string; blurb: string }[] = [
  { icon: <Zap class="h-6 w-6" />, title: 'Automatizaciones instantáneas', blurb: 'Dispara flujos con un evento, sin escribir una sola línea de código.' },
  { icon: <Rocket class="h-6 w-6" />, title: 'Lanza en minutos', blurb: 'Plantillas listas para usar: de la idea a producción el mismo día.' },
  { icon: <ShieldCheck class="h-6 w-6" />, title: 'Seguridad de nivel empresarial', blurb: 'Cifrado extremo a extremo y controles de acceso granular por equipo.' },
  { icon: <BarChart3 class="h-6 w-6" />, title: 'Analítica en tiempo real', blurb: 'Mide el impacto de cada automatización al instante, sin exportar nada.' },
  { icon: <Puzzle class="h-6 w-6" />, title: 'Integraciones nativas', blurb: 'Conecta más de 120 herramientas que ya usa tu equipo hoy.' },
  { icon: <Users class="h-6 w-6" />, title: 'Colaboración en equipo', blurb: 'Comparte flujos, roles y permisos entre todas tus áreas.' },
]

const LOGOS = ['Orbita', 'Vector Labs', 'Estelar', 'Nova Systems', 'Pico Cloud', 'Lumen Data', 'Astra Works', 'Quanta']

const STEPS = [
  { label: 'Conecta tus herramientas', description: 'Integra tu stack actual en minutos, sin código.' },
  { label: 'Diseña tu flujo', description: 'Arrastra y suelta bloques de automatización con IA.' },
  { label: 'Mide resultados', description: 'Sigue el impacto de cada flujo con analítica en vivo.' },
]

const formatPrice = (n: number): string =>
  new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 }).format(n)

const goToContact = (): void => {
  location.hash = '#contact'
}

const TIERS: PricingTier[] = [
  {
    name: 'Starter',
    description: 'Para equipos pequeños que empiezan a automatizar.',
    price: `${formatPrice(349)}/mes`,
    priceAnnual: `${formatPrice(279)}/mes`,
    features: ['Hasta 3 flujos activos', '1,000 ejecuciones al mes', 'Integraciones básicas', 'Soporte por correo'],
    cta: { label: 'Comenzar gratis', onClick: goToContact },
  },
  {
    name: 'Pro',
    description: 'Para equipos que escalan operaciones sin fricción.',
    price: `${formatPrice(899)}/mes`,
    priceAnnual: `${formatPrice(719)}/mes`,
    highlighted: true,
    features: ['Flujos ilimitados', '25,000 ejecuciones al mes', 'Integraciones avanzadas + IA', 'Soporte prioritario 24/5'],
    cta: { label: 'Comenzar gratis', onClick: goToContact },
  },
  {
    name: 'Enterprise',
    description: 'Para organizaciones con necesidades a medida.',
    price: 'Personalizado',
    features: ['SLA dedicado', 'Onboarding asistido', 'Seguridad y cumplimiento avanzados', 'Gerente de cuenta dedicado'],
    cta: { label: 'Contactar ventas', onClick: goToContact },
  },
]

const TESTIMONIALS = [
  { name: 'Renata Duarte', role: 'COO, Vector Labs', quote: 'Redujimos 30 horas semanales de trabajo manual desde el primer mes. Nimbus se paga solo.', rating: 5 },
  { name: 'Emilio Castañeda', role: 'Head of Ops, Estelar', quote: 'La curva de aprendizaje es mínima y las integraciones simplemente funcionan.', rating: 5 },
  { name: 'Camila Ríos', role: 'CTO, Nova Systems', quote: 'El soporte prioritario y la analítica en vivo nos dieron control real sobre nuestros procesos.', rating: 5 },
]

const FAQ = [
  { value: 'q1', title: '¿Hay prueba gratuita?', content: <p>Sí, 14 días con acceso completo a todas las funciones del plan Pro. No pedimos tarjeta para empezar.</p> },
  { value: 'q2', title: '¿Puedo cancelar cuando quiera?', content: <p>Por supuesto. Cancela en un clic desde tu panel; no hay permanencia ni penalizaciones.</p> },
  { value: 'q3', title: '¿Con qué herramientas se integra Nimbus?', content: <p>Con más de 120 herramientas de uso común: CRMs, hojas de cálculo, mensajería, pagos y bases de datos.</p> },
  { value: 'q4', title: '¿Cómo protegen mis datos?', content: <p>Cifrado en tránsito y en reposo, controles de acceso por rol y auditoría completa de cada automatización.</p> },
  { value: 'q5', title: '¿Ofrecen soporte en español?', content: <p>Sí, todo nuestro equipo de soporte atiende en español en horario de Lunes a Viernes, 9:00–19:00 (CST).</p> },
]

export function App(): JSX.Element {
  const [name, setName] = createSignal('')
  const [email, setEmail] = createSignal('')
  const [message, setMessage] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const submit = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress />
      <Aurora animated />

      {/* Nav */}
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" class="flex items-center gap-2 font-semibold tracking-tight">
            <Zap class="h-5 w-5 text-primary" /> Nimbus
          </a>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <div class="flex items-center gap-2">
            <Button variant="ghost" class="hidden sm:inline-flex" onClick={() => (location.hash = '#contact')}>
              Iniciar sesión
            </Button>
            <Button ripple onClick={() => (location.hash = '#pricing')}>
              Prueba gratis
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div id="top" class="relative overflow-hidden">
        <Parallax amount={70}>
          <div
            class="pointer-events-none absolute inset-0 -z-10 opacity-80"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.24), transparent 70%), radial-gradient(40% 40% at 85% 15%, hsl(var(--accent) / 0.22), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="info" pulse class="mb-5">
            <Sparkles class="h-3.5 w-3.5" />
            <ScrambleText text="NUEVO · AUTOMATIZACIONES CON IA" duration={700} />
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Flujos de trabajo que se{' '}
            <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">
              optimizan solos
            </GradientText>
          </h1>
          <p class="mx-auto mt-5 h-7 max-w-xl text-lg text-muted-foreground">
            <Typewriter
              text={[
                'Automatiza tareas repetitivas en minutos.',
                'Conecta tus herramientas favoritas sin código.',
                'Escala tus operaciones sin contratar más gente.',
              ]}
              speed={40}
            />
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#pricing')}>
                Comenzar gratis
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => (location.hash = '#how')}>
              Ver cómo funciona
            </Button>
          </div>
          <div class="mx-auto mt-14 grid max-w-2xl gap-6 sm:grid-cols-3">
            <Stat label="Equipos activos" value={12400} format={(n) => `${(Math.round(n / 100) / 10).toFixed(1)}k+`} tone="primary" />
            <Stat label="Horas ahorradas / semana" value={38000} format={(n) => `${Math.round(n / 1000)}k+`} tone="primary" delay={0.1} />
            <Stat label="Uptime" value={99.98} format={(n) => `${n.toFixed(2)}%`} tone="primary" delay={0.2} />
          </div>
        </Section>
      </div>

      {/* Logo cloud */}
      <div class="border-y border-border/60 bg-muted/30 py-10">
        <p class="mb-6 text-center text-sm text-muted-foreground">Con la confianza de equipos que crecen rápido</p>
        <Marquee speed={26}>
          <For each={LOGOS}>
            {(l) => <span class="mx-8 text-xl font-semibold tracking-tight text-muted-foreground/60">{l}</span>}
          </For>
        </Marquee>
      </div>

      {/* Features */}
      <Section id="features">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Todo lo que necesitas para escalar" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Un solo lugar para automatizar, medir y crecer.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={FEATURES}>
            {(f) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {f.icon}
                </div>
                <h3 class="text-lg font-semibold">{f.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{f.blurb}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* How it works */}
      <div id="how" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Cómo funciona, en 3 pasos" onView />
            </h2>
            <p class="mt-2 text-muted-foreground">De la idea a la automatización en producción, el mismo día.</p>
          </div>
          <Stepper steps={STEPS} active={2} />
        </Section>
      </div>

      {/* Pricing */}
      <Section id="pricing">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Precios simples, sin sorpresas" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Cambia de plan cuando quieras. Cancela cuando quieras.</p>
        </div>
        <PricingTable tiers={TIERS} />
      </Section>

      {/* Testimonials */}
      <div id="testimonials" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mb-8 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Lo que dicen nuestros clientes" onView />
            </h2>
          </div>
          <div class="mx-auto max-w-2xl">
            <Carousel
              autoplayMs={5500}
              swipe
              slides={TESTIMONIALS.map((t) => (
                <div class="px-2">
                  <Card glass class="p-8 text-center">
                    <Quote class="mx-auto mb-3 h-6 w-6 text-primary" />
                    <Rating value={t.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                    <p class="text-lg">&ldquo;{t.quote}&rdquo;</p>
                    <p class="mt-4 text-sm font-medium">{t.name}</p>
                    <p class="text-sm text-muted-foreground">{t.role}</p>
                  </Card>
                </div>
              ))}
            />
          </div>
        </Section>
      </div>

      {/* FAQ */}
      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">
            <TextReveal text="Preguntas frecuentes" onView />
          </h2>
          <Accordion items={FAQ} />
        </div>
      </Section>

      {/* Big CTA */}
      <div class="relative overflow-hidden border-y border-border/60">
        <Parallax amount={50}>
          <div
            class="pointer-events-none absolute inset-0 -z-10"
            style={{
              background:
                'radial-gradient(60% 60% at 50% 30%, hsl(var(--primary) / 0.3), transparent 70%), radial-gradient(45% 45% at 20% 80%, hsl(var(--accent) / 0.24), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-20 text-center">
          <h2 class="mx-auto max-w-2xl text-3xl font-semibold tracking-tight sm:text-4xl">
            Empieza a{' '}
            <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">
              automatizar hoy
            </GradientText>
          </h2>
          <p class="mx-auto mt-3 max-w-xl text-muted-foreground">
            Únete a miles de equipos que ya dejaron atrás el trabajo manual. Sin tarjeta, sin permanencia.
          </p>
          <div class="mt-8 flex items-center justify-center">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#contact')}>
                Crear cuenta gratis
              </Button>
            </Magnetic>
          </div>
        </Section>
      </div>

      {/* Contact */}
      <div id="contact" class="bg-muted/30">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">
                <TextReveal text="Hablemos" onView />
              </h2>
              <p class="mt-2 text-muted-foreground">
                Cuéntanos qué quieres automatizar y te ayudamos a diseñar tu primer flujo.
              </p>
              <ul class="mt-8 space-y-4 text-sm">
                <li class="flex items-center gap-3"><Phone class="h-5 w-5 text-primary" /> +52 55 8765 4321</li>
                <li class="flex items-center gap-3"><Mail class="h-5 w-5 text-primary" /> hola@nimbus.app</li>
                <li class="flex items-center gap-3"><MapPin class="h-5 w-5 text-primary" /> Equipo remoto en LatAm · Oficina central en CDMX</li>
                <li class="flex items-center gap-3"><Clock class="h-5 w-5 text-primary" /> Lun–Vie · 9:00–19:00 (CST)</li>
              </ul>
              <div class="mt-6 flex gap-2 text-muted-foreground">
                <a
                  href="#"
                  aria-label="Comunidad"
                  class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"
                >
                  <AtSign class="h-5 w-5" />
                </a>
                <a
                  href="#"
                  aria-label="Chat"
                  class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"
                >
                  <MessageCircle class="h-5 w-5" />
                </a>
                <a
                  href="#"
                  aria-label="Enviar mensaje"
                  class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary"
                >
                  <Send class="h-5 w-5" />
                </a>
              </div>
            </div>

            <Card glass class="p-6">
              {sent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {name() || 'nos vemos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Te contactamos en menos de 24 horas.</p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submit}>
                  <div>
                    <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                    <Input id="contact-name" value={name()} onInput={setName} placeholder="Tu nombre" required />
                  </div>
                  <div>
                    <label for="contact-email" class="mb-1 block text-sm font-medium">Correo</label>
                    <Input id="contact-email" value={email()} onInput={setEmail} placeholder="tu@empresa.com" type="email" required />
                  </div>
                  <div>
                    <label for="contact-message" class="mb-1 block text-sm font-medium">¿Qué te gustaría automatizar?</label>
                    <Textarea id="contact-message" value={message()} onInput={setMessage} placeholder="Cuéntanos…" rows={4} />
                  </div>
                  <Button ripple type="submit" class="w-full">Enviar mensaje</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto grid max-w-6xl gap-8 px-5 py-12 text-sm sm:grid-cols-3">
          <div>
            <span class="flex items-center gap-2 font-semibold"><Zap class="h-4 w-4 text-primary" /> Nimbus</span>
            <p class="mt-2 text-muted-foreground">Automatización de flujos de trabajo con IA para equipos que quieren escalar.</p>
          </div>
          <div>
            <p class="mb-2 font-medium">Navegación</p>
            <ul class="space-y-2 text-muted-foreground">
              <For each={NAV}>{(n) => <li><a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a></li>}</For>
            </ul>
          </div>
          <div>
            <p class="mb-2 font-medium">Contacto</p>
            <ul class="space-y-2 text-muted-foreground">
              <li>hola@nimbus.app</li>
              <li>+52 55 8765 4321</li>
              <li>Remoto en LatAm · CDMX</li>
            </ul>
          </div>
        </div>
        <div class="border-t border-border/60 px-5 py-6 text-center text-xs text-muted-foreground">
          © 2026 Nimbus. Hecho con A4ui.
        </div>
      </footer>
    </div>
  )
}
