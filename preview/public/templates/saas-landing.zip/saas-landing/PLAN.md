# Template: `saas-landing` — Startup product / SaaS landing page

A high-converting marketing page for a SaaS product. Goal: a visitor
understands the value prop in seconds, sees the product in action, trusts
the pricing, and converts (signup / demo / contact).

## Sections

1. **Top bar / nav** — logo, anchor links (Features, Pricing, FAQ), "Sign up" CTA, "Log in" link. (`AppShell` top bar, `Button`)
2. **Hero** — headline with animated gradient, subcopy, primary CTA "Start free trial", secondary "Watch demo". Glass surface over a themed/gradient backdrop. (`GradientText`, `TextReveal`, `Button` ripple)
3. **Logo cloud** — "Trusted by" row of client/partner logos. (`Marquee` for a continuous scrolling strip)
4. **Features** — 3–6 feature cards, icon + title + blurb. (`Card` tilt/spotlight, `TiltCard`, lucide icons)
5. **How it works** — 3–4 step process from signup to value. (`Stepper` or `Timeline`)
6. **Live product demo / screenshot** — annotated product screenshot or embedded video, floating over a themed backdrop. (`Parallax`, `Card` glow, `Image` blurUp, `Spotlight`)
7. **Pricing** — 3 tiers with a monthly/annual toggle, "Popular" badge. (`Card`, `PriceTag`, `Switch` for billing toggle, `Badge`)
8. **Testimonials** — customer quotes with avatar, name, role, rating. (`Carousel` swipe, `Rating`, `Avatar`)
9. **Stats band** — key metrics (users, uptime, integrations) with count-up. (`Stat`, `Sparkline` or `DonutChart`)
10. **FAQ** — collapsible questions. (`Accordion` with animated height)
11. **Big CTA** — final conversion banner, headline + primary CTA over a gradient/themed backdrop. (`GradientText`, `Button` ripple)
12. **Contact** — working contact form (name, email, message) + phone, address, hours (support hours), map placeholder (or "remote-first" note), social links. (`Form`, `Input`, `Textarea`, `Button` ripple, `Descriptions`)
13. **Footer** — nav, contact, socials, legal.

**Structure: single-page** (long scroll + sticky anchor nav via `Anchor`).

## Custom theme

Modern/high-energy: electric indigo or violet primary, near-black or
near-white background depending on mode, vivid gradient accent (indigo →
cyan), tight radius for a crisp SaaS feel. Override `--primary` /
`--accent` / `--background` / `--radius-*` tokens; verify WCAG AA on
gradient-text headlines in both light and dark.

## Animation / parallax

This template is the **most motion-heavy** in the set — lean hard on A4ui Motion:

- `Parallax` on hero backdrop and the product demo/screenshot section (multi-layer depth).
- `ScrollProgress` bar pinned to the top of the page.
- `TextReveal` / `FillText` for section headings as they scroll into view.
- `GradientText` on hero headline and final CTA headline.
- `ScrambleText` or `Typewriter` for a rotating value-prop line in the hero.
- `TiltCard` + `Spotlight` on feature cards and pricing cards.
- `Magnetic` on primary CTA buttons.
- `Curtain` or `Expandable` for section-to-section transitions.
- `Stat` count-up for the metrics band.
- `Marquee` for the logo cloud.
- `Carousel` swipe for testimonials.
- Animated `Accordion` for FAQ.
- Respect `prefers-reduced-motion` throughout (A4ui primitives handle this by default).

## Reusable candidates

- Pricing table with monthly/annual `Switch` toggle — high-value reusable across any SaaS/subscription vertical.
- Logo cloud `Marquee` strip — generic trust-signal pattern.
- Feature grid (`Card` tilt/spotlight + icon + title + blurb) — reusable across product-led verticals.
- Stats band with count-up `Stat` — generic metrics-band pattern.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `saas-landing` theme tokens
- [ ] Nav + hero (with gradient text + typewriter)
- [ ] Logo cloud marquee
- [ ] Features grid
- [ ] How-it-works steps
- [ ] Product demo / screenshot section with parallax
- [ ] Pricing table with monthly/annual toggle
- [ ] Testimonials carousel
- [ ] Stats band (count-up)
- [ ] FAQ accordion
- [ ] Big CTA banner
- [ ] Contact section + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
