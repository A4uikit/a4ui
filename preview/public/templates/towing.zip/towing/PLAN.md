# Template: `towing` — Tow truck / roadside assistance

A 24/7 emergency roadside assistance site. Goal: a stranded driver calls or
requests a tow within seconds of landing — everything else supports that one
action.

## Sections

1. **Emergency bar** — sticky top bar, always visible, tel: link phone number + "24/7" badge. (`AppShell` top bar, `Button` ripple, `MultiStateBadge`)
2. **Hero** — headline ("Stranded? We're on the way"), subcopy, primary CTA "Call Now" (tel: link, large), secondary CTA "Request a Tow" (scrolls to form). Glass surface over a themed backdrop, live "average response time" stat. (`Stat` count-up, `Button` ripple, `GradientText` on headline)
3. **Services grid** — towing, jumpstart, flat tire, lockout, fuel delivery, winch-out. Icon + title + blurb per card. (`Card` tilt/spotlight, lucide icons)
4. **Coverage area** — map placeholder with service radius, list of covered cities/zip codes. (`Card`, `Descriptions`, `Badge`)
5. **Request a tow form** — name, phone, vehicle type, location (address input + "use my location" affordance), issue `Select`, notes. Submit triggers `Toast` confirmation. (`Form`, `Input`, `Select`, `TagInput` for vehicle type, `Button` ripple, `Toast`)
6. **Pricing / response time** — base rate, per-mile rate, average ETA by zone. (`Table` or `Descriptions`, `RingProgress` for ETA, `PriceTag`)
7. **Trust & credentials** — licensed/insured badges, years in operation, certifications, fleet size. (`Stat` count-up, `Badge`, `Card`)
8. **Testimonials** — rotating reviews with rating. (`Carousel` swipe, `Rating`, `Avatar`)
9. **FAQ** — "how fast can you get here", "do you take insurance", "what payment methods". (`Accordion` animated height)
10. **Contact** — full contact section: phone, dispatch email, address, hours (with live open/closed via `Clock`), map placeholder, social links, plus a second lightweight contact form for non-emergency inquiries. (`Descriptions`, `Clock`, `Card`, `Form`)
11. **Footer** — nav, contact, socials, legal, licensing numbers.
12. **Floating CTA** — persistent floating call button, visible across all scroll positions (mobile especially). (`FloatingActionButton` ripple)

## Structure

**Single-page** (long scroll + sticky anchor nav), per CONVENTIONS.md. The
emergency bar and floating action button are the only persistent chrome
outside the scroll — no route changes ever separate a visitor from the call
CTA.

## Custom theme

Urgent/high-visibility: safety-orange primary (tow-truck amber/orange),
near-black secondary, high-contrast white text, larger touch targets on CTAs.
Override `--primary` / `--accent` / `--radius-*` tokens; verify WCAG AA
contrast on the orange-on-dark call button specifically since it's the single
most important element on the page.

## Animation / parallax

- `Parallax` on hero backdrop (road/asphalt texture).
- `ScrollProgress` bar tied to the anchor nav.
- `TextReveal` on section headings as they enter viewport.
- `GradientText` on hero headline, `ScrambleText` on the response-time stat label.
- `TiltCard` + `Spotlight` on services grid cards.
- `Magnetic` + `Ripple` on the primary Call Now button and the FloatingActionButton.
- `Carousel` swipe for testimonials, `List` stagger for the services grid entrance.
- `MultiStateBadge` cycling "Available now" / "24/7" in the emergency bar.
- Respect `prefers-reduced-motion` throughout (default A4ui behavior).

## Reusable candidates

- **Emergency/sticky action bar** (tel: CTA + status badge, persistent across scroll) — generalizes to any urgent-service vertical (hvac, plumbing). Propose as an A4ui pattern/component.
- **"Request service" form with geolocation-assisted address field** — reusable across towing, hvac, home-services templates.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `towing` theme tokens (WCAG AA check on CTA contrast)
- [ ] Emergency top bar + floating call CTA
- [ ] Hero with response-time stat
- [ ] Services grid
- [ ] Coverage area section (map placeholder)
- [ ] Request-a-tow form (with validation + toast confirmation)
- [ ] Pricing / response-time table
- [ ] Trust & credentials band
- [ ] Testimonials carousel
- [ ] FAQ accordion
- [ ] Contact section (hours, map, secondary form) + footer
- [ ] Responsive pass (mobile-first, CTA thumb-reachable) + deploy to Cloudflare Pages
