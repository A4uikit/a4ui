import {
  Accordion,
  ActionBar,
  Aurora,
  Badge,
  Button,
  Card,
  Carousel,
  FloatingActionButton,
  GradientText,
  Input,
  Magnetic,
  Parallax,
  Rating,
  ScrollProgress,
  Section,
  Stat,
  Textarea,
  TextReveal,
} from '@a4ui/core'
import {
  Award,
  AtSign,
  BatteryCharging,
  Cable,
  Clock,
  Fuel,
  KeyRound,
  LifeBuoy,
  Mail,
  MapPin,
  MessageCircle,
  Navigation,
  Phone,
  PhoneCall,
  ShieldCheck,
  Siren,
  Truck,
  Wrench,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const PHONE_DISPLAY = '55 8888 0024'
const PHONE_TEL = 'tel:+525588880024'
const DISPATCH_EMAIL = 'despacho@gruasrescate24.mx'

const NAV = [
  { href: '#servicios', label: 'Servicios' },
  { href: '#cobertura', label: 'Cobertura' },
  { href: '#solicitar', label: 'Solicitar grúa' },
  { href: '#precios', label: 'Precios' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contacto', label: 'Contacto' },
]

const SERVICES: { icon: JSX.Element; title: string; blurb: string; price: string }[] = [
  { icon: <Truck class="h-6 w-6" />, title: 'Arrastre de vehículo', blurb: 'Grúa de plataforma o arrastre para autos, SUV y camionetas.', price: 'desde $650' },
  { icon: <BatteryCharging class="h-6 w-6" />, title: 'Paso de corriente', blurb: 'Batería descargada? Arrancamos tu auto en minutos.', price: 'desde $350' },
  { icon: <Wrench class="h-6 w-6" />, title: 'Cambio de llanta', blurb: 'Ponchadura en carretera o ciudad, montamos tu refacción.', price: 'desde $400' },
  { icon: <KeyRound class="h-6 w-6" />, title: 'Apertura sin llave', blurb: 'Te quedaste las llaves dentro? Abrimos sin dañar tu auto.', price: 'desde $450' },
  { icon: <Fuel class="h-6 w-6" />, title: 'Envío de gasolina', blurb: 'Te quedaste sin combustible, te llevamos litros al instante.', price: 'desde $300' },
  { icon: <Cable class="h-6 w-6" />, title: 'Desatascado', blurb: 'Auto atascado en lodo, arena o zanja — te sacamos con cable.', price: 'desde $700' },
]

const COVERAGE_ZONES = [
  'Ciudad de México — todas las alcaldías',
  'Naucalpan, Tlalnepantla y Atizapán',
  'Ecatepec e Izcalli',
  'Interlomas y Santa Fe',
  'Toluca y zona oriente del Valle de México',
]

const ETA_ZONES: { zone: string; minutes: number }[] = [
  { zone: 'Centro / Zona 1', minutes: 12 },
  { zone: 'Norte / Zona 2', minutes: 18 },
  { zone: 'Poniente / Zona 3', minutes: 20 },
  { zone: 'Sur / Zona 4', minutes: 22 },
]

const VEHICLE_TYPES = ['Auto', 'SUV / Camioneta', 'Moto', 'Camión ligero']
const ISSUE_TYPES = ['Arrastre / grúa', 'Batería', 'Llanta ponchada', 'Cerrado por dentro', 'Sin gasolina', 'Atascado']

const REVIEWS = [
  { name: 'Ricardo M.', quote: 'Se me ponchó una llanta en la autopista a las 11 de la noche. Llegaron en 15 minutos.', rating: 5 },
  { name: 'Fernanda G.', quote: 'Me quedé sin batería en el estacionamiento del trabajo. Servicio rapidísimo y buen precio.', rating: 5 },
  { name: 'Javier O.', quote: 'Me cerré las llaves adentro del coche con mi hija dentro. Vinieron de inmediato, muy profesionales.', rating: 5 },
]

const FAQ = [
  { value: 'q1', title: '¿Qué tan rápido llegan?', content: 'Nuestro tiempo de respuesta promedio es de 12 a 22 minutos según tu zona. Verás una estimación al enviar tu solicitud.' },
  { value: 'q2', title: '¿Trabajan con aseguradoras?', content: 'Sí, facturamos directo a la mayoría de las aseguradoras. Si tu póliza incluye asistencia vial, dinos el nombre de tu aseguradora al llamar.' },
  { value: 'q3', title: '¿Qué formas de pago aceptan?', content: 'Efectivo, tarjeta de crédito/débito y transferencia. El operador lleva terminal portátil.' },
  { value: 'q4', title: '¿Atienden de noche y fin de semana?', content: 'Estamos disponibles 24 horas, los 7 días del año, incluyendo días festivos, sin costo adicional por horario.' },
  { value: 'q5', title: '¿Qué hago mientras espero la grúa?', content: 'Enciende las intermitentes, colócate en un lugar seguro fuera del carril y, si es de noche, usa el triángulo de seguridad si lo tienes.' },
]

export function App(): JSX.Element {
  // Request-a-tow form (primary conversion)
  const [name, setName] = createSignal('')
  const [phone, setPhone] = createSignal('')
  const [address, setAddress] = createSignal('')
  const [vehicle, setVehicle] = createSignal(VEHICLE_TYPES[0])
  const [issue, setIssue] = createSignal(ISSUE_TYPES[0])
  const [notes, setNotes] = createSignal('')
  const [sent, setSent] = createSignal(false)
  const [locating, setLocating] = createSignal<'idle' | 'loading' | 'error'>('idle')

  const useMyLocation = (): void => {
    if (!navigator.geolocation) {
      setLocating('error')
      return
    }
    setLocating('loading')
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setAddress(`${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`)
        setLocating('idle')
      },
      () => setLocating('error'),
      { enableHighAccuracy: true, timeout: 8000 },
    )
  }

  const submitTow = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  // Secondary, non-emergency contact form
  const [cName, setCName] = createSignal('')
  const [cEmail, setCEmail] = createSignal('')
  const [cMessage, setCMessage] = createSignal('')
  const [cSent, setCSent] = createSignal(false)

  const submitContact = (e: Event): void => {
    e.preventDefault()
    setCSent(true)
  }

  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress />

      <Aurora />

      {/* Emergency bar — sticky, always visible, the tel: CTA never scrolls away */}
      <ActionBar
        status={<Badge tone="success" pulse>24/7</Badge>}
        message="¿Te quedaste varado? Un operador va en camino."
        action={{ label: 'Llamar ahora', href: PHONE_TEL }}
      />

      <header class="border-b border-primary/30 bg-background/95 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-3">
          <a href="#top" class="flex shrink-0 items-center gap-2 font-semibold tracking-tight">
            <Truck class="h-5 w-5 text-primary" /> <span>Grúas Rescate 24</span>
          </a>
          <nav class="hidden items-center gap-5 text-sm text-muted-foreground lg:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <div id="top" class="relative overflow-hidden">
        <Parallax amount={50} class="pointer-events-none absolute inset-0 -z-10 opacity-80">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.22), transparent 70%), radial-gradient(45% 40% at 85% 15%, hsl(var(--accent) / 0.14), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-24 text-center sm:!py-28">
          <Badge tone="success" pulse class="mb-5">
            <Siren class="h-3.5 w-3.5" /> 24/7 DISPONIBLE · Todo el año
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            <TextReveal text="¿Te quedaste varado?" class="inline" />{' '}
            <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">Vamos en camino</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Grúa, batería, llanta o gasolina — un operador certificado llega a donde estés, cualquier hora, cualquier día.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <a
              href={PHONE_TEL}
              class="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-7 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/30 transition-transform hover:scale-[1.03] active:scale-[0.98]"
            >
              <PhoneCall class="h-5 w-5" /> Llamar ahora · {PHONE_DISPLAY}
            </a>
            <Magnetic strength={14}>
              <Button variant="outline" ripple onClick={() => (window.location.hash = '#solicitar')}>
                Solicitar grúa
              </Button>
            </Magnetic>
          </div>
          <div class="mx-auto mt-12 max-w-xs">
            <Stat label="Tiempo de respuesta promedio" value={18} format={(n) => `${Math.round(n)} min`} tone="primary" icon={<Clock class="h-5 w-5" />} />
          </div>
        </Section>
      </div>

      {/* Services */}
      <Section id="servicios">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Servicios de asistencia vial" onView /></h2>
          <p class="mt-2 text-muted-foreground">Cobertura completa para cualquier imprevisto en el camino.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={SERVICES}>
            {(s) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {s.icon}
                </div>
                <h3 class="text-lg font-semibold">{s.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
                <p class="mt-4 text-sm font-medium text-primary">{s.price}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Coverage area */}
      <div id="cobertura" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="grid gap-8 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">Zona de cobertura</h2>
              <p class="mt-2 text-muted-foreground">
                Flota distribuida en toda la zona metropolitana para llegar más rápido, sin importar dónde te encuentres.
              </p>
              <ul class="mt-6 space-y-3 text-sm">
                <For each={COVERAGE_ZONES}>
                  {(z) => (
                    <li class="flex items-center gap-3">
                      <MapPin class="h-4 w-4 shrink-0 text-primary" /> {z}
                    </li>
                  )}
                </For>
              </ul>
            </div>
            <Card glass class="relative flex h-64 items-center justify-center overflow-hidden p-0 sm:h-80">
              <div
                class="absolute inset-0 opacity-40"
                style={{
                  'background-image':
                    'linear-gradient(hsl(var(--border)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--border)) 1px, transparent 1px)',
                  'background-size': '28px 28px',
                }}
              />
              <div class="relative flex flex-col items-center gap-2 text-center">
                <MapPin class="h-8 w-8 text-primary" />
                <span class="text-sm font-medium text-muted-foreground">Mapa de radio de servicio</span>
                <span class="text-xs text-muted-foreground">~45 km desde el centro de despacho</span>
              </div>
            </Card>
          </div>
        </Section>
      </div>

      {/* Request a tow — primary conversion */}
      <Section id="solicitar" class="!py-20">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight"><TextReveal text="Solicita tu grúa" onView /></h2>
          <p class="mt-2 text-muted-foreground">Completa el formulario y despachamos una unidad de inmediato. Para emergencias, mejor llama.</p>
        </div>
        <Card glass class="mx-auto max-w-2xl p-6 sm:p-8">
          {sent() ? (
            <div class="flex flex-col items-center justify-center py-10 text-center">
              <Badge tone="success" pulse class="mb-3">Solicitud enviada</Badge>
              <p class="text-lg font-medium">¡Gracias, {name() || 'ya vamos en camino'}!</p>
              <p class="mt-1 text-sm text-muted-foreground">
                Un operador te llamará al {phone() || 'número que dejaste'} en los próximos minutos. ETA estimado: 12–22 min.
              </p>
            </div>
          ) : (
            <form class="space-y-4" onSubmit={submitTow}>
              <div class="grid gap-4 sm:grid-cols-2">
                <div>
                  <label for="tow-name" class="mb-1 block text-sm font-medium">Nombre</label>
                  <Input id="tow-name" value={name()} onInput={setName} placeholder="Tu nombre" required />
                </div>
                <div>
                  <label for="tow-phone" class="mb-1 block text-sm font-medium">Teléfono</label>
                  <Input id="tow-phone" value={phone()} onInput={setPhone} placeholder="55 0000 0000" type="tel" required />
                </div>
              </div>

              <div>
                <label for="tow-address" class="mb-1 block text-sm font-medium">Ubicación actual</label>
                <div class="flex gap-2">
                  <Input id="tow-address" value={address()} onInput={setAddress} placeholder="Calle, colonia o cruce de calles" required class="flex-1" />
                  <Button type="button" variant="outline" onClick={useMyLocation} class="shrink-0">
                    <Navigation class="h-4 w-4" />
                    <span class="hidden sm:inline">Usar mi ubicación</span>
                  </Button>
                </div>
                {locating() === 'loading' && <p class="mt-1 text-xs text-muted-foreground">Detectando ubicación…</p>}
                {locating() === 'error' && <p class="mt-1 text-xs text-destructive">No pudimos obtener tu ubicación. Escríbela manualmente.</p>}
              </div>

              <div>
                <label id="tow-vehicle-label" class="mb-1 block text-sm font-medium">Tipo de vehículo</label>
                <div class="flex flex-wrap gap-2" role="group" aria-labelledby="tow-vehicle-label">
                  <For each={VEHICLE_TYPES}>
                    {(v) => (
                      <Button
                        type="button"
                        variant={vehicle() === v ? 'primary' : 'outline'}
                        class="!h-9 !px-3 text-sm"
                        aria-pressed={vehicle() === v}
                        onClick={() => setVehicle(v)}
                      >
                        {v}
                      </Button>
                    )}
                  </For>
                </div>
              </div>

              <div>
                <label id="tow-issue-label" class="mb-1 block text-sm font-medium">¿Qué necesitas?</label>
                <div class="flex flex-wrap gap-2" role="group" aria-labelledby="tow-issue-label">
                  <For each={ISSUE_TYPES}>
                    {(i) => (
                      <Button
                        type="button"
                        variant={issue() === i ? 'primary' : 'outline'}
                        class="!h-9 !px-3 text-sm"
                        aria-pressed={issue() === i}
                        onClick={() => setIssue(i)}
                      >
                        {i}
                      </Button>
                    )}
                  </For>
                </div>
              </div>

              <div>
                <label for="tow-notes" class="mb-1 block text-sm font-medium">Notas adicionales</label>
                <Textarea id="tow-notes" value={notes()} onInput={setNotes} placeholder="Color y modelo del auto, referencias del lugar, etc." rows={3} />
              </div>

              <Button ripple type="submit" class="w-full !h-12 text-base">Solicitar grúa ahora</Button>
              <p class="text-center text-xs text-muted-foreground">
                ¿Es una emergencia? <a href={PHONE_TEL} class="font-medium text-primary hover:underline">Mejor llama al {PHONE_DISPLAY}</a>
              </p>
            </form>
          )}
        </Card>
      </Section>

      {/* Pricing / response time */}
      <div id="precios" class="border-y border-border/60 bg-muted/30">
        <Section class="!py-16">
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Precios y tiempo de respuesta</h2>
            <p class="mt-2 text-muted-foreground">Tarifas claras, sin sorpresas. Te cotizamos antes de despachar la unidad.</p>
          </div>
          <div class="grid gap-5 sm:grid-cols-2">
            <Stat label="Tarifa base" value={650} format={(n) => `$${Math.round(n)} MXN`} tone="primary" icon={<Truck class="h-5 w-5" />} />
            <Stat label="Costo por km adicional" value={25} format={(n) => `$${Math.round(n)} MXN`} tone="neutral" icon={<MapPin class="h-5 w-5" />} />
          </div>
          <div class="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <For each={ETA_ZONES}>
              {(z, i) => <Stat label={z.zone} value={z.minutes} format={(n) => `${Math.round(n)} min`} tone="primary" icon={<Clock class="h-5 w-5" />} delay={i() * 0.08} />}
            </For>
          </div>
        </Section>
      </div>

      {/* Trust & credentials */}
      <Section id="confianza">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Confianza y respaldo</h2>
          <p class="mt-2 text-muted-foreground">Operadores certificados, unidades aseguradas, más de una década en el camino.</p>
        </div>
        <div class="grid gap-6 sm:grid-cols-3">
          <Stat label="Años en operación" value={13} tone="primary" icon={<Award class="h-5 w-5" />} />
          <Stat label="Unidades en flota" value={34} tone="neutral" icon={<Truck class="h-5 w-5" />} />
          <Stat label="Servicios al mes" value={2100} format={(n) => `${Math.round(n / 100) / 10}k+`} tone="primary" icon={<LifeBuoy class="h-5 w-5" />} />
        </div>
        <div class="mt-8 flex flex-wrap justify-center gap-3">
          <Badge tone="info"><ShieldCheck class="h-3.5 w-3.5" /> Licencia SCT vigente</Badge>
          <Badge tone="info"><ShieldCheck class="h-3.5 w-3.5" /> Unidades aseguradas</Badge>
          <Badge tone="info"><Award class="h-3.5 w-3.5" /> Operadores certificados</Badge>
        </div>
      </Section>

      {/* Testimonials */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section id="resenas" class="!py-16">
          <div class="mb-8 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Lo que dicen nuestros clientes</h2>
          </div>
          <div class="mx-auto max-w-2xl">
            <Carousel
              class="reviews-carousel"
              autoplayMs={5000}
              slides={REVIEWS.map((r) => (
                <div class="px-2">
                  <Card glass class="p-8 text-center">
                    <Rating value={r.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                    <p class="text-lg">&ldquo;{r.quote}&rdquo;</p>
                    <p class="mt-4 text-sm font-medium text-muted-foreground">— {r.name}</p>
                  </Card>
                </div>
              ))}
            />
          </div>
        </Section>
      </div>

      {/* FAQ */}
      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">Preguntas frecuentes</h2>
          <Accordion items={FAQ} />
        </div>
      </Section>

      {/* Contact */}
      <div id="contacto" class="border-t border-border/60 bg-muted/30">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">Contáctanos</h2>
              <p class="mt-2 text-muted-foreground">Para emergencias, llama directo. Para todo lo demás, escríbenos.</p>
              <ul class="mt-8 space-y-4 text-sm">
                <li class="flex items-center gap-3"><Phone class="h-5 w-5 text-primary" /> <a href={PHONE_TEL} class="hover:text-primary">{PHONE_DISPLAY}</a></li>
                <li class="flex items-center gap-3"><Mail class="h-5 w-5 text-primary" /> {DISPATCH_EMAIL}</li>
                <li class="flex items-center gap-3"><MapPin class="h-5 w-5 text-primary" /> Anillo Periférico 4500, CDMX</li>
                <li class="flex items-center gap-3">
                  <Clock class="h-5 w-5 text-primary" /> Disponible 24 horas, los 7 días
                  <Badge tone="success" pulse class="ml-1">Abierto ahora</Badge>
                </li>
              </ul>
              <div class="mt-6 flex gap-1 text-muted-foreground">
                <a href="#" aria-label="Correo" class="inline-flex h-9 w-9 items-center justify-center rounded-md transition-colors hover:bg-muted/60 hover:text-primary"><AtSign class="h-5 w-5" /></a>
                <a href="#" aria-label="WhatsApp" class="inline-flex h-9 w-9 items-center justify-center rounded-md transition-colors hover:bg-muted/60 hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
              </div>
              <Card glass class="mt-6 flex h-40 items-center justify-center overflow-hidden p-0">
                <div class="flex flex-col items-center gap-1 text-center text-muted-foreground">
                  <MapPin class="h-6 w-6 text-primary" />
                  <span class="text-xs">Mapa — Anillo Periférico 4500, CDMX</span>
                </div>
              </Card>
            </div>

            <Card glass class="p-6">
              <h3 class="text-lg font-semibold">Consultas no urgentes</h3>
              <p class="mt-1 text-sm text-muted-foreground">Cotizaciones, facturación o dudas generales — te respondemos en menos de 24 horas.</p>
              {cSent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {cName() || 'te contactamos pronto'}!</p>
                </div>
              ) : (
                <form class="mt-4 space-y-4" onSubmit={submitContact}>
                  <div>
                    <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                    <Input id="contact-name" value={cName()} onInput={setCName} placeholder="Tu nombre" required />
                  </div>
                  <div>
                    <label for="contact-email" class="mb-1 block text-sm font-medium">Correo</label>
                    <Input id="contact-email" value={cEmail()} onInput={setCEmail} placeholder="tu@correo.com" type="email" required />
                  </div>
                  <div>
                    <label for="contact-message" class="mb-1 block text-sm font-medium">Mensaje</label>
                    <Textarea id="contact-message" value={cMessage()} onInput={setCMessage} placeholder="¿En qué te ayudamos?" rows={4} />
                  </div>
                  <Button ripple type="submit" class="w-full">Enviar mensaje</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto max-w-6xl px-5 py-10 text-sm text-muted-foreground">
          <div class="flex flex-col items-center justify-between gap-6 sm:flex-row sm:items-start">
            <div>
              <span class="flex items-center gap-2 font-medium text-foreground"><Truck class="h-4 w-4 text-primary" /> Grúas Rescate 24</span>
              <p class="mt-2 max-w-xs text-xs">Asistencia vial 24/7 en la zona metropolitana. Permiso SCT-CDMX-00452.</p>
            </div>
            <nav class="flex flex-wrap justify-center gap-4 text-xs">
              <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
            </nav>
            <div class="flex gap-1">
              <a href="#" aria-label="Correo" class="inline-flex h-9 w-9 items-center justify-center rounded-md transition-colors hover:bg-muted/60 hover:text-primary"><AtSign class="h-5 w-5" /></a>
              <a href="#" aria-label="WhatsApp" class="inline-flex h-9 w-9 items-center justify-center rounded-md transition-colors hover:bg-muted/60 hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
            </div>
          </div>
          <div class="mt-8 border-t border-border/60 pt-6 text-center text-xs">© 2026 Grúas Rescate 24. Hecho con A4ui.</div>
        </div>
      </footer>

      {/* Floating call CTA — persistent across all scroll positions */}
      <FloatingActionButton
        icon={<PhoneCall class="h-6 w-6" />}
        label="Llamar ahora"
        ripple
        position="bottom-right"
        onClick={() => {
          window.location.href = PHONE_TEL
        }}
      />
    </div>
  )
}
