# Template: `sports` — Sports news & standings

A data-heavy sports site. Goal: news, fixtures, standings, team pages, stats —
exercises the tables/data/charts side of A4ui.

## Sections / routes

1. **Top bar** — league nav, `Tabs` per sport/competition.
2. **Hero** — featured match or headline story. (`Card`, `Badge`)
3. **News grid** — article cards with image + category tag.
4. **Fixtures & results** — upcoming/past matches. (`List`, `Timeline`, `Badge` scores)
5. **Standings table** — league table (pos, team, P/W/D/L, GD, pts). (`Table` or `DataGrid`, sortable)
6. **Team page** — crest, form, roster (`Table`), season stats (`Stat`, `BarChart`, `DonutChart`).
7. **Schedule** — calendar/heatmap of match density. (`CalendarHeatmap`, `Calendar`)
8. **Footer**

## Data

Sample static dataset: teams, fixtures, standings, player stats.

## Custom theme

Bold sport: strong primary (team-color-driven), high contrast, condensed headings.

## Tasks (→ issues)

- [ ] Scaffold app + routing
- [ ] `sports` theme tokens
- [ ] Sample dataset (teams / fixtures / standings / stats)
- [ ] Top bar + sport tabs
- [ ] Hero + news grid
- [ ] Fixtures & results
- [ ] Standings table (sortable)
- [ ] Team page (roster + stat charts)
- [ ] Schedule / heatmap
- [ ] Responsive pass + deploy
