import { Aurora, ScrollProgress } from '@a4ui/core'
import { A, Route, Router } from '@solidjs/router'
import { Calendar, ListOrdered, Trophy } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { Home } from './pages/Home'
import { NotFound } from './pages/NotFound'
import { Schedule } from './pages/Schedule'
import { Standings } from './pages/Standings'
import { Team } from './pages/Team'

const NAV = [
  { href: '/', label: 'Inicio' },
  { href: '/tabla', label: 'Tabla' },
  { href: '/calendario', label: 'Calendario' },
]

function Layout(props: { children?: JSX.Element }): JSX.Element {
  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress color="hsl(var(--accent))" />
      <Aurora />
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <A href="/" class="flex items-center gap-2 py-1 font-semibold tracking-tight">
            <Trophy class="h-5 w-5 text-primary" /> GolMX
          </A>
          <nav class="hidden items-center gap-1 rounded-full border border-border/60 bg-muted/40 p-1 text-sm md:flex">
            <For each={NAV}>
              {(n) => (
                <A
                  href={n.href}
                  end={n.href === '/'}
                  class="rounded-full px-4 py-1.5 text-muted-foreground transition-colors hover:text-foreground"
                  activeClass="!bg-primary !text-primary-foreground"
                >
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <A
            href="/tabla"
            class="flex items-center gap-2 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground md:hidden"
          >
            <ListOrdered class="h-4 w-4" /> Tabla
          </A>
        </div>
      </header>

      {props.children}

      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2">
            <Trophy class="h-4 w-4 text-primary" /> GolMX · Liga MX GolMX & Copa GolMX
          </span>
          <nav class="flex items-center gap-5">
            <For each={NAV}>
              {(n) => (
                <A href={n.href} class="py-1.5 transition-colors hover:text-foreground">
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <span class="flex items-center gap-2">
            <Calendar class="h-4 w-4" /> © 2026 GolMX. Hecho con A4ui.
          </span>
        </div>
      </footer>
    </div>
  )
}

export function App(): JSX.Element {
  return (
    <Router root={Layout}>
      <Route path="/" component={Home} />
      <Route path="/tabla" component={Standings} />
      <Route path="/calendario" component={Schedule} />
      <Route path="/equipo/:id" component={Team} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}
