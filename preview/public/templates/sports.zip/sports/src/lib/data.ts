/** Sample data for the GolMX sports template. Invented league, teams, and stats. */

export interface Team {
  id: string
  name: string
  short: string
  city: string
  founded: number
  color: string
  form: ('W' | 'D' | 'L')[]
}

export interface StandingsRow {
  teamId: string
  played: number
  won: number
  drawn: number
  lost: number
  gf: number
  ga: number
}

export interface Fixture {
  id: string
  competition: 'Liga MX' | 'Copa GolMX'
  matchday: number
  date: string
  time: string
  home: string
  away: string
  homeScore?: number
  awayScore?: number
  venue: string
  status: 'scheduled' | 'live' | 'finished'
}

export interface Player {
  id: string
  teamId: string
  name: string
  position: 'POR' | 'DEF' | 'MED' | 'DEL'
  number: number
  age: number
  goals: number
  assists: number
}

export interface NewsItem {
  id: string
  title: string
  summary: string
  category: string
  date: string
}

export const TEAMS: Team[] = [
  { id: 'mty', name: 'Titanes de Monterrey', short: 'MTY', city: 'Monterrey', founded: 1974, color: '152 65% 42%', form: ['W', 'W', 'D', 'W', 'W'] },
  { id: 'gdl', name: 'Panteras de Guadalajara', short: 'GDL', city: 'Guadalajara', founded: 1968, color: '221 75% 50%', form: ['W', 'W', 'W', 'D', 'L'] },
  { id: 'agf', name: 'Águilas de la Frontera', short: 'AGF', city: 'Tijuana', founded: 1981, color: '355 70% 48%', form: ['D', 'W', 'L', 'W', 'D'] },
  { id: 'son', name: 'Halcones de Sonora', short: 'SON', city: 'Hermosillo', founded: 1977, color: '28 85% 50%', form: ['W', 'L', 'W', 'D', 'W'] },
  { id: 'ver', name: 'Tiburones de Veracruz', short: 'VER', city: 'Veracruz', founded: 1963, color: '199 80% 42%', form: ['L', 'D', 'W', 'W', 'L'] },
  { id: 'tab', name: 'Jaguares de Tabasco', short: 'TAB', city: 'Villahermosa', founded: 1989, color: '84 55% 38%', form: ['D', 'D', 'L', 'W', 'D'] },
  { id: 'pue', name: 'Rayos de Puebla', short: 'PUE', city: 'Puebla', founded: 1972, color: '271 60% 50%', form: ['L', 'W', 'D', 'L', 'W'] },
  { id: 'oax', name: 'Cóndores de Oaxaca', short: 'OAX', city: 'Oaxaca', founded: 1993, color: '43 90% 48%', form: ['D', 'L', 'W', 'L', 'D'] },
  { id: 'dgo', name: 'Lobos de Durango', short: 'DGO', city: 'Durango', founded: 1985, color: '215 15% 45%', form: ['L', 'L', 'D', 'L', 'W'] },
  { id: 'chh', name: 'Toros de Chihuahua', short: 'CHH', city: 'Chihuahua', founded: 1990, color: '15 70% 45%', form: ['L', 'L', 'L', 'D', 'L'] },
]

export const STANDINGS_LIGA: StandingsRow[] = [
  { teamId: 'mty', played: 14, won: 10, drawn: 2, lost: 2, gf: 32, ga: 14 },
  { teamId: 'gdl', played: 14, won: 9, drawn: 3, lost: 2, gf: 28, ga: 15 },
  { teamId: 'agf', played: 14, won: 8, drawn: 4, lost: 2, gf: 25, ga: 16 },
  { teamId: 'son', played: 14, won: 7, drawn: 4, lost: 3, gf: 24, ga: 18 },
  { teamId: 'ver', played: 14, won: 7, drawn: 3, lost: 4, gf: 22, ga: 19 },
  { teamId: 'tab', played: 14, won: 6, drawn: 5, lost: 3, gf: 20, ga: 17 },
  { teamId: 'pue', played: 14, won: 6, drawn: 3, lost: 5, gf: 21, ga: 22 },
  { teamId: 'oax', played: 14, won: 5, drawn: 4, lost: 5, gf: 18, ga: 20 },
  { teamId: 'dgo', played: 14, won: 4, drawn: 3, lost: 7, gf: 16, ga: 25 },
  { teamId: 'chh', played: 14, won: 2, drawn: 4, lost: 8, gf: 12, ga: 28 },
]

export const STANDINGS_COPA: StandingsRow[] = [
  { teamId: 'mty', played: 4, won: 3, drawn: 1, lost: 0, gf: 9, ga: 3 },
  { teamId: 'gdl', played: 4, won: 3, drawn: 0, lost: 1, gf: 8, ga: 4 },
  { teamId: 'agf', played: 4, won: 2, drawn: 1, lost: 1, gf: 7, ga: 5 },
  { teamId: 'son', played: 4, won: 2, drawn: 0, lost: 2, gf: 6, ga: 6 },
  { teamId: 'ver', played: 4, won: 1, drawn: 1, lost: 2, gf: 5, ga: 7 },
  { teamId: 'tab', played: 4, won: 0, drawn: 1, lost: 3, gf: 3, ga: 9 },
]

export function points(row: StandingsRow): number {
  return row.won * 3 + row.drawn
}

export function goalDiff(row: StandingsRow): number {
  return row.gf - row.ga
}

export function sortedStandings(rows: StandingsRow[]): StandingsRow[] {
  return [...rows].sort((a, b) => points(b) - points(a) || goalDiff(b) - goalDiff(a) || b.gf - a.gf)
}

export function getTeam(id: string): Team | undefined {
  return TEAMS.find((t) => t.id === id)
}

export const FIXTURES: Fixture[] = [
  { id: 'f1', competition: 'Liga MX', matchday: 14, date: '2026-07-12', time: '17:00', home: 'mty', away: 'chh', homeScore: 3, awayScore: 1, venue: 'Estadio del Titán', status: 'finished' },
  { id: 'f2', competition: 'Liga MX', matchday: 14, date: '2026-07-12', time: '19:00', home: 'gdl', away: 'agf', homeScore: 2, awayScore: 2, venue: 'Coliseo Pantera', status: 'finished' },
  { id: 'f3', competition: 'Liga MX', matchday: 14, date: '2026-07-13', time: '12:00', home: 'son', away: 'oax', homeScore: 1, awayScore: 0, venue: 'Nido del Halcón', status: 'finished' },
  { id: 'f4', competition: 'Liga MX', matchday: 14, date: '2026-07-13', time: '17:00', home: 'ver', away: 'pue', homeScore: 2, awayScore: 1, venue: 'Arrecife Tiburón', status: 'finished' },
  { id: 'f5', competition: 'Liga MX', matchday: 14, date: '2026-07-13', time: '19:00', home: 'tab', away: 'dgo', homeScore: 0, awayScore: 0, venue: 'Selva Jaguar', status: 'finished' },
  { id: 'f6', competition: 'Liga MX', matchday: 15, date: '2026-07-19', time: '20:00', home: 'mty', away: 'gdl', venue: 'Estadio del Titán', status: 'scheduled' },
  { id: 'f7', competition: 'Liga MX', matchday: 15, date: '2026-07-20', time: '12:00', home: 'agf', away: 'son', venue: 'Nido del Águila', status: 'scheduled' },
  { id: 'f8', competition: 'Liga MX', matchday: 15, date: '2026-07-20', time: '17:00', home: 'ver', away: 'tab', venue: 'Arrecife Tiburón', status: 'scheduled' },
  { id: 'f9', competition: 'Liga MX', matchday: 15, date: '2026-07-20', time: '19:00', home: 'oax', away: 'dgo', venue: 'Nido Cóndor', status: 'scheduled' },
  { id: 'f10', competition: 'Liga MX', matchday: 15, date: '2026-07-21', time: '20:00', home: 'pue', away: 'chh', venue: 'Templo del Rayo', status: 'scheduled' },
  { id: 'f11', competition: 'Copa GolMX', matchday: 5, date: '2026-07-22', time: '19:00', home: 'gdl', away: 'mty', venue: 'Coliseo Pantera', status: 'scheduled' },
  { id: 'f12', competition: 'Copa GolMX', matchday: 5, date: '2026-07-23', time: '19:00', home: 'son', away: 'agf', venue: 'Nido del Halcón', status: 'scheduled' },
]

export function fixturesFor(teamId: string): Fixture[] {
  return FIXTURES.filter((f) => f.home === teamId || f.away === teamId)
}

const FIRST_NAMES = ['Iker', 'Santiago', 'Emiliano', 'Diego', 'Mateo', 'Bruno', 'Kevin', 'Ángel', 'Leonel', 'Rodrigo', 'Uriel', 'Jesús', 'Marco', 'Édgar', 'Alexis']
const LAST_NAMES = ['Cortés', 'Ramírez', 'Vega', 'Salas', 'Montoya', 'Reyes', 'Cabrera', 'Zamora', 'Duarte', 'Nava', 'Solís', 'Barreto', 'Osuna', 'Peña', 'Quintero']
const POSITIONS: Player['position'][] = ['POR', 'DEF', 'DEF', 'DEF', 'MED', 'MED', 'MED', 'DEL', 'DEL', 'DEL']

function generateRoster(teamId: string, teamIndex: number): Player[] {
  return POSITIONS.map((position, i) => {
    const seed = teamIndex * 10 + i
    const first = FIRST_NAMES[seed % FIRST_NAMES.length]
    const last = LAST_NAMES[(seed * 3 + 1) % LAST_NAMES.length]
    const isAttacker = position === 'DEL'
    const isMid = position === 'MED'
    return {
      id: `${teamId}-p${i + 1}`,
      teamId,
      name: `${first} ${last}`,
      position,
      number: i + 1,
      age: 19 + (seed % 15),
      goals: isAttacker ? 6 + (seed % 9) : isMid ? 2 + (seed % 5) : seed % 3,
      assists: isMid ? 4 + (seed % 6) : isAttacker ? 2 + (seed % 4) : seed % 3,
    }
  })
}

export function rosterFor(teamId: string): Player[] {
  const index = TEAMS.findIndex((t) => t.id === teamId)
  return generateRoster(teamId, index === -1 ? 0 : index)
}

export const NEWS: NewsItem[] = [
  { id: 'n1', title: 'Titanes cierra la contratación de su nuevo lateral', category: 'Fichajes', date: '2026-07-17', summary: 'El club de Monterrey confirmó la llegada de un lateral formado en la cantera para reforzar la banda derecha de cara a la recta final del torneo.' },
  { id: 'n2', title: 'Panteras suma su tercera victoria consecutiva', category: 'Resultados', date: '2026-07-16', summary: 'Guadalajara se afianza en el segundo lugar tras vencer 2-0 como visitante y mantiene la presión sobre el líder del torneo.' },
  { id: 'n3', title: 'Halcones renueva a su capitán por dos temporadas más', category: 'Plantilla', date: '2026-07-15', summary: 'El defensa central, pieza clave del bloque de Sonora, extendió su contrato hasta 2028 tras una campaña sólida.' },
  { id: 'n4', title: 'Análisis: la mejor defensa del torneo tiene nombre y apellido', category: 'Análisis', date: '2026-07-14', summary: 'Con apenas 14 goles recibidos en 14 jornadas, Titanes exhibe la defensa más sólida de la Liga MX GolMX esta temporada.' },
  { id: 'n5', title: 'Copa GolMX: así luce el cuadrangular final', category: 'Copa', date: '2026-07-13', summary: 'Seis equipos se reparten los cuatro boletos a semifinales en una fase de grupos que promete definirse en la última jornada.' },
  { id: 'n6', title: 'Toros busca reaccionar antes de que se le escape la permanencia', category: 'Resultados', date: '2026-07-12', summary: 'El colista de Chihuahua encara jornadas decisivas con la urgencia de sumar puntos para alejarse de la zona de descenso.' },
]

export const FEATURED_FIXTURE_ID = 'f6'
