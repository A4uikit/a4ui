import { Badge, Button, Card, Expandable, Section, Stat, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow, TextReveal } from '@a4ui/core'
import { BarChart, DonutChart } from '@a4ui/core/charts'
import { A, useNavigate, useParams } from '@solidjs/router'
import { Award, ChevronLeft, Goal, Shield, Target, Users } from 'lucide-solid'
import { createMemo, For, type JSX, Show } from 'solid-js'

import { fixturesFor, getTeam, goalDiff, points, rosterFor, STANDINGS_LIGA, type Player } from '../lib/data'

const FORM_TONE: Record<'W' | 'D' | 'L', 'success' | 'neutral' | 'danger'> = {
  W: 'success',
  D: 'neutral',
  L: 'danger',
}

const FORM_LABEL: Record<'W' | 'D' | 'L', string> = { W: 'G', D: 'E', L: 'P' }

export function Team(): JSX.Element {
  const params = useParams<{ id: string }>()
  const navigate = useNavigate()
  const team = createMemo(() => getTeam(params.id))
  const row = createMemo(() => STANDINGS_LIGA.find((r) => r.teamId === params.id))
  const roster = createMemo(() => rosterFor(params.id))
  const fixtures = createMemo(() => fixturesFor(params.id).filter((f) => f.status === 'scheduled').slice(0, 3))

  const topScorers = createMemo<{ label: string; value: number }[]>(() =>
    [...roster()]
      .sort((a, b) => b.goals - a.goals)
      .slice(0, 5)
      .map((p) => ({ label: p.name.split(' ')[1] ?? p.name, value: p.goals })),
  )

  return (
    <Show
      when={team()}
      fallback={
        <Section class="text-center">
          <Shield class="mx-auto mb-4 h-10 w-10 text-primary" />
          <h1 class="text-3xl font-semibold tracking-tight">Equipo no encontrado</h1>
          <Button ripple class="mt-6" onClick={() => navigate('/tabla')}>
            Ver tabla
          </Button>
        </Section>
      }
    >
      {(t) => (
        <>
          <div class="relative overflow-hidden">
            <div
              class="pointer-events-none absolute inset-0 -z-10 opacity-70"
              style={{ background: `radial-gradient(60% 50% at 50% 0%, hsl(${t().color} / 0.25), transparent 70%)` }}
            />
            <Section class="!pb-8">
              <A
                href="/tabla"
                class="mb-6 inline-flex items-center gap-1 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <ChevronLeft class="h-4 w-4" /> Volver a la tabla
              </A>
              <div class="flex flex-col items-start gap-6 sm:flex-row sm:items-center">
                <div
                  class="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl text-xl font-bold text-white"
                  style={{ background: `hsl(${t().color})` }}
                >
                  {t().short}
                </div>
                <div>
                  <h1 class="text-3xl font-semibold tracking-tight sm:text-4xl">
                    <TextReveal text={t().name} />
                  </h1>
                  <p class="mt-1 text-muted-foreground">
                    {t().city} · Fundado en {t().founded}
                  </p>
                  <div class="mt-3 flex items-center gap-1.5">
                    <span class="mr-1 text-xs text-muted-foreground">Últimos 5:</span>
                    <For each={t().form}>
                      {(result) => (
                        <Badge tone={FORM_TONE[result]} class="h-6 w-6 justify-center rounded-full p-0">
                          {FORM_LABEL[result]}
                        </Badge>
                      )}
                    </For>
                  </div>
                </div>
              </div>
            </Section>
          </div>

          {/* Season stats */}
          <Section class="!py-10">
            <Show when={row()}>
              {(r) => (
                <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                  <Stat label="Puntos" value={points(r())} tone="primary" icon={<Award class="h-5 w-5" />} />
                  <Stat label="Partidos jugados" value={r().played} tone="neutral" icon={<Users class="h-5 w-5" />} />
                  <Stat label="Goles a favor" value={r().gf} tone="primary" icon={<Goal class="h-5 w-5" />} />
                  <Stat label="Diferencia de gol" value={goalDiff(r())} tone={goalDiff(r()) >= 0 ? 'primary' : 'danger'} icon={<Target class="h-5 w-5" />} />
                </div>
              )}
            </Show>
          </Section>

          {/* Charts */}
          <div class="border-y border-border/60 bg-muted/30">
            <Section class="!py-14">
              <div class="grid gap-6 lg:grid-cols-2">
                <Card glass class="p-6">
                  <h2 class="mb-4 font-semibold">Goleadores del equipo</h2>
                  <BarChart data={topScorers()} tone="primary" />
                </Card>
                <Card glass class="p-6">
                  <h2 class="mb-4 font-semibold">Resultados de la temporada</h2>
                  <Show when={row()}>
                    {(r) => (
                      <DonutChart
                        data={[
                          { label: 'Ganados', value: r().won, tone: 'primary' },
                          { label: 'Empatados', value: r().drawn, tone: 'accent' },
                          { label: 'Perdidos', value: r().lost, tone: 'destructive' },
                        ]}
                      />
                    )}
                  </Show>
                </Card>
              </div>
            </Section>
          </div>

          {/* Roster */}
          <Section>
            <h2 class="mb-6 text-2xl font-semibold tracking-tight">Plantilla</h2>
            <Card glass class="overflow-hidden p-4 sm:p-6">
              <Table>
                <TableHead>
                  <TableRow>
                    <TableHeadCell>#</TableHeadCell>
                    <TableHeadCell>Jugador</TableHeadCell>
                    <TableHeadCell>Pos</TableHeadCell>
                    <TableHeadCell>Edad</TableHeadCell>
                    <TableHeadCell>Goles</TableHeadCell>
                    <TableHeadCell>Asist.</TableHeadCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <For each={roster()}>{(p: Player) => (
                    <TableRow>
                      <TableCell class="text-muted-foreground">{p.number}</TableCell>
                      <TableCell class="font-medium">
                        <Expandable
                          size="dialog"
                          maxWidth={400}
                          class="-mx-2 -my-1 rounded-lg"
                          panelClass="overflow-hidden rounded-2xl"
                          trigger={
                            <span class="inline-flex cursor-pointer items-center rounded-lg px-2 py-1 transition-colors hover:bg-muted/60">
                              {p.name}
                            </span>
                          }
                        >
                          <div class="p-6">
                            <div class="flex items-center gap-3">
                              <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-lg font-bold text-primary">
                                {p.number}
                              </div>
                              <div>
                                <p class="font-semibold leading-tight">{p.name}</p>
                                <div class="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                                  <Badge tone="neutral">{p.position}</Badge>
                                  {p.age} años
                                </div>
                              </div>
                            </div>
                            <div class="mt-6 grid grid-cols-2 gap-4">
                              <Stat label="Goles" value={p.goals} tone="primary" />
                              <Stat label="Asistencias" value={p.assists} tone="neutral" />
                            </div>
                          </div>
                        </Expandable>
                      </TableCell>
                      <TableCell>
                        <Badge tone="neutral">{p.position}</Badge>
                      </TableCell>
                      <TableCell>{p.age}</TableCell>
                      <TableCell>{p.goals}</TableCell>
                      <TableCell>{p.assists}</TableCell>
                    </TableRow>
                  )}</For>
                </TableBody>
              </Table>
            </Card>
          </Section>

          {/* Upcoming */}
          <Show when={fixtures().length > 0}>
            <div class="border-t border-border/60 bg-muted/30">
              <Section class="!py-14">
                <h2 class="mb-6 text-2xl font-semibold tracking-tight">Próximos partidos</h2>
                <div class="grid gap-4 sm:grid-cols-3">
                  <For each={fixtures()}>
                    {(f) => {
                      const home = getTeam(f.home)
                      const away = getTeam(f.away)
                      return (
                        <Card glass class="p-5">
                          <p class="text-xs text-muted-foreground">
                            {f.competition} · J{f.matchday}
                          </p>
                          <p class="mt-2 font-medium">
                            {home?.short} vs {away?.short}
                          </p>
                          <p class="mt-1 text-sm text-muted-foreground">
                            {f.date} · {f.time}
                          </p>
                        </Card>
                      )
                    }}
                  </For>
                </div>
              </Section>
            </div>
          </Show>
        </>
      )}
    </Show>
  )
}
