import { Badge, Card, Section, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow, Tabs, TextReveal } from '@a4ui/core'
import { A } from '@solidjs/router'
import { ListOrdered, TrendingUp } from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

import { getTeam, goalDiff, points, sortedStandings, STANDINGS_COPA, STANDINGS_LIGA, type StandingsRow } from '../lib/data'

function StandingsTable(props: { rows: StandingsRow[] }): JSX.Element {
  return (
    <Table>
      <TableHead>
        <TableRow>
          <TableHeadCell>#</TableHeadCell>
          <TableHeadCell>Equipo</TableHeadCell>
          <TableHeadCell>PJ</TableHeadCell>
          <TableHeadCell>G</TableHeadCell>
          <TableHeadCell>E</TableHeadCell>
          <TableHeadCell>P</TableHeadCell>
          <TableHeadCell>DG</TableHeadCell>
          <TableHeadCell>Pts</TableHeadCell>
        </TableRow>
      </TableHead>
      <TableBody>
        <For each={sortedStandings(props.rows)}>
          {(row, i) => {
            const team = getTeam(row.teamId)
            if (!team) return null
            const gd = goalDiff(row)
            return (
              <TableRow>
                <TableCell class="font-medium text-muted-foreground">{i() + 1}</TableCell>
                <TableCell>
                  <A href={`/equipo/${team.id}`} class="flex items-center gap-2 font-medium transition-colors hover:text-primary">
                    <span class="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: `hsl(${team.color})` }} />
                    {team.name}
                  </A>
                </TableCell>
                <TableCell>{row.played}</TableCell>
                <TableCell>{row.won}</TableCell>
                <TableCell>{row.drawn}</TableCell>
                <TableCell>{row.lost}</TableCell>
                <TableCell class={gd >= 0 ? 'text-primary' : 'text-destructive'}>{gd > 0 ? `+${gd}` : gd}</TableCell>
                <TableCell class="font-semibold">{points(row)}</TableCell>
              </TableRow>
            )
          }}
        </For>
      </TableBody>
    </Table>
  )
}

export function Standings(): JSX.Element {
  const [tab, setTab] = createSignal('liga')

  return (
    <>
      <Section class="!pb-6 text-center">
        <Badge tone="info" class="mb-4">
          <ListOrdered class="h-3.5 w-3.5" /> Posiciones
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">
          <TextReveal text="Tabla general" />
        </h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Sigue la carrera por el título en la Liga MX GolMX y la fase de grupos de la Copa GolMX.
        </p>
      </Section>

      <Section class="!pt-0">
        <Card glass class="overflow-hidden p-4 sm:p-6">
          <Tabs
            value={tab()}
            onChange={setTab}
            items={[
              { value: 'liga', label: 'Liga MX', content: <StandingsTable rows={STANDINGS_LIGA} /> },
              { value: 'copa', label: 'Copa GolMX', content: <StandingsTable rows={STANDINGS_COPA} /> },
            ]}
          />
        </Card>
        <p class="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <TrendingUp class="h-3.5 w-3.5" /> PJ = jugados, G = ganados, E = empatados, P = perdidos, DG = diferencia de gol, Pts = puntos.
        </p>
      </Section>
    </>
  )
}
