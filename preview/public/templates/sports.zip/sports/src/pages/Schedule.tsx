import { Badge, CalendarHeatmap, Card, Section, TextReveal } from '@a4ui/core'
import { A } from '@solidjs/router'
import { Calendar, MapPin } from 'lucide-solid'
import { createMemo, For, type JSX } from 'solid-js'

import { FIXTURES, type Fixture, getTeam } from '../lib/data'

function FixtureRow(props: { fixture: Fixture }): JSX.Element {
  const home = () => getTeam(props.fixture.home)
  const away = () => getTeam(props.fixture.away)
  const finished = () => props.fixture.status === 'finished'

  return (
    <Card glass class="p-4">
      <div class="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          {props.fixture.competition} · Jornada {props.fixture.matchday}
        </span>
        <Badge tone={finished() ? 'neutral' : 'info'}>{finished() ? 'Finalizado' : 'Programado'}</Badge>
      </div>
      <div class="mt-3 flex items-center justify-between gap-3">
        <A href={`/equipo/${home()?.id}`} class="flex flex-1 items-center gap-2 font-medium transition-colors hover:text-primary">
          <span class="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: `hsl(${home()?.color})` }} />
          {home()?.short}
        </A>
        <span class="shrink-0 text-lg font-semibold">
          {finished() ? `${props.fixture.homeScore} – ${props.fixture.awayScore}` : 'vs'}
        </span>
        <A href={`/equipo/${away()?.id}`} class="flex flex-1 items-center justify-end gap-2 text-right font-medium transition-colors hover:text-primary">
          {away()?.short}
          <span class="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: `hsl(${away()?.color})` }} />
        </A>
      </div>
      <div class="mt-3 flex items-center justify-between text-xs text-muted-foreground">
        <span class="flex items-center gap-1.5">
          <Calendar class="h-3.5 w-3.5" /> {props.fixture.date} · {props.fixture.time}
        </span>
        <span class="flex items-center gap-1.5">
          <MapPin class="h-3.5 w-3.5" /> {props.fixture.venue}
        </span>
      </div>
    </Card>
  )
}

export function Schedule(): JSX.Element {
  const heatmapValues = createMemo(() => {
    const counts = new Map<string, number>()
    for (const f of FIXTURES) counts.set(f.date, (counts.get(f.date) ?? 0) + 1)
    return [...counts.entries()].map(([date, count]) => ({ date, count }))
  })

  const upcoming = createMemo(() => FIXTURES.filter((f) => f.status === 'scheduled').sort((a, b) => a.date.localeCompare(b.date)))
  const results = createMemo(() => FIXTURES.filter((f) => f.status === 'finished').sort((a, b) => b.date.localeCompare(a.date)))

  return (
    <>
      <Section class="!pb-6 text-center">
        <Badge tone="info" class="mb-4">
          <Calendar class="h-3.5 w-3.5" /> Calendario
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">
          <TextReveal text="Calendario de partidos" />
        </h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Próximos duelos y resultados recientes de la Liga MX GolMX y la Copa GolMX.
        </p>
      </Section>

      <Section class="!pt-0">
        <Card glass class="p-6">
          <h2 class="mb-4 font-semibold">Densidad de partidos</h2>
          <CalendarHeatmap values={heatmapValues()} weeks={8} />
        </Card>
      </Section>

      <Section class="!pt-0">
        <div class="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 class="mb-5 text-2xl font-semibold tracking-tight">Próximos partidos</h2>
            <div class="space-y-3">
              <For each={upcoming()}>{(f) => <FixtureRow fixture={f} />}</For>
            </div>
          </div>
          <div>
            <h2 class="mb-5 text-2xl font-semibold tracking-tight">Resultados recientes</h2>
            <div class="space-y-3">
              <For each={results()}>{(f) => <FixtureRow fixture={f} />}</For>
            </div>
          </div>
        </div>
      </Section>
    </>
  )
}
