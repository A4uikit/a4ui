import { Badge, Button, Card, GradientText, Magnetic, Parallax, Section, Stat, TextReveal } from '@a4ui/core'
import { A, useNavigate } from '@solidjs/router'
import { Award, Calendar, MapPin, Newspaper, Sparkles, Trophy, Users } from 'lucide-solid'
import { createMemo, For, type JSX } from 'solid-js'

import { FEATURED_FIXTURE_ID, FIXTURES, getTeam, NEWS, STANDINGS_LIGA, TEAMS } from '../lib/data'

const CATEGORY_TONE: Record<string, 'neutral' | 'success' | 'warning' | 'danger' | 'info'> = {
  Fichajes: 'info',
  Resultados: 'success',
  Plantilla: 'neutral',
  Análisis: 'warning',
  Copa: 'danger',
}

function formatMatchDate(date: string): string {
  const d = new Date(`${date}T00:00:00`)
  const formatted = new Intl.DateTimeFormat('es-MX', { weekday: 'long', day: 'numeric', month: 'long' }).format(d)
  return formatted.charAt(0).toUpperCase() + formatted.slice(1)
}

export function Home(): JSX.Element {
  const navigate = useNavigate()

  const featured = createMemo(() => FIXTURES.find((f) => f.id === FEATURED_FIXTURE_ID))
  const totalGoals = createMemo(() => STANDINGS_LIGA.reduce((sum, r) => sum + r.gf, 0))
  const matchesPlayed = createMemo(() => (STANDINGS_LIGA[0]?.played ?? 0) * (TEAMS.length / 2))

  return (
    <>
      {/* Hero */}
      <div class="relative overflow-hidden">
        <Parallax amount={60} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.25), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.18), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!pb-10 !pt-24 text-center">
          <Badge tone="info" class="mb-5">
            <Trophy class="h-3.5 w-3.5" /> Liga MX GolMX · Temporada 2026
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            La pasión del fútbol, <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">jornada a jornada</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Tabla de posiciones, calendario, estadísticas de equipo y las noticias más recientes de la liga.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={10}>
              <Button ripple onClick={() => navigate('/tabla')}>
                Ver tabla general
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => navigate('/calendario')}>
              Ver calendario
            </Button>
          </div>
        </Section>
      </div>

      {/* Featured match */}
      <Section class="!pt-4">
        {(() => {
          const f = featured()
          if (!f) return null
          const home = getTeam(f.home)
          const away = getTeam(f.away)
          return (
            <Card glass tilt spotlight class="overflow-hidden p-6 sm:p-10">
              <Badge tone="warning" pulse class="mb-6">
                <Sparkles class="h-3.5 w-3.5" /> Partido estelar de la jornada {f.matchday}
              </Badge>
              <div class="flex flex-col items-center justify-between gap-8 sm:flex-row">
                <A href={`/equipo/${home?.id}`} class="flex flex-1 flex-col items-center gap-3 text-center transition-transform hover:-translate-y-0.5">
                  <div
                    class="flex h-16 w-16 items-center justify-center rounded-2xl text-lg font-bold text-white"
                    style={{ background: `hsl(${home?.color})` }}
                  >
                    {home?.short}
                  </div>
                  <span class="font-semibold">{home?.name}</span>
                </A>

                <div class="flex flex-col items-center gap-2">
                  <span class="text-3xl font-bold tracking-tight text-muted-foreground">VS</span>
                  <span class="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <Calendar class="h-4 w-4" /> {formatMatchDate(f.date)} · {f.time}
                  </span>
                  <span class="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <MapPin class="h-4 w-4" /> {f.venue}
                  </span>
                </div>

                <A href={`/equipo/${away?.id}`} class="flex flex-1 flex-col items-center gap-3 text-center transition-transform hover:-translate-y-0.5">
                  <div
                    class="flex h-16 w-16 items-center justify-center rounded-2xl text-lg font-bold text-white"
                    style={{ background: `hsl(${away?.color})` }}
                  >
                    {away?.short}
                  </div>
                  <span class="font-semibold">{away?.name}</span>
                </A>
              </div>
            </Card>
          )
        })()}
      </Section>

      {/* Stats band */}
      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Equipos participantes" value={TEAMS.length} tone="primary" icon={<Users class="h-5 w-5" />} />
            <Stat label="Goles en la temporada" value={totalGoals()} tone="neutral" icon={<Trophy class="h-5 w-5" />} />
            <Stat label="Partidos jugados" value={matchesPlayed()} tone="primary" icon={<Calendar class="h-5 w-5" />} />
            <Stat label="Años de historia" value={2026 - Math.min(...TEAMS.map((t) => t.founded))} tone="neutral" icon={<Award class="h-5 w-5" />} />
          </div>
        </Section>
      </div>

      {/* News grid */}
      <Section>
        <div class="mb-10 text-center">
          <Badge tone="neutral" class="mb-4">
            <Newspaper class="h-3.5 w-3.5" /> Noticias
          </Badge>
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Lo último de la liga" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Fichajes, resultados y análisis de la Liga MX GolMX y la Copa GolMX.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={NEWS}>
            {(n) => (
              <Card glass tilt spotlight class="flex h-full flex-col p-6">
                <Badge tone={CATEGORY_TONE[n.category] ?? 'neutral'} class="mb-3 self-start">
                  {n.category}
                </Badge>
                <h3 class="text-lg font-semibold leading-snug">{n.title}</h3>
                <p class="mt-2 flex-1 text-sm text-muted-foreground">{n.summary}</p>
                <p class="mt-4 text-xs text-muted-foreground">{n.date}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>
    </>
  )
}
