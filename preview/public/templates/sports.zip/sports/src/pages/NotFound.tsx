import { Button, Section } from '@a4ui/core'
import { useNavigate } from '@solidjs/router'
import { Trophy } from 'lucide-solid'
import type { JSX } from 'solid-js'

export function NotFound(): JSX.Element {
  const navigate = useNavigate()

  return (
    <Section class="text-center">
      <Trophy class="mx-auto mb-4 h-10 w-10 text-primary" />
      <h1 class="text-3xl font-semibold tracking-tight">Fuera de lugar</h1>
      <p class="mx-auto mt-3 max-w-md text-muted-foreground">
        Esta jugada no existe. Regresa al inicio para seguir la acción de la Liga MX GolMX.
      </p>
      <Button ripple class="mt-6" onClick={() => navigate('/')}>
        Volver al inicio
      </Button>
    </Section>
  )
}
