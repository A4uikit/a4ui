import { Button, Section } from '@a4ui/core'
import { useNavigate } from '@solidjs/router'
import { RadioTower } from 'lucide-solid'
import type { JSX } from 'solid-js'

export function NotFound(): JSX.Element {
  const navigate = useNavigate()

  return (
    <Section class="text-center">
      <RadioTower class="mx-auto mb-4 h-10 w-10 text-primary" />
      <h1 class="text-3xl font-semibold tracking-tight">Fuera de señal</h1>
      <p class="mx-auto mt-3 max-w-md text-muted-foreground">
        No encontramos esta página. Regresa a la jornada en vivo para seguir el marcador.
      </p>
      <Button ripple class="mt-6" onClick={() => navigate('/')}>
        Volver al inicio
      </Button>
    </Section>
  )
}
