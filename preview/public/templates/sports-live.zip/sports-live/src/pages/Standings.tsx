import { Badge, Section, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow, TextReveal } from '@a4ui/core'
import { A } from '@solidjs/router'
import { ArrowDown, ArrowUp, Minus } from 'lucide-solid'
import { createMemo, For, type JSX } from 'solid-js'

import { BASE_RANK, matches, standings } from '../lib/sim'

export function Standings(): JSX.Element {
  const rows = createMemo(() => standings())

  function matchIdFor(teamId: string): string | undefined {
    return matches().find((m) => m.home.id === teamId || m.away.id === teamId)?.id
  }

  function movement(teamId: string, index: number): JSX.Element {
    const delta = BASE_RANK.indexOf(teamId) - index
    if (delta > 0) return <ArrowUp class="h-4 w-4 text-emerald-500" aria-label={`Sube ${delta} lugar(es)`} />
    if (delta < 0) return <ArrowDown class="h-4 w-4 text-destructive" aria-label={`Baja ${-delta} lugar(es)`} />
    return <Minus class="h-4 w-4 text-muted-foreground" aria-label="Sin cambio" />
  }

  return (
    <Section>
      <div class="mb-8 text-center">
        <Badge tone="danger" class="mb-4">
          Impacto en vivo
        </Badge>
        <h1 class="mx-auto max-w-2xl text-4xl font-semibold tracking-tight sm:text-5xl">
          <TextReveal text="Tabla de posiciones" />
        </h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Se recalcula con cada resultado en curso — así quedaría la tabla si los partidos terminaran ahora mismo.
        </p>
      </div>

      <Table>
        <TableHead>
          <TableRow>
            <TableHeadCell>#</TableHeadCell>
            <TableHeadCell>Equipo</TableHeadCell>
            <TableHeadCell>PJ</TableHeadCell>
            <TableHeadCell>G</TableHeadCell>
            <TableHeadCell>E</TableHeadCell>
            <TableHeadCell>P</TableHeadCell>
            <TableHeadCell>GF</TableHeadCell>
            <TableHeadCell>GC</TableHeadCell>
            <TableHeadCell>DG</TableHeadCell>
            <TableHeadCell>Pts</TableHeadCell>
          </TableRow>
        </TableHead>
        <TableBody>
          <For each={rows()}>
            {(row, i) => (
              <TableRow>
                <TableCell class="flex items-center gap-2 font-medium">
                  {movement(row.team.id, i())} {i() + 1}
                </TableCell>
                <TableCell>
                  <A
                    href={matchIdFor(row.team.id) ? `/partido/${matchIdFor(row.team.id)}` : '/'}
                    class="flex items-center gap-2 py-1 font-medium transition-colors hover:text-primary"
                  >
                    {row.team.name}
                    {row.live && (
                      <Badge tone="danger" pulse class="text-[10px]">
                        EN VIVO
                      </Badge>
                    )}
                  </A>
                </TableCell>
                <TableCell>{row.played}</TableCell>
                <TableCell>{row.won}</TableCell>
                <TableCell>{row.drawn}</TableCell>
                <TableCell>{row.lost}</TableCell>
                <TableCell>{row.gf}</TableCell>
                <TableCell>{row.ga}</TableCell>
                <TableCell>{row.gf - row.ga}</TableCell>
                <TableCell class="font-semibold text-primary">{row.pts}</TableCell>
              </TableRow>
            )}
          </For>
        </TableBody>
      </Table>
    </Section>
  )
}
