import { Badge, Button, Card, GradientText, Magnetic, Parallax, Section, TextReveal } from '@a4ui/core'
import { A, useNavigate } from '@solidjs/router'
import { ArrowRight, Goal, ListOrdered, Radio, Target } from 'lucide-solid'
import { For, type JSX } from 'solid-js'

import { clockLabel, liveMatchCount, type Match, matches, statusLabel } from '../lib/sim'

const FEATURES: { icon: JSX.Element; title: string; blurb: string }[] = [
  {
    icon: <Radio class="h-6 w-6" />,
    title: 'Marcador en tiempo real',
    blurb: 'El reloj y el resultado avanzan solos, partido a partido, como si estuvieras en el estadio.',
  },
  {
    icon: <Goal class="h-6 w-6" />,
    title: 'Minuto a minuto',
    blurb: 'Goles, tarjetas y remates aparecen en la bitácora del partido justo cuando ocurren.',
  },
  {
    icon: <ListOrdered class="h-6 w-6" />,
    title: 'Tabla que se mueve',
    blurb: 'La tabla de posiciones se recalcula con cada resultado en curso, sin recargar la página.',
  },
]

function statusTone(status: Match['status']): 'danger' | 'warning' | 'neutral' {
  if (status === 'live') return 'danger'
  if (status === 'ht') return 'warning'
  return 'neutral'
}

export function Home(): JSX.Element {
  const navigate = useNavigate()

  return (
    <>
      <div class="relative overflow-hidden">
        <Parallax amount={60} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.25), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.16), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-24 text-center">
          <Badge tone="danger" pulse class="mb-5">
            <Target class="h-3.5 w-3.5" /> {liveMatchCount()} partidos en vivo ahora
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            La jornada, <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">minuto a minuto</GradientText>
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Marcadores, comentarios y estadísticas en vivo de la jornada — sin refrescar, sin perderte nada.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => navigate('/tabla')}>
                Ver tabla de posiciones
              </Button>
            </Magnetic>
          </div>
        </Section>
      </div>

      <Section>
        <div class="mb-8 flex items-end justify-between">
          <div>
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Partidos en vivo" onView />
            </h2>
            <p class="mt-2 text-muted-foreground">Desliza para ver toda la jornada.</p>
          </div>
        </div>
        <div class="snap-strip -mx-5 flex gap-4 overflow-x-auto px-5 pb-4">
          <For each={matches()}>
            {(m) => (
              <A href={`/partido/${m.id}`} class="block w-72 shrink-0">
                <Card glass tilt spotlight class="h-full p-5">
                  <div class="mb-4 flex items-center justify-between">
                    <Badge tone={statusTone(m.status)} pulse={m.status === 'live'}>
                      {statusLabel(m.status)}
                    </Badge>
                    <span class="truncate text-xs text-muted-foreground">{m.venue}</span>
                  </div>
                  <div class="space-y-2.5">
                    <div class="flex items-center justify-between">
                      <span class="font-medium">{m.home.short}</span>
                      <span class="text-2xl font-bold tabular-nums">{m.homeScore}</span>
                    </div>
                    <div class="flex items-center justify-between">
                      <span class="font-medium">{m.away.short}</span>
                      <span class="text-2xl font-bold tabular-nums">{m.awayScore}</span>
                    </div>
                  </div>
                  <div class="mt-5 flex items-center justify-between text-sm">
                    <span class="text-muted-foreground">{clockLabel(m)}</span>
                    <span class="inline-flex items-center gap-1 font-medium text-primary">
                      Ver partido <ArrowRight class="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Card>
              </A>
            )}
          </For>
        </div>
      </Section>

      <div class="border-y border-border/60 bg-muted/30">
        <Section class="!py-14">
          <div class="grid gap-5 sm:grid-cols-3">
            <For each={FEATURES}>
              {(f) => (
                <Card glass class="p-6">
                  <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                    {f.icon}
                  </div>
                  <h3 class="text-lg font-semibold">{f.title}</h3>
                  <p class="mt-1 text-sm text-muted-foreground">{f.blurb}</p>
                </Card>
              )}
            </For>
          </div>
        </Section>
      </div>
    </>
  )
}
