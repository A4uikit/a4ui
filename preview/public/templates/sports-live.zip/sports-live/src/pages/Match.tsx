import {
  Badge,
  Button,
  Card,
  Meter,
  Progress,
  Section,
  Stat,
  TextReveal,
  Timeline,
  type TimelineItem,
  type TimelineTone,
} from '@a4ui/core'
import { A, useNavigate, useParams } from '@solidjs/router'
import { ArrowLeft, MapPin } from 'lucide-solid'
import { createMemo, type JSX, Show } from 'solid-js'

import { clockLabel, type EventType, matches, statusLabel } from '../lib/sim'

function eventTone(type: EventType): TimelineTone {
  if (type === 'goal') return 'success'
  if (type === 'red') return 'danger'
  if (type === 'yellow') return 'primary'
  return 'default'
}

function crest(short: string): JSX.Element {
  return (
    <div class="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xl font-bold text-primary">
      {short}
    </div>
  )
}

export function Match(): JSX.Element {
  const params = useParams<{ id: string }>()
  const navigate = useNavigate()

  const match = createMemo(() => matches().find((m) => m.id === params.id))

  const feed = createMemo<TimelineItem[]>(() => {
    const m = match()
    if (!m) return []
    return [...m.events]
      .reverse()
      .map((e) => ({ title: e.text, time: `${e.minute}'`, tone: eventTone(e.type) }))
  })

  return (
    <Show
      when={match()}
      fallback={
        <Section class="text-center">
          <h1 class="text-3xl font-semibold tracking-tight">Partido no encontrado</h1>
          <p class="mx-auto mt-3 max-w-md text-muted-foreground">Este partido no está en la jornada de hoy.</p>
          <Button ripple class="mt-6" onClick={() => navigate('/')}>
            Volver al inicio
          </Button>
        </Section>
      }
    >
      {(m) => (
        <>
          <Section class="!pb-8">
            <A
              href="/"
              class="inline-flex items-center gap-1.5 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft class="h-4 w-4" /> Todos los partidos
            </A>

            <h1 class="mt-4 text-2xl font-semibold tracking-tight sm:text-3xl">
              <TextReveal text={`${m().home.name} vs ${m().away.name}`} />
            </h1>

            <Card glass class="mt-6 p-6 sm:p-8">
              <div class="flex flex-wrap items-center justify-between gap-3">
                <Badge tone={m().status === 'live' ? 'danger' : m().status === 'ht' ? 'warning' : 'neutral'} pulse={m().status === 'live'}>
                  {statusLabel(m().status)}
                </Badge>
                <span class="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <MapPin class="h-3.5 w-3.5" /> {m().venue}
                </span>
              </div>

              <div class="mt-6 grid grid-cols-[1fr_auto_1fr] items-center gap-4 sm:gap-8">
                <div class="flex flex-col items-center gap-3 text-center">
                  {crest(m().home.short)}
                  <span class="font-medium">{m().home.name}</span>
                </div>

                <div class="flex flex-col items-center gap-2">
                  <div class="flex items-center gap-4">
                    <Stat label="Local" value={m().homeScore} tone="primary" class="text-center" />
                    <span class="text-3xl font-bold text-muted-foreground">–</span>
                    <Stat label="Visitante" value={m().awayScore} tone="primary" class="text-center" />
                  </div>
                  <span class="text-sm font-medium text-primary">{clockLabel(m())}</span>
                </div>

                <div class="flex flex-col items-center gap-3 text-center">
                  {crest(m().away.short)}
                  <span class="font-medium">{m().away.name}</span>
                </div>
              </div>
            </Card>
          </Section>

          <Section class="!pt-0">
            <div class="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
              <div>
                <h2 class="mb-4 text-2xl font-semibold tracking-tight">Minuto a minuto</h2>
                <Card glass class="p-6">
                  <Timeline items={feed()} />
                </Card>
              </div>

              <div>
                <h2 class="mb-4 text-2xl font-semibold tracking-tight">Estadísticas en vivo</h2>
                <Card glass class="space-y-5 p-6">
                  <Progress
                    value={m().homeStats.possession}
                    max={100}
                    label={`Posesión — ${m().home.short} ${m().homeStats.possession}% · ${m().away.short} ${m().awayStats.possession}%`}
                  />
                  <div class="grid grid-cols-2 gap-4">
                    <Meter value={m().homeStats.shots} max={20} label={`Remates ${m().home.short}`} />
                    <Meter value={m().awayStats.shots} max={20} label={`Remates ${m().away.short}`} />
                  </div>
                  <div class="grid grid-cols-2 gap-4">
                    <Meter value={m().homeStats.onTarget} max={12} label={`A puerta ${m().home.short}`} />
                    <Meter value={m().awayStats.onTarget} max={12} label={`A puerta ${m().away.short}`} />
                  </div>
                  <div class="grid grid-cols-2 gap-4">
                    <Meter value={m().homeStats.xg} max={4} label={`xG ${m().home.short}`} />
                    <Meter value={m().awayStats.xg} max={4} label={`xG ${m().away.short}`} />
                  </div>
                </Card>
              </div>
            </div>
          </Section>
        </>
      )}
    </Show>
  )
}
