import { motionReduced } from '@a4ui/core'
import { createSignal } from 'solid-js'

/** How often the simulator advances a live match by one matchday minute. */
const TICK_MS = 2200
/** Ticks a match sits in "medio tiempo" before kicking off the second half. */
const HALFTIME_TICKS = 3

export interface Team {
  id: string
  name: string
  short: string
}

export const TEAMS: Team[] = [
  { id: 'monterrey', name: 'Titanes de Monterrey', short: 'TIT' },
  { id: 'tijuana', name: 'Lobos de Tijuana', short: 'LOB' },
  { id: 'oaxaca', name: 'Águilas de Oaxaca', short: 'AGU' },
  { id: 'veracruz', name: 'Tiburones de Veracruz', short: 'TIB' },
  { id: 'puebla', name: 'Serpientes de Puebla', short: 'SER' },
  { id: 'merida', name: 'Jaguares de Mérida', short: 'JAG' },
  { id: 'guadalajara', name: 'Halcones de Guadalajara', short: 'HAL' },
  { id: 'leon', name: 'Toros de León', short: 'TOR' },
]

function team(id: string): Team {
  const t = TEAMS.find((x) => x.id === id)
  if (!t) throw new Error(`Unknown team id: ${id}`)
  return t
}

export type Side = 'home' | 'away'
export type MatchStatus = 'live' | 'ht' | 'ft'
export type EventType = 'goal' | 'yellow' | 'red' | 'chance' | 'kickoff' | 'ht' | 'ft'

export interface MatchEvent {
  id: string
  minute: number
  type: EventType
  side: Side | 'neutral'
  text: string
}

export interface TeamStats {
  possession: number
  shots: number
  onTarget: number
  xg: number
}

export interface Match {
  id: string
  venue: string
  home: Team
  away: Team
  homeScore: number
  awayScore: number
  minute: number
  status: MatchStatus
  htTicksLeft?: number
  events: MatchEvent[]
  homeStats: TeamStats
  awayStats: TeamStats
}

const PLAYERS = [
  'J. Hernández', 'C. Vela', 'A. Rodríguez', 'D. Torres', 'M. Reyes',
  'L. Gómez', 'R. Flores', 'E. Salazar', 'F. Navarro', 'O. Castillo',
  'S. Ibarra', 'P. Domínguez',
]

function randomPlayer(): string {
  return PLAYERS[Math.floor(Math.random() * PLAYERS.length)] as string
}

let eventSeq = 0
function mkEvent(minute: number, type: EventType, side: Side | 'neutral', text: string): MatchEvent {
  eventSeq += 1
  return { id: `ev-${eventSeq}`, minute, type, side, text }
}

function freshStats(): TeamStats {
  return { possession: 50, shots: 0, onTarget: 0, xg: 0 }
}

function initialMatches(): Match[] {
  const fixtures: { id: string; home: string; away: string; venue: string }[] = [
    { id: 'mty-tij', home: 'monterrey', away: 'tijuana', venue: 'Estadio del Norte' },
    { id: 'oax-ver', home: 'oaxaca', away: 'veracruz', venue: 'Arena Pacífico' },
    { id: 'pue-mer', home: 'puebla', away: 'merida', venue: 'Coliseo Central' },
    { id: 'gdl-leo', home: 'guadalajara', away: 'leon', venue: 'Estadio Halcón' },
  ]
  return fixtures.map((f) => ({
    id: f.id,
    venue: f.venue,
    home: team(f.home),
    away: team(f.away),
    homeScore: 0,
    awayScore: 0,
    minute: 1,
    status: 'live',
    events: [mkEvent(0, 'kickoff', 'neutral', 'Arranca el partido')],
    homeStats: freshStats(),
    awayStats: freshStats(),
  }))
}

const [matches, setMatches] = createSignal<Match[]>(initialMatches())
export { matches }

function bump(stats: TeamStats, kind: 'chance' | 'onTarget' | 'goal'): TeamStats {
  if (kind === 'chance') return { ...stats, shots: stats.shots + 1, xg: Math.round((stats.xg + 0.08) * 100) / 100 }
  if (kind === 'onTarget') return { ...stats, shots: stats.shots + 1, onTarget: stats.onTarget + 1, xg: Math.round((stats.xg + 0.15) * 100) / 100 }
  return { ...stats, shots: stats.shots + 1, onTarget: stats.onTarget + 1, xg: Math.round((stats.xg + 0.32) * 100) / 100 }
}

function driftPossession(m: Match): { homeStats: TeamStats; awayStats: TeamStats } {
  const delta = Math.random() * 6 - 3
  const home = Math.min(68, Math.max(32, Math.round(m.homeStats.possession + delta)))
  return {
    homeStats: { ...m.homeStats, possession: home },
    awayStats: { ...m.awayStats, possession: 100 - home },
  }
}

function advance(m: Match): Match {
  if (m.status === 'ft') return m

  if (m.status === 'ht') {
    const left = (m.htTicksLeft ?? 0) - 1
    if (left <= 0) return { ...m, status: 'live', htTicksLeft: undefined, minute: 46 }
    return { ...m, htTicksLeft: left }
  }

  const minute = m.minute + 1

  if (minute >= 90) {
    return {
      ...m,
      minute: 90,
      status: 'ft',
      events: [...m.events, mkEvent(90, 'ft', 'neutral', 'Final del partido')],
    }
  }

  if (minute === 45) {
    return {
      ...m,
      minute: 45,
      status: 'ht',
      htTicksLeft: HALFTIME_TICKS,
      events: [...m.events, mkEvent(45, 'ht', 'neutral', 'Termina el primer tiempo')],
    }
  }

  const { homeStats, awayStats } = driftPossession(m)
  let events = m.events
  let homeScore = m.homeScore
  let awayScore = m.awayScore
  let nextHomeStats = homeStats
  let nextAwayStats = awayStats

  const roll = Math.random()
  const side: Side = Math.random() < 0.5 ? 'home' : 'away'
  const squad = side === 'home' ? m.home : m.away

  if (roll < 0.045) {
    if (side === 'home') homeScore += 1
    else awayScore += 1
    const scorer = randomPlayer()
    events = [...events, mkEvent(minute, 'goal', side, `¡Gol de ${squad.short}! Anota ${scorer}.`)]
    if (side === 'home') nextHomeStats = bump(homeStats, 'goal')
    else nextAwayStats = bump(awayStats, 'goal')
  } else if (roll < 0.08) {
    const player = randomPlayer()
    events = [...events, mkEvent(minute, 'yellow', side, `Tarjeta amarilla para ${player} (${squad.short}).`)]
  } else if (roll < 0.085) {
    const player = randomPlayer()
    events = [...events, mkEvent(minute, 'red', side, `¡Tarjeta roja! ${player} (${squad.short}) se va expulsado.`)]
  } else if (roll < 0.22) {
    const onTarget = Math.random() < 0.45
    const text = onTarget
      ? `Remate de ${squad.short} que ataja el portero.`
      : `Remate de ${squad.short} que se va desviado.`
    events = [...events, mkEvent(minute, 'chance', side, text)]
    if (side === 'home') nextHomeStats = bump(homeStats, onTarget ? 'onTarget' : 'chance')
    else nextAwayStats = bump(awayStats, onTarget ? 'onTarget' : 'chance')
  }

  return {
    ...m,
    minute,
    homeScore,
    awayScore,
    events,
    homeStats: nextHomeStats,
    awayStats: nextAwayStats,
  }
}

/**
 * Starts the global match-state ticker (clock, score, events, live stats).
 * Call once (e.g. from the app root's `onMount`). Skips mutating state on
 * ticks where the user prefers reduced motion, so the whole live feel pauses
 * — clock, score, and feed all freeze — rather than just the animations.
 * Returns a stop function for `onCleanup`.
 */
export function startSimulator(): () => void {
  const interval = setInterval(() => {
    if (motionReduced()) return
    setMatches((ms) => ms.map(advance))
  }, TICK_MS)
  return () => clearInterval(interval)
}

export function liveMatchCount(): number {
  return matches().filter((m) => m.status !== 'ft').length
}

export function statusLabel(status: MatchStatus): string {
  if (status === 'live') return 'EN VIVO'
  if (status === 'ht') return 'MEDIO TIEMPO'
  return 'FINAL'
}

export function clockLabel(m: Match): string {
  if (m.status === 'ht') return 'Descanso'
  if (m.status === 'ft') return 'Final'
  return `${m.minute}'`
}

// --- Standings ------------------------------------------------------------

interface SeasonRecord {
  played: number
  won: number
  drawn: number
  lost: number
  gf: number
  ga: number
}

const BASE_SEASON: Record<string, SeasonRecord> = {
  monterrey: { played: 14, won: 9, drawn: 3, lost: 2, gf: 27, ga: 14 },
  guadalajara: { played: 14, won: 8, drawn: 4, lost: 2, gf: 24, ga: 13 },
  oaxaca: { played: 14, won: 7, drawn: 4, lost: 3, gf: 22, ga: 15 },
  tijuana: { played: 14, won: 7, drawn: 3, lost: 4, gf: 20, ga: 16 },
  merida: { played: 14, won: 6, drawn: 5, lost: 3, gf: 19, ga: 17 },
  leon: { played: 14, won: 6, drawn: 3, lost: 5, gf: 18, ga: 18 },
  veracruz: { played: 14, won: 5, drawn: 4, lost: 5, gf: 17, ga: 19 },
  puebla: { played: 14, won: 4, drawn: 3, lost: 7, gf: 14, ga: 22 },
}

function basePts(id: string): number {
  const r = BASE_SEASON[id]
  if (!r) throw new Error(`No base record for team ${id}`)
  return r.won * 3 + r.drawn
}

/** Team ids ranked by pre-matchday points — the reference order used to show live table movement. */
export const BASE_RANK: string[] = [...TEAMS].sort((a, b) => basePts(b.id) - basePts(a.id)).map((t) => t.id)

export interface StandingsRow {
  team: Team
  played: number
  won: number
  drawn: number
  lost: number
  gf: number
  ga: number
  pts: number
  live: boolean
}

/**
 * Current table, projecting every live/finished match of the day onto the
 * pre-matchday season record — recomputes reactively as `matches()` ticks.
 */
export function standings(): StandingsRow[] {
  const ms = matches()
  const rows = TEAMS.map((t) => {
    const base = BASE_SEASON[t.id]
    if (!base) throw new Error(`No base record for team ${t.id}`)
    const match = ms.find((m) => m.home.id === t.id || m.away.id === t.id)

    let { played, won, drawn, lost, gf, ga } = base
    let live = false

    if (match) {
      live = match.status !== 'ft'
      const isHome = match.home.id === t.id
      const gfAdd = isHome ? match.homeScore : match.awayScore
      const gaAdd = isHome ? match.awayScore : match.homeScore
      played += 1
      gf += gfAdd
      ga += gaAdd
      if (gfAdd > gaAdd) won += 1
      else if (gfAdd === gaAdd) drawn += 1
      else lost += 1
    }

    return { team: t, played, won, drawn, lost, gf, ga, pts: won * 3 + drawn, live }
  })

  return rows.sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga) || b.gf - a.gf)
}
