import { Badge, ScrollProgress } from '@a4ui/core'
import { A, Route, Router } from '@solidjs/router'
import { RadioTower } from 'lucide-solid'
import { For, onCleanup, onMount, type JSX } from 'solid-js'

import { liveMatchCount, startSimulator } from './lib/sim'
import { Home } from './pages/Home'
import { Match } from './pages/Match'
import { NotFound } from './pages/NotFound'
import { Standings } from './pages/Standings'

const NAV = [
  { href: '/', label: 'Inicio' },
  { href: '/tabla', label: 'Tabla' },
]

function Layout(props: { children?: JSX.Element }): JSX.Element {
  onMount(() => {
    const stop = startSimulator()
    onCleanup(stop)
  })

  return (
    <div class="min-h-screen bg-background text-foreground">
      <ScrollProgress height={3} />
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <A href="/" class="flex items-center gap-2 py-1 font-semibold tracking-tight">
            <RadioTower class="h-5 w-5 text-primary" /> En Vivo MX
          </A>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>
              {(n) => (
                <A
                  href={n.href}
                  class="inline-flex items-center py-2 transition-colors hover:text-foreground"
                  activeClass="text-foreground"
                  end={n.href === '/'}
                >
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <div class="flex items-center gap-3">
            <Badge tone="danger" pulse>
              EN VIVO
            </Badge>
            <span class="hidden text-sm text-muted-foreground sm:inline">{liveMatchCount()} partidos ahora</span>
          </div>
        </div>
      </header>

      {props.children}

      <footer class="border-t border-border/60">
        <div class="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <span class="flex items-center gap-2">
            <RadioTower class="h-4 w-4 text-primary" /> En Vivo MX · Marcadores y comentarios en tiempo real
          </span>
          <nav class="flex items-center gap-5">
            <For each={NAV}>
              {(n) => (
                <A href={n.href} class="inline-flex items-center py-2 transition-colors hover:text-foreground">
                  {n.label}
                </A>
              )}
            </For>
          </nav>
          <span>© 2026 En Vivo MX. Hecho con A4ui.</span>
        </div>
      </footer>
    </div>
  )
}

export function App(): JSX.Element {
  return (
    <Router root={Layout}>
      <Route path="/" component={Home} />
      <Route path="/partido/:id" component={Match} />
      <Route path="/tabla" component={Standings} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}
