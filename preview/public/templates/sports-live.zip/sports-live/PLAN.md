# Template: `sports-live` — Live scores & commentary

The realtime cousin of `sports`: a live-match experience. Goal: make the page
_feel_ live — pulsing indicators, count-up stats, a minute-by-minute feed.
Showcases the Motion side of A4ui.

## Sections

1. **Top bar** — "LIVE" `Badge pulse`, match count.
2. **Live matches strip** — horizontally scrollable cards, each with `Badge pulse` "LIVE", score, clock.
3. **Match detail** — big live scoreboard (`Stat` count-up), team crests, current minute.
4. **Minute-by-minute feed** — goals/cards/subs as they happen. (`Timeline`, `List stagger`, `NotificationStack`)
5. **Live stats** — possession, shots, xG — animated meters/bars. (`Meter`, `Progress`, `BarChart`)
6. **Standings impact** — how the live result shifts the table. (`Table`)
7. **Footer**

## Simulated realtime

No backend — a small simulator ticks match state (clock, score, events) on an
interval to drive the live feel. Respects reduced motion (no pulsing/count-up).

## Custom theme

Dark, high-contrast, live-red accent for `LIVE` states.

## Tasks (→ issues)

- [ ] Scaffold app
- [ ] `sports-live` dark/live theme tokens
- [ ] Match state simulator (clock/score/events on interval)
- [ ] Top bar + live badge
- [ ] Live matches strip
- [ ] Match detail scoreboard (count-up)
- [ ] Minute-by-minute feed (timeline + stagger)
- [ ] Live stats (meters/bars)
- [ ] Standings impact table
- [ ] Reduced-motion pass + responsive + deploy
