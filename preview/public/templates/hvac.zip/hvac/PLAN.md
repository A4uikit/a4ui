# Template: `hvac` — Air conditioning install, repair & maintenance

A single-page marketing + lead-gen site for an HVAC company (air conditioning
install, repair, maintenance). Goal: a visitor confirms the company serves
their area, sees maintenance plans, and requests service — with emergency
contact always visible.

## Sections

1. **Top bar / nav** — logo, sticky anchor nav (Services, Coverage Area, Plans, Testimonials, FAQ, Contact), persistent "24/7 Emergency" phone CTA. (`AppShell` top bar, `Anchor`, `Button` ripple, `BackToTop`)
2. **Hero** — headline, subcopy, primary CTA "Request service", secondary "Call now — 24/7". Glass `Card` over a themed backdrop. (`TextReveal` headline, `GradientText` accent, `Button` ripple)
3. **About / trust signals** — years in business, technicians certified, units serviced, licensed & insured badges. (`Stat` count-up, `Card` glass)
4. **Services grid** — installation, repair, maintenance/tune-up, emergency service, duct cleaning, thermostat/smart-home, indoor air quality. (`Card` tilt/spotlight, lucide icons)
5. **Coverage area** — list/map placeholder of served cities/zip codes, response-time note. (`Descriptions`, `Card`, map placeholder)
6. **How it works** — 4 steps (call/request → diagnose → quote → fix). (`Stepper` or `Timeline`)
7. **Maintenance plans / pricing** — 3 tiers (basic tune-up, seasonal plan, premium/priority plan) with what's included. (`Card`, `PriceTag`, `Badge` "Most popular")
8. **Testimonials** — rotating customer quotes + ratings. (`Carousel` swipe, `Rating`, `Avatar`)
9. **FAQ** — collapsible questions (financing, warranty, response time, brands serviced). (`Accordion` animated height)
10. **Request-service form** — service type select, unit type, address/zip, preferred date/time, urgency (emergency toggle), name, phone, notes. (`Form`, `Select`, `Switch` for emergency, `DateField`, `Input`, `Button` ripple, `Toast` on submit)
11. **Contact** — 24/7 emergency phone (always visible), office hours, address, map placeholder, email, social links. (`Descriptions`, `Card` glass, `Alert` for emergency line)
12. **Footer** — nav, contact, socials, legal, license number.

## Structure

Single-page (long scroll + sticky anchor nav).

## Custom theme

Cool, reliable, technical mood: HVAC-blue primary (evokes cool air), safety-orange
accent for emergency CTAs, cooler neutral background, moderate radius.
Override `--primary`, `--accent`, `--background`, `--radius-*` tokens; verify
WCAG AA contrast in both light and dark (the emergency-orange CTA must stay
legible on both).

## Animation / parallax

- `Parallax` — hero backdrop and coverage-area map section depth on scroll.
- `ScrollProgress` — thin scroll progress bar in the sticky nav.
- `TextReveal` / `FillText` — section-title reveals on scroll.
- `GradientText` — hero headline accent ("24/7 Emergency").
- `Card` tilt/spotlight on service and pricing cards; `Magnetic` on the "Request service" and "Call now" CTAs.
- `Curtain` transition between Services and Coverage Area sections.
- `Stat` count-up for years/technicians/units-serviced trust numbers.
- `MultiStateBadge` or pulse `Badge` on the "24/7 Emergency" indicator.
- All motion respects `prefers-reduced-motion`.

## Reusable candidates

A coverage-area block (served-cities list/badges + map placeholder + response-time
note) is generic across any local-service vertical (HVAC, towing, plumbing) —
worth proposing as an `A4uikit/a4ui` component (e.g. `CoverageArea`). The
maintenance-plan pricing tier with an "included visits" list is also close
enough to the generic pricing `Card` to fold into a shared `PlanCard`.

## Tasks (→ issues)

- [ ] Scaffold app (Vite + Solid + Tailwind + a4ui preset)
- [ ] Custom `hvac` theme tokens
- [ ] Nav + hero
- [ ] About / trust stats
- [ ] Services grid
- [ ] Coverage area
- [ ] How it works steps
- [ ] Maintenance plans / pricing
- [ ] Testimonials carousel
- [ ] FAQ accordion
- [ ] Request-service form (with validation)
- [ ] Contact section (24/7 emergency) + footer
- [ ] Responsive pass (mobile) + deploy to Cloudflare Pages
