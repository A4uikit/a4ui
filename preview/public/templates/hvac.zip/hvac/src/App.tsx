import {
  Accordion,
  ActionBar,
  Aurora,
  Badge,
  Button,
  Card,
  Carousel,
  GradientText,
  Input,
  Magnetic,
  Parallax,
  PricingTable,
  Rating,
  ScrollProgress,
  Section,
  Select,
  Stat,
  Switch,
  Textarea,
  TextReveal,
} from '@a4ui/core'
import {
  AtSign,
  Award,
  BadgeCheck,
  Clock,
  Fan,
  Gauge,
  Home,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  PhoneCall,
  ShieldCheck,
  Snowflake,
  Thermometer,
  Timer,
  Wind,
  Wrench,
} from 'lucide-solid'
import { createSignal, For, type JSX } from 'solid-js'

const PHONE = '+52 55 8877 6655'
const PHONE_HREF = 'tel:+525588776655'

const NAV = [
  { href: '#services', label: 'Servicios' },
  { href: '#coverage', label: 'Zona de cobertura' },
  { href: '#plans', label: 'Planes' },
  { href: '#reviews', label: 'Reseñas' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contact', label: 'Contacto' },
]

const SERVICES: { icon: JSX.Element; title: string; blurb: string }[] = [
  { icon: <Snowflake class="h-6 w-6" />, title: 'Instalación', blurb: 'Equipos nuevos split, mini-split y centrales, dimensionados a tu espacio.' },
  { icon: <Wrench class="h-6 w-6" />, title: 'Reparación', blurb: 'Diagnóstico rápido y refacciones originales para cualquier marca.' },
  { icon: <Gauge class="h-6 w-6" />, title: 'Mantenimiento / afinación', blurb: 'Limpieza de filtros, revisión de gas y rendimiento óptimo.' },
  { icon: <PhoneCall class="h-6 w-6" />, title: 'Servicio de emergencia', blurb: 'Atención 24/7 cuando tu equipo falla en el peor momento.' },
  { icon: <Wind class="h-6 w-6" />, title: 'Limpieza de ductos', blurb: 'Eliminamos polvo, alérgenos y malos olores del sistema.' },
  { icon: <Thermometer class="h-6 w-6" />, title: 'Termostatos inteligentes', blurb: 'Instalación y configuración de control climático smart-home.' },
  { icon: <Fan class="h-6 w-6" />, title: 'Calidad del aire interior', blurb: 'Filtración avanzada y purificación para un ambiente más sano.' },
]

const COVERAGE_CITIES = [
  'CDMX — Benito Juárez',
  'CDMX — Coyoacán',
  'CDMX — Álvaro Obregón',
  'Naucalpan',
  'Tlalnepantla',
  'Interlomas',
  'Santa Fe',
  'Ciudad Satélite',
]

const STEPS = [
  { icon: <PhoneCall class="h-5 w-5" />, title: 'Llama o solicita', blurb: 'Cuéntanos qué pasa por teléfono o el formulario.' },
  { icon: <Gauge class="h-5 w-5" />, title: 'Diagnóstico', blurb: 'Un técnico certificado revisa tu equipo en sitio.' },
  { icon: <BadgeCheck class="h-5 w-5" />, title: 'Cotización clara', blurb: 'Te damos el costo antes de tocar una tuerca.' },
  { icon: <Wrench class="h-5 w-5" />, title: 'Reparamos', blurb: 'Trabajo garantizado, equipo funcionando el mismo día.' },
]

const PLANS: {
  name: string
  price: string
  highlighted?: boolean
  features: string[]
  cta: { label: string; onClick: () => void }
}[] = [
  {
    name: 'Básico',
    price: '$799 / visita',
    features: ['1 afinación anual', 'Revisión de filtros', 'Chequeo de gas refrigerante', 'Reporte de estado'],
    cta: { label: 'Elegir plan', onClick: () => (location.hash = '#request') },
  },
  {
    name: 'Temporada',
    price: '$1,499 / año',
    highlighted: true,
    features: ['2 afinaciones al año', 'Limpieza de ductos incluida', 'Descuento 15% en refacciones', 'Prioridad en agenda'],
    cta: { label: 'Elegir plan', onClick: () => (location.hash = '#request') },
  },
  {
    name: 'Premium',
    price: '$2,399 / año',
    features: ['4 visitas al año', 'Atención de emergencia sin costo de visita', 'Descuento 25% en refacciones', 'Línea directa 24/7'],
    cta: { label: 'Elegir plan', onClick: () => (location.hash = '#request') },
  },
]

const REVIEWS = [
  { name: 'Roberto C.', quote: 'Llegaron en 40 minutos un domingo con 38°C afuera. Salvaron la semana.', rating: 5 },
  { name: 'Lupita H.', quote: 'El plan de temporada me ahorró una reparación mayor. Muy profesionales.', rating: 5 },
  { name: 'Iván S.', quote: 'Instalaron mi mini-split en un día y quedó impecable.', rating: 5 },
]

const FAQ = [
  { value: 'q1', title: '¿Ofrecen financiamiento?', content: 'Sí, contamos con planes a meses sin intereses para instalaciones nuevas y reparaciones mayores. Pregunta al solicitar tu servicio.' },
  { value: 'q2', title: '¿Qué garantía tienen las reparaciones?', content: 'Toda mano de obra tiene 90 días de garantía y las refacciones nuevas cuentan con garantía de fábrica.' },
  { value: 'q3', title: '¿Cuál es el tiempo de respuesta?', content: 'Para emergencias, en promedio llegamos en 45–60 minutos dentro de nuestra zona de cobertura, las 24 horas.' },
  { value: 'q4', title: '¿Con qué marcas trabajan?', content: 'Damos servicio a todas las marcas: Mirage, Carrier, Trane, LG, Samsung, York y más.' },
]

const SERVICE_TYPES = [
  { value: 'install', label: 'Instalación nueva' },
  { value: 'repair', label: 'Reparación' },
  { value: 'maintenance', label: 'Mantenimiento / afinación' },
  { value: 'ducts', label: 'Limpieza de ductos' },
  { value: 'thermostat', label: 'Termostato inteligente' },
  { value: 'air-quality', label: 'Calidad del aire' },
]

const UNIT_TYPES = [
  { value: 'split', label: 'Split / minisplit' },
  { value: 'central', label: 'Central' },
  { value: 'window', label: 'Ventana' },
  { value: 'other', label: 'No estoy seguro' },
]

export function App(): JSX.Element {
  const [serviceType, setServiceType] = createSignal('repair')
  const [unitType, setUnitType] = createSignal('split')
  const [address, setAddress] = createSignal('')
  const [preferredDate, setPreferredDate] = createSignal('')
  const [emergency, setEmergency] = createSignal(false)
  const [name, setName] = createSignal('')
  const [phone, setPhone] = createSignal('')
  const [notes, setNotes] = createSignal('')
  const [sent, setSent] = createSignal(false)

  const [cName, setCName] = createSignal('')
  const [cContact, setCContact] = createSignal('')
  const [cMessage, setCMessage] = createSignal('')
  const [cSent, setCSent] = createSignal(false)

  const submitRequest = (e: Event): void => {
    e.preventDefault()
    setSent(true)
  }

  const submitContact = (e: Event): void => {
    e.preventDefault()
    setCSent(true)
  }

  return (
    <div class="relative min-h-screen text-foreground">
      <ScrollProgress />

      <Aurora />

      {/* Emergency strip */}
      <ActionBar
        sticky={false}
        status={
          <span class="inline-flex items-center gap-1.5 text-sm font-medium">
            <PhoneCall class="h-4 w-4" /> Emergencia 24/7
          </span>
        }
        message="No dejes que el calor gane."
        action={{ label: `Llama ahora: ${PHONE}`, href: PHONE_HREF }}
      />

      {/* Nav */}
      <header class="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" class="flex items-center gap-2 font-semibold tracking-tight">
            <Snowflake class="h-5 w-5 text-primary" /> AirePro
          </a>
          <nav class="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
          </nav>
          <div class="flex items-center gap-2">
            <a href={PHONE_HREF} class="hidden text-sm font-medium text-primary sm:inline-flex sm:items-center sm:gap-1">
              <Phone class="h-4 w-4" /> {PHONE}
            </a>
            <Button ripple onClick={() => (location.hash = '#request')}>
              Solicitar servicio
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div id="top" class="relative overflow-hidden">
        <Parallax amount={40} class="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div
            class="h-full w-full"
            style={{
              background:
                'radial-gradient(60% 50% at 50% 0%, hsl(var(--primary) / 0.18), transparent 70%), radial-gradient(40% 40% at 80% 20%, hsl(var(--accent) / 0.16), transparent 70%)',
            }}
          />
        </Parallax>
        <Section class="!py-28 text-center">
          <Badge tone="info" pulse class="mb-5">
            <PhoneCall class="h-3.5 w-3.5" /> Emergencia 24/7 disponible
          </Badge>
          <h1 class="mx-auto max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Aire acondicionado que <GradientText from="hsl(var(--primary))" to="hsl(var(--accent))">funciona</GradientText>, cuando lo necesitas
          </h1>
          <p class="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
            Instalación, reparación y mantenimiento con técnicos certificados. Licenciados, asegurados y listos las 24 horas.
          </p>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Magnetic strength={14}>
              <Button ripple onClick={() => (location.hash = '#request')}>
                Solicitar servicio
              </Button>
            </Magnetic>
            <Button variant="outline" onClick={() => (window.location.href = PHONE_HREF)}>
              <Phone class="h-4 w-4" /> Llamar ahora — 24/7
            </Button>
          </div>
        </Section>
      </div>

      {/* About / trust stats */}
      <div id="about" class="border-y border-border/60 bg-muted/30">
        <Section py="md">
          <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Años en el negocio" value={17} tone="primary" />
            <Stat label="Técnicos certificados" value={24} tone="primary" />
            <Stat label="Equipos atendidos" value={9800} format={(n) => `${Math.round(n / 100) / 10}k+`} tone="primary" />
            <Stat label="Reseñas 5 estrellas" value={1250} format={(n) => `${Math.round(n)}+`} tone="neutral" />
          </div>
          <div class="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Badge tone="success">
              <ShieldCheck class="h-3.5 w-3.5" /> Licenciados y asegurados
            </Badge>
            <Badge tone="info">
              <Award class="h-3.5 w-3.5" /> Técnicos certificados EPA
            </Badge>
            <Badge tone="neutral">
              <Clock class="h-3.5 w-3.5" /> Respuesta en 45–60 min
            </Badge>
          </div>
        </Section>
      </div>

      {/* Services */}
      <Section id="services">
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">
            <TextReveal text="Servicios" onView />
          </h2>
          <p class="mt-2 text-muted-foreground">Todo lo que tu sistema de climatización necesita, en un solo lugar.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <For each={SERVICES}>
            {(s) => (
              <Card glass tilt spotlight class="p-6">
                <div class="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                  {s.icon}
                </div>
                <h3 class="text-lg font-semibold">{s.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{s.blurb}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Coverage area */}
      <div id="coverage" class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">Zona de cobertura</h2>
              <p class="mt-2 text-muted-foreground">
                Damos servicio en toda la zona metropolitana con tiempos de respuesta rápidos.
              </p>
              <div class="mt-6 flex flex-wrap gap-2">
                <For each={COVERAGE_CITIES}>
                  {(city) => (
                    <Badge tone="neutral" class="py-1">
                      <MapPin class="h-3 w-3" /> {city}
                    </Badge>
                  )}
                </For>
              </div>
              <p class="mt-6 flex items-center gap-2 text-sm font-medium text-primary">
                <Timer class="h-4 w-4" /> Tiempo de respuesta promedio: 45–60 minutos en emergencias.
              </p>
            </div>
            <Parallax amount={20}>
              <Card glass class="flex h-64 items-center justify-center overflow-hidden p-0 sm:h-80">
                <div class="flex flex-col items-center gap-2 text-muted-foreground">
                  <MapPin class="h-10 w-10 text-primary" />
                  <span class="text-sm">Mapa de cobertura</span>
                </div>
              </Card>
            </Parallax>
          </div>
        </Section>
      </div>

      {/* How it works */}
      <Section>
        <div class="mb-10 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Cómo funciona</h2>
          <p class="mt-2 text-muted-foreground">De la llamada al equipo funcionando, sin sorpresas.</p>
        </div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <For each={STEPS}>
            {(step, i) => (
              <Card glass class="p-6">
                <div class="mb-4 flex items-center gap-2">
                  <span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
                    {i() + 1}
                  </span>
                  <span class="text-primary">{step.icon}</span>
                </div>
                <h3 class="font-semibold">{step.title}</h3>
                <p class="mt-1 text-sm text-muted-foreground">{step.blurb}</p>
              </Card>
            )}
          </For>
        </div>
      </Section>

      {/* Maintenance plans */}
      <div id="plans" class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">
              <TextReveal text="Planes de mantenimiento" onView />
            </h2>
            <p class="mt-2 text-muted-foreground">Evita fallas y extiende la vida de tu equipo.</p>
          </div>
          <PricingTable tiers={PLANS} />
        </Section>
      </div>

      {/* Reviews */}
      <Section id="reviews">
        <div class="mb-8 text-center">
          <h2 class="text-3xl font-semibold tracking-tight">Lo que dicen nuestros clientes</h2>
        </div>
        <div class="mx-auto max-w-2xl">
          <Carousel
            autoplayMs={5000}
            swipe
            slides={REVIEWS.map((r) => (
              <div class="px-2">
                <Card glass class="p-8 text-center">
                  <Rating value={r.rating} readonly max={5} class="mx-auto mb-4 justify-center" />
                  <p class="text-lg">&ldquo;{r.quote}&rdquo;</p>
                  <p class="mt-4 text-sm font-medium text-muted-foreground">— {r.name}</p>
                </Card>
              </div>
            ))}
          />
        </div>
      </Section>

      {/* FAQ */}
      <Section id="faq" class="!py-16">
        <div class="mx-auto max-w-2xl">
          <h2 class="mb-6 text-center text-3xl font-semibold tracking-tight">
            <TextReveal text="Preguntas frecuentes" onView />
          </h2>
          <Accordion items={FAQ} />
        </div>
      </Section>

      {/* Request-service form */}
      <div id="request" class="border-y border-border/60 bg-muted/30">
        <Section>
          <div class="mb-10 text-center">
            <h2 class="text-3xl font-semibold tracking-tight">Solicita tu servicio</h2>
            <p class="mt-2 text-muted-foreground">Cuéntanos qué necesitas y te contactamos para confirmar horario.</p>
          </div>
          <Card glass class="mx-auto max-w-2xl p-6 sm:p-8">
            {sent() ? (
              <div class="flex flex-col items-center justify-center py-10 text-center">
                <Badge tone="success" pulse class="mb-3">
                  Enviado
                </Badge>
                <p class="text-lg font-medium">¡Gracias, {name() || 'ya estamos en camino'}!</p>
                <p class="mt-1 text-sm text-muted-foreground">
                  {emergency()
                    ? 'Marcamos tu solicitud como emergencia — te contactamos de inmediato.'
                    : 'Te contactamos en breve para confirmar tu cita.'}
                </p>
              </div>
            ) : (
              <form class="space-y-4" onSubmit={submitRequest}>
                <div class="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label for="service-type" class="mb-1 block text-sm font-medium">Tipo de servicio</label>
                    <Select id="service-type" value={serviceType()} onChange={setServiceType}>
                      <For each={SERVICE_TYPES}>{(t) => <option value={t.value}>{t.label}</option>}</For>
                    </Select>
                  </div>
                  <div>
                    <label for="unit-type" class="mb-1 block text-sm font-medium">Tipo de equipo</label>
                    <Select id="unit-type" value={unitType()} onChange={setUnitType}>
                      <For each={UNIT_TYPES}>{(t) => <option value={t.value}>{t.label}</option>}</For>
                    </Select>
                  </div>
                </div>
                <div>
                  <label for="address" class="mb-1 block text-sm font-medium">Dirección o código postal</label>
                  <Input id="address" value={address()} onInput={setAddress} placeholder="Calle, colonia o C.P." required />
                </div>
                <div class="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label for="preferred-date" class="mb-1 block text-sm font-medium">Fecha preferida</label>
                    <Input id="preferred-date" value={preferredDate()} onInput={setPreferredDate} type="date" />
                  </div>
                  <div class="flex items-end">
                    <Switch
                      checked={emergency()}
                      onChange={setEmergency}
                      label="Es una emergencia"
                      class={emergency() ? 'text-primary' : ''}
                    />
                  </div>
                </div>
                <div class="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label for="name" class="mb-1 block text-sm font-medium">Nombre</label>
                    <Input id="name" value={name()} onInput={setName} placeholder="Tu nombre" required />
                  </div>
                  <div>
                    <label for="phone" class="mb-1 block text-sm font-medium">Teléfono</label>
                    <Input id="phone" value={phone()} onInput={setPhone} placeholder="55 0000 0000" type="tel" required />
                  </div>
                </div>
                <div>
                  <label for="notes" class="mb-1 block text-sm font-medium">Notas adicionales</label>
                  <Textarea id="notes" value={notes()} onInput={setNotes} placeholder="Cuéntanos qué está pasando con tu equipo…" rows={4} />
                </div>
                {emergency() && (
                  <div class="flex items-center gap-2 rounded-md bg-primary/10 px-3 py-2 text-sm text-primary">
                    <PhoneCall class="h-4 w-4" /> Para emergencias, también puedes llamar directo al {PHONE}.
                  </div>
                )}
                <Button ripple type="submit" class="w-full">
                  {emergency() ? 'Solicitar atención de emergencia' : 'Solicitar servicio'}
                </Button>
              </form>
            )}
          </Card>
        </Section>
      </div>

      {/* Contact */}
      <div id="contact">
        <Section>
          <div class="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 class="text-3xl font-semibold tracking-tight">Contacto</h2>
              <p class="mt-2 text-muted-foreground">Estamos disponibles todos los días del año, a cualquier hora.</p>

              <div class="mt-6 flex items-center gap-3 rounded-lg bg-primary/10 px-4 py-3 text-primary">
                <PhoneCall class="h-5 w-5 shrink-0" />
                <div class="text-sm">
                  <p class="font-semibold">Línea de emergencia 24/7</p>
                  <a href={PHONE_HREF} class="hover:underline">{PHONE}</a>
                </div>
              </div>

              <ul class="mt-8 space-y-4 text-sm">
                <li class="flex items-center gap-3"><Mail class="h-5 w-5 text-primary" /> contacto@airepro.mx</li>
                <li class="flex items-center gap-3"><MapPin class="h-5 w-5 text-primary" /> Av. Insurgentes Sur 2100, CDMX</li>
                <li class="flex items-center gap-3"><Clock class="h-5 w-5 text-primary" /> Oficina: Lun–Sáb · 8:00–19:00 · Emergencias 24/7</li>
                <li class="flex items-center gap-3"><Home class="h-5 w-5 text-primary" /> Licencia técnica N.º HVAC-04821-MX</li>
              </ul>
              <div class="mt-6 flex gap-1 text-muted-foreground">
                <a href="#" aria-label="Redes sociales" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted/60 hover:text-primary"><AtSign class="h-5 w-5" /></a>
                <a href="#" aria-label="WhatsApp" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted/60 hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
              </div>
              <Card glass class="mt-6 flex h-40 items-center justify-center p-0">
                <div class="flex flex-col items-center gap-2 text-muted-foreground">
                  <MapPin class="h-8 w-8 text-primary" />
                  <span class="text-sm">Mapa de ubicación</span>
                </div>
              </Card>
            </div>

            <Card glass class="p-6">
              {cSent() ? (
                <div class="flex h-full flex-col items-center justify-center py-10 text-center">
                  <Badge tone="success" pulse class="mb-3">Enviado</Badge>
                  <p class="text-lg font-medium">¡Gracias, {cName() || 'te contactamos pronto'}!</p>
                  <p class="mt-1 text-sm text-muted-foreground">Responderemos a la brevedad.</p>
                </div>
              ) : (
                <form class="space-y-4" onSubmit={submitContact}>
                  <div>
                    <label for="contact-name" class="mb-1 block text-sm font-medium">Nombre</label>
                    <Input id="contact-name" value={cName()} onInput={setCName} placeholder="Tu nombre" required />
                  </div>
                  <div>
                    <label for="contact-info" class="mb-1 block text-sm font-medium">Teléfono o correo</label>
                    <Input id="contact-info" value={cContact()} onInput={setCContact} placeholder="55 0000 0000 o tú@correo.com" required />
                  </div>
                  <div>
                    <label for="contact-message" class="mb-1 block text-sm font-medium">Mensaje</label>
                    <Textarea id="contact-message" value={cMessage()} onInput={setCMessage} placeholder="¿En qué te ayudamos?" rows={4} />
                  </div>
                  <Button ripple type="submit" class="w-full">Enviar mensaje</Button>
                </form>
              )}
            </Card>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer class="border-t border-border/60">
        <div class="mx-auto max-w-6xl px-5 py-10">
          <div class="flex flex-col items-center justify-between gap-6 sm:flex-row">
            <span class="flex items-center gap-2 font-semibold">
              <Snowflake class="h-4 w-4 text-primary" /> AirePro · Aire Acondicionado 24/7
            </span>
            <nav class="flex flex-wrap items-center justify-center gap-4 text-sm text-muted-foreground">
              <For each={NAV}>{(n) => <a href={n.href} class="transition-colors hover:text-foreground">{n.label}</a>}</For>
            </nav>
            <div class="flex gap-1 text-muted-foreground">
              <a href="#" aria-label="Redes sociales" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted/60 hover:text-primary"><AtSign class="h-5 w-5" /></a>
              <a href="#" aria-label="WhatsApp" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted/60 hover:text-primary"><MessageCircle class="h-5 w-5" /></a>
              <a href={PHONE_HREF} aria-label="Llamar" class="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted/60 hover:text-primary"><Phone class="h-5 w-5" /></a>
            </div>
          </div>
          <div class="mt-6 flex flex-col items-center justify-between gap-2 border-t border-border/60 pt-6 text-xs text-muted-foreground sm:flex-row">
            <span>© 2026 AirePro. Licenciados y asegurados · Licencia N.º HVAC-04821-MX.</span>
            <span>Hecho con A4ui.</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
